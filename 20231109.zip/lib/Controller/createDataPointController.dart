import '../Constants/Library.dart';

class CreateDataPointController extends GetxController {
  RxInt selectSalutation = 8.obs;
  RxBool isLoading = false.obs;
  final companyName = TextEditingController();
  final companyWebsite = TextEditingController();
  final contactName = TextEditingController();
  final designation = TextEditingController();
  final mobile = TextEditingController();
  final email = TextEditingController();
  final landlineNumber = TextEditingController();
  RxInt selectTallyUser = 4.obs;
  RxString selectLeadId = "".obs;
  RxString selectLead = "".obs;
  RxList<dynamic> lead = [].obs;
  RxString selectEpicenterId = "".obs;
  RxString selectEpicenter = "".obs;
  RxList<dynamic> epicenter = [].obs;

  @override
  void onInit() {
    getLeadSource();
    super.onInit();
  }

  void getLeadSource() async {
    Api().fetchApi(action: "LEADSRC").then((value) {
      try {
        if (value!.success) {
          var jsonResponse = value.data;

          var data = jsonResponse['ROOT'][0]['LEDSRC'];

          lead.value = data;

          isLoading.value = false;
        } else {}
      } catch (e) {
        isLoading.value = false;
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });

    Api()
        .fetchApi(
            data: json.encode({"UID": DataInfo.userId.value}),
            action: "EPICMAST")
        .then((value) {
      try {
        if (value!.success) {
          var jsonResponse = value.data;

          var data = jsonResponse['records'];

          epicenter.value = data;

          isLoading.value = false;
        } else {}
      } catch (e) {
        isLoading.value = false;
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });
  }

  checkData() {
    String? message;
    if (Utilities.checkString(selectLeadId.value) == false) {
      message = "Please select lead";
    } else if (Utilities.checkString(companyName.text.trim()) == false) {
      message = "Please enter company name";
    }
    else if (Utilities.checkString(companyName.text.trim()) == false) {
      message = "Please enter company name";
    }
    else if (Utilities.checkString(companyWebsite.text.trim()) == false) {
      message = "Please enter company website";
    }
    else if (selectSalutation.value == 8) {
      message = "Please select salutation";
    }
    else if (Utilities.checkString(contactName.text.trim()) == false) {
      message = "Please enter contact name";
    }
    else if (Utilities.checkString(designation.text.trim()) == false) {
      message = "Please enter designation";
    }
    else if (Utilities.checkString(mobile.text.trim()) == false) {
      message = "Please enter mobile number";
    }
    else if (Utilities.checkString(email.text.trim()) == false) {
      message = "Please enter email";
    }
    else if (Utilities.checkString(landlineNumber.text.trim()) == false) {
      message = "Please enter landline number";
    }
    else if (selectTallyUser.value == 4) {
      message = "Please select tally user";
    }
    else if (Utilities.checkString(selectEpicenterId.value) == false) {
      message = "Please select epicenter";
    }


    if(Utilities.checkString(message.toString())){
      CustomWidgets.snackBar(title: message.toString());
    }
  }
}

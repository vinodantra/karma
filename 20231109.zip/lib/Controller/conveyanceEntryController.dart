import 'dart:developer';

import 'package:karma/Constants/Library.dart';

class ConveyanceEntryController extends GetxController {
  RxMap data = {}.obs;
  RxList<dynamic> travelByList = [].obs;
  RxList<dynamic> conveyanceList = [].obs;
  RxString selectTravelByData = "Select".obs;
  RxString selectTravelById = "".obs;
  TextEditingController from = TextEditingController();
  TextEditingController to = TextEditingController();
  TextEditingController fromLocationController = TextEditingController();
  TextEditingController toLocationController = TextEditingController();
  TextEditingController amount = TextEditingController();
  TextEditingController passAmount = TextEditingController();
  TextEditingController comment = TextEditingController();

  TextEditingController distanceController = TextEditingController();
  RxList<dynamic> passTypeList = [
    {"ID": "1", "NAME": "Bus"},
    {"ID": "2", "NAME": "Metro"},
    {"ID": "3", "NAME": "Monorail"},
    {"ID": "4", "NAME": "Train"},
  ].obs;
  RxString petrolPrice = "".obs;
  RxString selectPassType = "Select".obs;
  RxString selectFromDate = "".obs;
  RxString selectToDate = "".obs;
  RxString fromLocation = "".obs;
  RxString toLocation = "".obs;
  RxMap callDetails = {}.obs;
  RxBool showPassData = false.obs;
  @override
  void onInit() {
    data.value = Get.arguments;
    log("fe:${data.value}");
    getData();
    getTravelByData();
    getConveyanceData(data['ID']);
    super.onInit();
  }

  getTravelByData() async {
    Api().fetchApi(action: "GETSOURCE").then((value) {
      try {
        if (value!.success) {
          var jsonResponse = value.data;
          travelByList.value = jsonResponse['ROOT'][0]['DETAILS'];
        }
      } catch (e) {
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });
  }

  getConveyanceData(String id) async {
    Api().fetchApi(data: id, action: "GETCONVAYANCE").then((value) {
      try {
        if (value!.success) {
          var jsonResponse = value.data;
          conveyanceList.value = jsonResponse['ROOT'][0]['DETAILS'];
        }
      } catch (e) {
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });
  }

  getData() async {
    Api()
        .fetchApi(data: DataInfo.username.value, action: "CALLBOOK")
        .then((value) {
      try {
        if (value!.success) {
          var jsonResponse = value.data;
          var response = jsonResponse['ROOT'][0]['DETAILS'][0];
          callDetails.value = jsonResponse['ROOT'][0]['DETAILS'][0];
         // getConveyanceData(data['ID']);
        }
      } catch (e) {
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });
  }

  deleteConveyanceData(String id) async {
    Api().fetchApi(data: id, action: "DELETECONVAYANCE").then((value) {
      try {
        if (value!.success) {
          if (value.data == "Yes") {
            Get.find<ConveyanceEntryController>().onInit();
          }
        }
      } catch (e) {
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });
  }

  createPass() async {
    Api().fetchApi(
        data:json.encode({
          "PASSTYPE": selectPassType.value,
          "FROMDATE": selectFromDate.value,
          "TODATE": selectToDate.value,
          "FROMLOC": fromLocationController.text,
          "TOLOC": toLocationController.text,
          "PASSAMT": passAmount.text.trim(),
          "UNAME": DataInfo.username.value
        }),
        action: "PASSCONV").then((value) {
      try {


        if (value!.success) {
          Get.dialog(
            Center(
              child: Card(
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.0),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.check,
                      color: Colors.lightGreen,
                      size: 50,
                    ),
                    20.heightBox,
                    TextWidget(
                      "Well Done!",
                      fontSize: 18,
                      color: Colors.black,
                    ),
                    15.heightBox,
                    TextWidget(
                      "You pass successfully created.",
                      fontSize: 16,
                      color: Colors.grey[500],
                    ),
                    20.heightBox,
                    CustomButton(
                      text: "Ok",
                      onPressed: () {
                        Get.offAll(() => ConveyanceEntry(), arguments: data);
                      },
                    ),
                    10.heightBox,
                  ],
                ).p24(),
              ),
            ),
            barrierDismissible: false,
          ).then((value) {
            Get.offAll(() => ConveyanceEntry(), arguments: data);
          });
          // var jsonResponse =
          // json.decode(responseData.body);
          // conveyanceList.value = jsonResponse['ROOT'][0]['DETAILS'];

        }
      } catch (e) {
        if (kDebugMode) {
          print("error:$e");
        }
      }
    } );

  }

  getPrice() async {
    Api().fetchApi(data:json.encode({"CALLDATE": callDetails['CALLDATE']}),action: "PETROLRATE").then((value){
      try {


        if (value!.success) {
          var jsonResponse = value.data;

          petrolPrice.value = jsonResponse['records'][0]['RATE'].toString();
          showPassData.value = true;
        }
      } catch (e) {
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });

  }

  addConveyanceEntry() async {

    print("de:${data['ID']}|${data['CALLDATE']}|${data['CMP']}|${DataInfo.username.value}|${from.text.trim()}|${to.text.trim()}|${selectTravelByData.value}|${amount.text.trim()}|${comment.text.trim()}|");
    Api().fetchApi(
        data:"${data['ID']}|${data['CALLDATE']}|${data['CMP']}|${DataInfo.username.value}|${from.text.trim()}|${to.text.trim()}|${selectTravelByData.value}|${amount.text.trim()}|${comment.text.trim()}|",
        action: "SETCONVAYANCE").then((value){
      try {

        from.clear();
        to.clear();
        fromLocationController.clear();
        toLocationController.clear();
        comment.clear();
        amount.clear();
        passAmount.clear();
        distanceController.clear();
        selectTravelByData.value ="Select";
        selectTravelById.value = "";
        if (value!.success) {
          if (value.data == 'YES') {
            Get.dialog(
              Center(
                child: Card(
                  color: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.check,
                        color: Colors.lightGreen,
                        size: 50,
                      ),
                      20.heightBox,
                      TextWidget(
                        "Well Done!",
                        fontSize: 18,
                        color: Colors.black,
                      ),
                      15.heightBox,
                      TextWidget(
                        "Your Conveyance Entry Added Successfully.",
                        fontSize: 16,
                        color: Colors.grey[500],
                      ),
                      20.heightBox,
                      CustomButton(
                        text: "Ok",
                        onPressed: () {
                          getData();
                          getConveyanceData(data['ID']);
                          Get.back();
                          // Get.offAll(() => const ConveyanceEntry(),
                          //     arguments: data);
                        },
                      ),
                      10.heightBox,
                    ],
                  ).p24(),
                ),
              ),
              barrierDismissible: false,
            ).then((value) {
             // Get.back();
              //Get.offAll(() => const ConveyanceEntry(), arguments: data);
            });
          }
        }
      } catch (e) {
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });

  }

  checkData() {
    if (from.text.trim().isEmpty) {
      CustomWidgets.snackBar(title: "Please enter from location.");
    } else if (to.text.trim().isEmpty) {
      CustomWidgets.snackBar(title: "Please enter to location.");
    } else if (selectTravelByData.value == "Select") {
      CustomWidgets.snackBar(title: "Please select travel by");
    } else if (amount.text.trim().isEmpty) {
      CustomWidgets.snackBar(title: "Please enter amount.");
    } else {
      addConveyanceEntry();
    }
  }
}

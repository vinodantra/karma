import 'package:karma/Constants/Library.dart';

class SupportController extends GetxController{
  RxBool isLoading = false.obs;
  RxList<dynamic> list = [].obs;
  RxList<dynamic> list1 = [].obs;
  final ScrollController scrollController = ScrollController();
@override
  void onInit() {
    getData();
    super.onInit();
  }

  void getData() async {
    isLoading.value = true;
    Api().fetchApi(data: "", action: "AVAILABLEUSER").then((value){
      try {


        if (value!.success) {
          var jsonResponse = value.data;

          list.value = jsonResponse['Table'];
          list1.value = jsonResponse['Table1'];
          print("le:${list1.value}");
          isLoading.value = false;
        } else {
          isLoading.value = false;
        }
      } catch (e) {
        isLoading.value = false;
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });




  }
}
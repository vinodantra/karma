import 'dart:developer';

import 'package:karma/Constants/Library.dart';

import 'package:intl/intl.dart';
class AddSupportEntry extends GetView<AddSupportEntryController> {
  const AddSupportEntry({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(AddSupportEntryController());
    return Scaffold(
      appBar: AppBarWidget(
        title: "Add Support Entry",
        onSubmit: (){
          controller.updateStatus();
        },
      ),
      body: SizedBox(
        width: Get.width,
        height: Get.height,
        child: Obx(()=>ListView(
          children: [
            tile(title: "Company Name",data: controller.data['CMP']),
            tile(title: "CheckIn Time",data: controller.data['CHKIN']),
            tile(title: "CheckOut Time",data: controller.data['CHKOUT']),
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    TextWidget(
                      "Tally Serial",

                      color:  titleColor,
                      fontSize: 16,

                      fontWeight: FontWeight.w500,

                    ),

                    SizedBox(
                        width: Get.width / 2,
                        height: 50,
                        child: TextField(

                          controller: controller.tallySerialController,
                          keyboardType: TextInputType.number,
                          textAlign: TextAlign.right,

                        )
                    ),
                  ],
                ).pSymmetric(h: 15.0,),
                5.heightBox,
                Container(
                  width: Get.width,
                  height: 1.0,
                  color: Colors.grey[300],
                ),
              ],
            ),
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    TextWidget(
                      "Ticket Number",

                      color: titleColor,
                      fontSize: 16,

                      fontWeight: FontWeight.w500,

                    ),

                    SizedBox(
                        width: Get.width / 2,
                        height: 50,
                        child: TextField(
                          controller: controller.tallyNumberController,
                          onTap: (){
                            controller.tallyNoController.clear();

                            Get.dialog(Center(
                                child: Obx(()=>Card(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      TextWidget("TLY-ddmmmyyyy-TicketNo",fontSize: 18,fontWeight: FontWeight.w700,
                                        textAlign: TextAlign.center,).p8(),
                                      Container(
                                        width: Get.width,
                                        height: 1.0,
                                        color: Colors.grey[400],
                                      ),
                                      10.heightBox,
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          TextWidget("Ticket Type",fontSize: 16,
                                            color: appColor.value,),
                                          InkWell(
                                            onTap:(){
                                              CustomWidgets.customBottomSheet(controller.ticketTypeList, "NAME",false, (data){

                                                controller.selectTicketType.value = data['NAME'];
                                                controller.selectTicketTypeId.value = data['ID'];
                                                Get.back();
                                              });

                                            },
                                            child: Row(

                                              children: [
                                                TextWidget(controller.selectTicketType.value,fontSize: 14,color: Color(0xff2f3237),),
                                                5.widthBox,
                                                const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                                              ],),
                                          ),

                                        ],
                                      ).pSymmetric(h: 10.0,v: 15.0),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          TextWidget("Ticket Date",fontSize: 16,
                                            color: appColor.value,),
                                          InkWell(
                                            onTap:()async{
                                              var de = await  CustomWidgets.pickDate(context,selectPreviousDate: true);

                                              if(de != null) {
                                                controller.selectDate.value = de.toString();

                                                controller.selectTallyDate.value = DateFormat('dd/MM/yyyy')
                                                    .format(de);
                                                controller.tallyDate.value = DateFormat('ddMMMyyyy')
                                                    .format(de);


                                              }

                                            },
                                            child: Row(

                                              children: [
                                                TextWidget(controller.selectTallyDate.value,fontSize: 14,color: Color(0xff2f3237),),
                                                5.widthBox,
                                                const Icon(Icons.calendar_today_outlined,color: Color(0xff7E8494),)
                                              ],),
                                          ),

                                        ],
                                      ).pSymmetric(h: 10.0,v: 5.0),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          TextWidget(
                                            "Ticket No",

                                            color: appColor.value,
                                            fontSize: 16,

                                            fontWeight: FontWeight.w500,

                                          ),

                                          SizedBox(
                                              width: Get.width / 3,
                                              height: 50,
                                              child:  TextField(
                                                textAlign: TextAlign.right,
                                                controller: controller.tallyNoController,
                                                keyboardType: TextInputType.number,
                                              )
                                          ),
                                        ],
                                      ).pSymmetric(h: 10.0,v: 5.0),
                                      10.heightBox,
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          TextButton(onPressed: (){
                                            Get.back();
                                          }, child: TextWidget("Cancel",fontSize: 16,
                                            color: Colors.black,)),
                                          CustomButton(text: "OK",onPressed: (){
                                            if(controller.selectTicketTypeId.value != "" && controller.tallyNoController.text != "")
                                            {
                                              controller.tallyNumberController.text = "${controller.selectTicketType.value}-${controller.tallyDate.value.toUpperCase()}-${controller.tallyNoController.text}";
                                              log("show data:${controller.tallyNumberController.text}");
                                              Get.back();
                                            }
                                            else
                                            {
                                              CustomWidgets.snackBar(title: "Please enter all fields.");
                                            }
                                          },  width: 120,
                                            height: 40,),
                                        ],
                                      ),

                                    ],
                                  ).p8(),
                                ).pSymmetric(h: 20.0,v: 8.0),)
                            ));
                          },
                          readOnly: true,
                          textAlign: TextAlign.right,
                          keyboardType: TextInputType.number,
                        )
                    ),
                  ],
                ).pSymmetric(h: 15.0,),
                5.heightBox,
                Container(
                  width: Get.width,
                  height: 1.0,
                  color: Colors.grey[300],
                ),
              ],
            ),
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextWidget(
                      "Type of Call",

                      color: titleColor,
                      fontSize: 16,

                      fontWeight: FontWeight.w500,

                    ),
                    InkWell(
                      onTap:(){
                        CustomWidgets.customBottomSheet(controller.data['TEAMID'] != "1" ? controller.typeOfCallList : controller.typeOfCallList1, "NAME",false, (data){

                          controller.selectTypeOfCall.value = data['NAME'];
                          controller.selectTypeOfCallId.value = data['ID'];
                          Get.back();
                        });

                      },
                      child: Row(

                        children: [
                          TextWidget(controller.selectTypeOfCall.value,fontSize: 14,color: Color(0xff2f3237),),
                          5.widthBox,
                          const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                        ],),
                    ),

                  ],
                ).pSymmetric(h: 15.0,v: 10.0),
                5.heightBox,
                Container(
                  width: Get.width,
                  height: 1.0,
                  color: Colors.grey[300],
                ),
              ],
            ),
           controller.data['TEAMID'] == "1" ?
           Column(
              children: [
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextWidget(
                          "Level of Call",

                          color: titleColor,
                          fontSize: 16,

                          fontWeight: FontWeight.w500,

                        ),
                        InkWell(
                          onTap:(){
                            CustomWidgets.customBottomSheet(controller.levelList, "NAME",false, (data){

                              controller.selectLevel.value = data['NAME'];
                              controller.selectLevelId.value = data['ID'];
                              Get.back();
                            });

                          },
                          child: Row(

                            children: [
                              TextWidget(controller.selectLevel.value,fontSize: 14,color: Color(0xff2f3237),),
                              5.widthBox,
                              const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                            ],),
                        ),

                      ],
                    ).pSymmetric(h: 15.0,v: 10.0),
                    5.heightBox,
                    Container(
                      width: Get.width,
                      height: 1.0,
                      color: Colors.grey[300],
                    ),
                  ],
                ),
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextWidget(
                          "Category",

                          color: titleColor,
                          fontSize: 16,

                          fontWeight: FontWeight.w500,

                        ),
                        InkWell(
                          onTap:(){
                            CustomWidgets.customBottomSheet(controller.categoryList, "NAME",true, (data){

                              controller.selectCategory.value = data['NAME'];
                              controller.selectCategoryId.value = data['ID'];
                              Get.back();
                            });

                          },
                          child: Row(

                            children: [
                              TextWidget(controller.selectCategory.value,fontSize: 14,color: Color(0xff2f3237),),
                              5.widthBox,
                              const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                            ],),
                        ),

                      ],
                    ).pSymmetric(h: 15.0,v: 10.0),
                    5.heightBox,
                    Container(
                      width: Get.width,
                      height: 1.0,
                      color: Colors.grey[300],
                    ),
                  ],
                ),
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextWidget(
                          "Status",

                          color: titleColor,
                          fontSize: 16,

                          fontWeight: FontWeight.w500,

                        ),
                        InkWell(
                          onTap:(){
                            CustomWidgets.customBottomSheet(controller.statusList, "NAME",false, (data){

                              controller.selectStatus.value = data['NAME'];
                              controller.selectStatusId.value = data['ID'];
                              Get.back();
                            });

                          },
                          child: Row(

                            children: [
                              TextWidget(controller.selectStatus.value,fontSize: 14,color: Color(0xff2f3237),),
                              5.widthBox,
                              const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                            ],),
                        ),

                      ],
                    ).pSymmetric(h: 15.0,v: 10.0),
                    5.heightBox,
                    Container(
                      width: Get.width,
                      height: 1.0,
                      color: Colors.grey[300],
                    ),
                  ],
                ),
                controller.selectStatusId.value == "2" ?
                CheckboxListTile(

                  value: controller.experienceTicket.value, onChanged: (value){
                  controller.experienceTicket.value = value!;
                },
                  contentPadding: const EdgeInsets.all(2),
                  controlAffinity: ListTileControlAffinity.leading,
                title: TextWidget("Experience Ticket",fontSize: 16,),
                ) : const SizedBox(),
                Container(
                  width: Get.width,
                  height: 1.0,
                  color: Colors.grey[300],
                ),
              ],
            ) : const SizedBox(),

            tile(title: "Contact Person",data: DataInfo.username.value),
            tile(title: "Contact Email",data: DataInfo.email.value),
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    TextWidget(
                      "Attend Person",

                      color: titleColor,
                      fontSize: 16,

                      fontWeight: FontWeight.w500,

                    ),

                    SizedBox(
                        width: Get.width / 2,
                        height: 50,
                        child: TextField(

                          controller: controller.name,
                          keyboardType: TextInputType.name,
                          textAlign: TextAlign.right,

                        )
                    ),
                  ],
                ).pSymmetric(h: 15.0,),
                5.heightBox,
                Container(
                  width: Get.width,
                  height: 1.0,
                  color: Colors.grey[300],
                ),
              ],
            ),
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    TextWidget(
                      "Attend Person Email",

                      color: titleColor,
                      fontSize: 16,

                      fontWeight: FontWeight.w500,

                    ),

                    SizedBox(
                        width: Get.width / 2,
                        height: 50,
                        child: TextField(

                          controller: controller.email,
                          keyboardType: TextInputType.emailAddress,
                          textAlign: TextAlign.right,

                        )
                    ),
                  ],
                ).pSymmetric(h: 15.0,),
                5.heightBox,
                Container(
                  width: Get.width,
                  height: 1.0,
                  color: Colors.grey[300],
                ),
                TextField(

                  controller: controller.remark,
                  decoration: const InputDecoration(
                    hintText: "Visit/Support remark"
                  ),
                  keyboardType: TextInputType.multiline,
                  minLines: 5,
                  maxLines: 10,



                ).pSymmetric(h: 15.0,v: 8.0),
                5.heightBox,
                Container(
                  width: Get.width,
                  height: 1.0,
                  color: Colors.grey[300],
                ),
              ],
            ),

          ],
        ),),
      ),
    );
  }
  Widget tile({String?title,String? data,String type = "1" }){
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextWidget(
              title,

              color: titleColor,
              fontSize: 16,

              fontWeight: FontWeight.w500,

            ),
            type == "1" ?
            SizedBox(
              width: Get.width / 2,
              child: TextWidget(
                data,

                color: const Color(0xff667084),
                fontSize: 16,

                fontWeight: FontWeight.w500,
                textAlign: TextAlign.right,
                maxLines: 10,

              ),
            ) : InkWell(
              onTap: (){
                Utilities.onClickMobile(data!);
              },
              child: TextWidget(
                data,
                color: Colors.lightBlueAccent,
                fontSize: 16,

                fontWeight: FontWeight.w500,
                textDecoration: TextDecoration.underline,

              ),
            ),
          ],
        ).pSymmetric(h: 15.0,v: 10.0),
        5.heightBox,
        Container(
          width: Get.width,
          height: 1.0,
          color: Colors.grey[300],
        ),
      ],
    );
  }


}

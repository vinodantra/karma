
// ignore_for_file: file_names

import 'package:karma/Constants/Library.dart';


class SupportList extends GetView<SupportListController> {
  const SupportList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(SupportListController());
    return Scaffold(
      appBar: AppBarWidget(

        title: "Support List",
        onPressAdd: (){
          Get.to(()=> const AddSupportEntry(),arguments: controller.data)!.then((value) {


            Get.find<SupportListController>().onInit();
          });
        },
      ),
      body: WillPopScope(
        onWillPop: ()async{
          Get.back();
          return true;
        },
        child: SizedBox(
          width: Get.width,
          height: Get.height,
          child: Obx(() => Stack(
                children: [
                  ListView(
                    children: List.generate(
                        controller.list.length,
                        (index) => InkWell(
                          onTap: (){
                            Get.to(()=> const SupportDetails(),arguments: controller.list[index]);
                          },
                          child: Card(
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        TextWidget(
                                          "Ticket : ",
                                          color:  titleColor,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500,
                                        ),
                                        10.widthBox,
                                        TextWidget(
                                          controller.list[index]['TICKET'],
                                          color:  titleColor,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ],
                                    ),
                                    5.heightBox,
                                    Row(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        TextWidget(
                                          "Category : ",
                                          color:  titleColor,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500,
                                        ),
                                        10.widthBox,
                                        SizedBox(
                                          width: Get.width * 0.65,
                                          child: TextWidget(
                                            controller.list[index]['CATEGORY'],
                                            color:  titleColor,
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500,
                                            maxLines: 5,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ).p8(),
                              ).p8(),
                        )),
                  ),
                  controller.isLoading.value
                      ? const LoadingScreen()
                      :   controller.isLoading.value == false &&  controller.list.isEmpty ? Center(
                        child: TextWidget("Support entries are not available.",
                    fontSize: 18,color: Colors.black,fontWeight: FontWeight.w500,
                  ),
                      ) : const SizedBox(),
                ],
              )),
        ),
      ),
    );
  }
}

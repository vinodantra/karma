import 'package:karma/Controller/supportController.dart';

import '../../Constants/Library.dart';
class Support extends GetView<SupportController> {
  const Support({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(SupportController());
    return Scaffold(
      appBar: AppBarWidget(
        title: "Support Availability",
      ),
      body: SizedBox(
        width: context.screenWidth,
        height: context.screenHeight,


        child: Obx(()=>Stack(
          children: [
         controller.list.isNotEmpty ?
         Column(mainAxisSize: MainAxisSize.max,
              children: [
               controller.list.isNotEmpty ?  Expanded(
                 child: Column(
                    children: [
                      TextWidget("Antra Cloud Support",color: Provider.of<AppThemeController>(context).appColor,fontSize: 20,
                        fontWeight: FontWeight.w500,).p8(),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          TextWidget("Name",color: titleColor,fontSize: 16,
                            fontWeight: FontWeight.w500,),
                          TextWidget("Status",color: titleColor,fontSize: 16,
                            fontWeight: FontWeight.w500,),
                        ],
                      ).pSymmetric(h: 20.0,v: 10.0),
                      Divider(
                        height: 1.0,
                        color: Colors.grey[500],
                      ),
                      Expanded(

                        child: Scrollbar(
                          controller: controller.scrollController,
                          thickness: 5.0,


                          trackVisibility: true,
                          thumbVisibility: true,

                          child: ListView.separated(
                            controller: controller.scrollController,
                            shrinkWrap: true,

                            itemCount: controller.list.length,
                            itemBuilder: (context, index) {
                              return ListTile(
                                onTap: (){

                                },
                                title: TextWidget(controller.list[index]['name'],
                                  color: titleColor,
                                  fontSize: titleFontSize,),
                                trailing:TextWidget(controller.list[index]['available_status'],
                                  color: setColor(controller.list[index]['available_status']),
                                  fontSize: titleFontSize,),
                              );
                            },
                            separatorBuilder: (context,index){
                              return  Divider(
                                height: 1.0,
                                color: Colors.grey[500],
                              );
                            },),
                        ),
                      ),
                    ],
                  ),
               ) : const SizedBox(),
               controller.list1.isNotEmpty ?  Column(
                  children: [
                    TextWidget("Tally Support",color: Provider.of<AppThemeController>(context).appColor ,fontSize: 20,
                      fontWeight: FontWeight.w500,).p8(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TextWidget("Name",color: titleColor,fontSize: 16,
                          fontWeight: FontWeight.w500,),
                        TextWidget("Status",color: titleColor,fontSize: 16,
                          fontWeight: FontWeight.w500,),
                      ],
                    ).pSymmetric(h: 20.0,v: 10.0),
                    Divider(
                      height: 1.0,
                      color: Colors.grey[500],
                    ),
                    Column(
                      children: List.generate(controller.list1.length, (index) => Column(
                        children: [
                          ListTile(
                            onTap: (){

                            },
                            title: TextWidget(controller.list1[index]['name'],
                              color: titleColor,
                              fontSize: titleFontSize,),
                            trailing:TextWidget(controller.list1[index]['available_status'],
                              color: setColor(controller.list1[index]['available_status']),
                              fontSize: titleFontSize,),
                          ),
                          Divider(
                            height: 1.0,
                            color: Colors.grey[500],
                          )

                        ],
                      )),
                    ),
                  ],
                ) : const SizedBox(),

              ],
            ) : controller.isLoading.value ==  false ?  Center(
           child: TextWidget("No data found.",fontSize: 25,fontWeight: FontWeight.w500,),
         ) : const SizedBox(),
            controller.isLoading.value ? const LoadingScreen() : const SizedBox()
          ],
        ))
      ),
    );
  }
 Color setColor(String value){
    if(value == "On Leave" || value == "Not in Shift"){
      return Colors.red;
    }else if(value == "Available" || value == "Available Incharge"){
      return Colors.green;
    }else{
      return Colors.yellow;
    }
  }
  
}
/*
On Leave
Not in Shift
Available
Available Incharge
Lunch Break*/

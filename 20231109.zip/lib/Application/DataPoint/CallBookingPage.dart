import 'dart:developer';


import 'package:gradient_borders/box_borders/gradient_box_border.dart';
import 'package:karma/Constants/Library.dart';

import 'package:intl/intl.dart';
class CallBookingPage extends GetView<CallBookingController> {
  const CallBookingPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(CallBookingController());
    return WillPopScope(
      onWillPop: ()async{
        Get.back();
       // Get.offAll(()=>  DataPointInfo(),arguments: controller.data);
        return true;
      },
      child: Scaffold(

        appBar: AppBarWidget(title: controller.data['DPNAME'],

         /* onSubmit: (){
          controller.checkData();
        },*/),
        body: SingleChildScrollView(
          child: SizedBox(
              height: Get.height,
              width: Get.width,
              child:Obx(()=> Stack(
                children: [
                  Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Column(
                            children: [

                             controller.step1.value ?  Container(
                                width: 24,
                                height: 24,
                                decoration:
                                BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                      colors: Provider.of<AppThemeController>(context).appGradientColor
                                  ),
                                ),
                                child: const Center(
                                    child: Icon(Icons.check,color: Colors.white,)

                                ),
                              ) : Container(
                               width: 24,
                               height: 24,
                               decoration: controller.currentPage.value  == 0 ?
                               BoxDecoration(
                                 shape: BoxShape.circle,
                                 gradient: LinearGradient(
                                     colors: Provider.of<AppThemeController>(context).appGradientColor
                                 ),
                               ) : BoxDecoration(
                                   shape: BoxShape.circle,
                                   border: Border.all(width: 1.0,color: greyColor)
                               ),
                               child: Center(
                                   child: controller.currentPage.value  == 0 ?
                                   TextWidget("1",color: Colors.white,
                                     fontSize: 14,

                                     fontWeight: FontWeight.w400,) :


                                   TextWidget("1",color: greyColor,
                                     fontSize: 14,

                                     fontWeight: FontWeight.w400,)

                               ),
                             ),
                              5.heightBox,
                              controller.currentPage.value  == 0 ?
                              GradientTextWidget("Step 1",
                                fontSize: 14,
                                fontWeight: FontWeight.w500,) : TextWidget("Step 1",
                                color: greyColor,
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                              )
                            ],
                          ),
                          GradientTextWidget("-----"),
                          Column(
                            children: [

                            controller.step2.value ? Container(
                              width: 24,
                              height: 24,
                              decoration:
                              BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: LinearGradient(
                                    colors: Provider.of<AppThemeController>(context).appGradientColor
                                ),
                              ),
                              child: const Center(
                                  child: Icon(Icons.check,color: Colors.white,)

                              ),
                            ) :  Container(
                                width: 24,
                                height: 24,
                                decoration: controller.currentPage.value  == 1 ?
                                BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                      colors: Provider.of<AppThemeController>(context).appGradientColor
                                  ),
                                ) : BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(width: 1.0,color: greyColor)
                                ),
                                child: Center(
                                    child: controller.currentPage.value  == 1 ?
                                    TextWidget("2",color: Colors.white,
                                      fontSize: 14,

                                      fontWeight: FontWeight.w400,) :


                                    TextWidget("2",color: greyColor,
                                      fontSize: 14,

                                      fontWeight: FontWeight.w400,)

                                ),
                              ),
                              5.heightBox,
                              controller.currentPage.value  == 1 ?
                              GradientTextWidget("Step 2",
                                fontSize: 14,
                                fontWeight: FontWeight.w500,) : TextWidget("Step 2",
                                color: greyColor,
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                              )
                            ],
                          ),
                          GradientTextWidget("-----"),
                          Column(
                            children: [

                              Container(
                                width: 24,
                                height: 24,
                                decoration: controller.currentPage.value  == 2 ?
                                BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                      colors: Provider.of<AppThemeController>(context).appGradientColor
                                  ),
                                ) : BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(width: 1.0,color: greyColor)
                                ),
                                child: Center(
                                    child: controller.currentPage.value  == 2 ?
                                    TextWidget("3",color: Colors.white,
                                      fontSize: 14,

                                      fontWeight: FontWeight.w400,) :


                                    TextWidget("3",color: greyColor,
                                      fontSize: 14,

                                      fontWeight: FontWeight.w400,)

                                ),
                              ),
                              5.heightBox,
                              controller.currentPage.value  == 2 ?
                              GradientTextWidget("Step 3",
                                fontSize: 14,
                                fontWeight: FontWeight.w500,) : TextWidget("Step 3",
                                color: greyColor,
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                              )
                            ],
                          ),

                        ],
                      ).pSymmetric(h: 10.0,v: 20.0),
                      10.heightBox,
                      const ShowPage(),
                      CustomButton(text: controller.currentPage.value == 0 ?
                      "Proceed to Step 2"  :  controller.currentPage.value == 1 ?  "Proceed to last step" : "Done" ,width: Get.width,

                      onPressed: () {
                        if(controller.currentPage.value == 0){
                          controller.checkStep1();
                        }
                        else if(controller.currentPage.value == 1){
                          controller.checkStep2();
                        }
                        else{
                          controller.checkData();
                        }



                      },),
                    ],
                  ).p16(),
                  controller.isLoading.value ?
                      const LoadingScreen() : const SizedBox()
                ],
              )),
          ),
        ),
      ),
    );

  }
}

class ShowPage extends GetView<CallBookingController> {
  const ShowPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(CallBookingController());
    return PageView.builder(
      itemCount: 3,
      controller: controller.pageController,
      physics: const BouncingScrollPhysics(),
      itemBuilder: (_,int index){
        return Obx(()=>SizedBox(width: Get.width,
          height: Get.height,
          child: index == 0 ?  Column(

            children: [
              selectItem(title: Utilities.checkString(controller.currentDate.value) ? controller.currentDate.value : "Select Call date",icon: CustomWidgets.showAssetImage1(path: calendar),
                onPressed: () async{
                  var de = await  CustomWidgets.pickDate(context);
                  if(de != null) {
                    controller.selectDate.value = de.toString();

                    controller.currentDate.value = DateFormat('dd-MM-yyyy')
                        .format(de);

                  }
                },

              ),
              10.heightBox,
              selectItem(title: controller.currentTime.value,icon: CustomWidgets.showAssetImage1(path: calendar),
                  onPressed: ()async{
                    TimeOfDay? selectTime = await  CustomWidgets.pickTime(context);
                    if(selectTime != null) {
                      controller.selectTime.value =  selectTime.format(context).toString();
                      controller.currentTime.value = selectTime.format(context).toString();
                    }
                  }),
              10.heightBox,
              selectItem(title: Utilities.checkString(controller.selectCallType.value) ? controller.selectCallType.value : "Select Type of call",onPressed: (){
                CustomWidgets.customBottomSheet(controller.callTypeList, "NAME",false, (data){

                  controller.selectCallType.value = data['NAME'];
                  controller.selectCallTypeId.value = data['ID'];
                  Get.back();
                });
              }),
              10.heightBox,
              selectItem(title: Utilities.checkString(controller.selectNoc.value) ? controller.selectNoc.value : "Select Nature of call",onPressed: (){
                CustomWidgets.customBottomSheet(controller.fNatureOfCall, "NAME",true, (data){
                  controller.selectNoc.value = data['NAME'];
                  controller.selectNocId.value =  data['ID'];
                  Get.back();
                });
              }),
              10.heightBox,
              selectItem(title: Utilities.checkString(controller.selectManager.value) ? controller.selectManager.value : "Select Allocation manager",onPressed: (){
                CustomWidgets.customBottomSheet(controller.allocationManagerList, "NAME",false, (data){
                  controller.selectManager.value = data['NAME'];
                  controller.selectManagerId.value = data['ID'];
                  controller.selectUser.value = "Select";
                  Get.back();
                });
              }),
              10.heightBox,

            ],
          ) : index == 1 ?
          Column(

            children: [

              controller.selectManager.value == "Sales" ?  selectItem(title: Utilities.checkString(controller.selectUser.value) ? controller.selectUser.value : "Select User",onPressed: (){
                CustomWidgets.customBottomSheet(controller.flUsersList, "NAME",true, (data){
                  controller.selectUser.value = data['NAME'];
                  Get.back();
                });
              }) : const SizedBox(),
              10.heightBox,
              selectItem(title: Utilities.checkString(controller.selectSupType.value) ? controller.selectSupType.value : "Select support type",onPressed: (){
                CustomWidgets.customBottomSheet(controller.supTypeList, "NAME",true, (data){
                  controller.selectSupType.value = data['NAME'];
                  controller.selectSupTypeId.value = data['ID'];
                  Get.back();
                });
              }),
              10.heightBox,
              selectItem(title: controller.selectAddress.value,onPressed: (){
                CustomWidgets.customBottomSheet(controller.addressList, "NAME",true, (data){
                  controller.selectAddress.value = data['NAME'];
                  controller.addressDetails.value = data['ADD'];
                  controller.selectPhone.value = data['PHONE'];
                  controller.selectRegion.value = data['CITY'];
                  Get.back();
                });
              }),
              10.heightBox,
              controller.selectPhone.value.isNotEmpty ?  Column(
                children: [
                  selectItem(title: controller.selectPhone.value,onPressed: (){

                  },icon: const SizedBox()),
                  10.heightBox,
                ],
              ): const SizedBox(),
              controller.addressDetails.value.isNotEmpty ?  Column(
                children: [
                  selectItem(title: controller.addressDetails.value,onPressed: (){

                  },icon: const SizedBox()),
                  10.heightBox,
                ],
              ): const SizedBox(),
              controller.selectRegion.value.isNotEmpty ?  Column(
                children: [
                  selectItem(title: controller.selectRegion.value,onPressed: (){

                  },icon: const SizedBox()),
                  10.heightBox,
                ],
              ): const SizedBox(),
              selectItem(title: controller.selectTallySrNo.value,onPressed: (){
                CustomWidgets.customBottomSheet(controller.tallySrNo, "NAME",true, (data){
                  controller.selectTallySrNo.value = data['NAME'];
                  Get.back();
                });
              }),
              10.heightBox,
            ],
          ) : Column(

            children: [


              selectItem(title: Utilities.checkString(controller.selectContact.value) ? controller.selectContact.value : "Select Contact",onPressed: (){
                CustomWidgets.customBottomSheet(controller.contactList, "CNTNAME",true, (data){

                  controller.selectContact.value = data['CNTNAME'];
                  controller.selectContactEmail.value = data['EMAIL'];
                  controller.selectContactMobile.value = data['MOBILE'];
                  controller.selectContactId.value = data['CNTID'];
                  Get.back();
                });
              }),
              10.heightBox,

              controller.selectContactEmail.value.isNotEmpty ?  Column(
                children: [
                  selectItem(title: controller.selectContactEmail.value,onPressed: (){

                  },icon: const SizedBox()),
                  10.heightBox,
                ],
              ): const SizedBox(),
              controller.selectContactMobile.value.isNotEmpty ?  Column(
                children: [
                  selectItem(title: controller.selectContactMobile.value,onPressed: (){

                  },icon: const SizedBox()),
                  10.heightBox,
                ],
              ): const SizedBox(),
              InkWell(
                onTap: () {
                  if(controller.selectCheckCollection.value == 2){
                    controller.selectCheckCollection.value = 1;
                  }
                  else{
                    controller.selectCheckCollection.value = 2;
                  }
                },
                child: Container(
                  width: Get.width,
                  height: 60,
                  decoration: BoxDecoration(
                    border: controller.selectCheckCollection.value == 1 ?  GradientBoxBorder(
                      gradient: LinearGradient(
                          colors:
                          Provider.of<AppThemeController>(context)
                              .appGradientColor),
                      width: 1.0,
                    ) : Border.all(width: 0.50, color: const Color(0xFFDFDFDF)),
                    // border: Border.all(width: 0.50, color: const Color(0xFFDFDFDF)),
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x3fb0b0b0),
                        blurRadius: 4,
                        offset: Offset(0, 2),
                      ),
                    ],
                    color: Colors.white,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,

                    children: [
                      TextWidget(
                        "Cheque Collection",
                        color: const Color(0xff2f3237),
                        fontSize: 16,

                      ),
                      controller.selectCheckCollection.value == 1  ? CustomWidgets.showAssetImage(path: select) : const SizedBox(),

                    ],
                  ).pSymmetric(h: 25.0),
                ),
              ),
              10.heightBox,
              commentField(controller: controller.remarkController,
              hintText: "Remark for customer"),
            ],
          ),
        ));
      },
      onPageChanged: (value){
        controller.currentPage.value = value;
      },).h(context.screenHeight * 0.65);
  }
}


class ContactPage1 extends StatefulWidget {
  const ContactPage1({Key? key}) : super(key: key);

  @override
  State<ContactPage1> createState() => _ContactPage1State();
}

class _ContactPage1State extends State<ContactPage1> {
  @override
  Widget build(BuildContext context) {
    final controller = Get.put(CallBookingController());
    return SizedBox(
      height: Get.height,
      width: Get.width,
      child:Obx(()=> Stack(
        children: [
          ListView(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: 30,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        TextWidget("Call Date",color: greyColor,
                          fontSize: 14,),

                        Container(
                          width: Get.width * 0.5,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 30.0,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        InkWell(
                          onTap: () async{
                            var de = await  CustomWidgets.pickDate(context);

                            if(de != null) {
                              controller.selectDate.value = de.toString();

                              controller.currentDate.value = DateFormat('dd-MM-yyyy')
                                  .format(de);
                            }
                          },
                          child: Row(
                            children: [
                              TextWidget(controller.currentDate.value,fontSize: 14,
                                  color: const Color(0xff2f3237)),
                              5.widthBox,
                              const Icon(Icons.calendar_today_outlined,size: 20,color: Color(0xff7E8494),),
                              const  Icon(Icons.keyboard_arrow_down_outlined,size: 20,color: Color(0xff7E8494),)
                            ],
                          ),
                        ),

                        Container(
                          width: Get.width * 0.4,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                ],
              ).pOnly(top:10.0,bottom: 10.0),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: 30,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        TextWidget("Call Time",color: greyColor,
                          fontSize: 14,),

                        Container(
                          width: Get.width * 0.5,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 30.0,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        InkWell(
                          onTap: () async{
                            TimeOfDay? selectTime = await  CustomWidgets.pickTime(context);
                            if(selectTime != null) {
                              controller.selectTime.value =  selectTime.format(context).toString();
                              controller.currentTime.value = selectTime.format(context).toString();
                            }
                          },
                          child: Row(
                            children: [
                              TextWidget(controller.currentTime.value,fontSize: 14,
                                color: const Color(0xff2f3237),),
                              5.widthBox,
                              const Icon(Icons.access_time,size: 20,color:  Color(0xff7E8494),),
                              const  Icon(Icons.keyboard_arrow_down_outlined,size: 20,color:  Color(0xff7E8494),)
                            ],
                          ),
                        ),

                        Container(
                          width: Get.width * 0.4,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                ],
              ).pOnly(top:10.0,bottom: 10.0),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: 30,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        TextWidget("Type of Call",color: greyColor,
                          fontSize: 14,),

                        Container(
                          width: Get.width * 0.5,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 30.0,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        InkWell(
                          onTap:(){
                            CustomWidgets.customBottomSheet(controller.callTypeList, "NAME",false, (data){
                              log("Type of Call :$data");
                              controller.selectCallType.value = data['NAME'];
                              controller.selectCallTypeId.value = data['ID'];
                              Get.back();
                            });

                          },
                          child: Row(children: [
                            TextWidget(controller.selectCallType.value,fontSize: 14,color: const Color(0xff2f3237),),
                            5.widthBox,
                            const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                          ],),
                        ),

                        Container(
                          width: Get.width * 0.4,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                ],
              ).pOnly(top:10.0,bottom: 10.0),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: 30,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        TextWidget("Nature of Call",color: greyColor,
                          fontSize: 14,),

                        Container(
                          width: Get.width * 0.5,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 30.0,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        InkWell(
                          onTap:(){
                            CustomWidgets.customBottomSheet(controller.fNatureOfCall, "NAME",true, (data){
                              controller.selectNoc.value = data['NAME'];
                              controller.selectNocId.value =  data['ID'];
                              Get.back();
                            });


                          },
                          child: Row(children: [
                            SizedBox(
                                width:130,
                                child: TextWidget(controller.selectNoc.value,fontSize: 14,color: const Color(0xff2f3237),textAlign: TextAlign.right,)),
                            5.widthBox,
                            const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                          ],),
                        ),

                        Container(
                          width: Get.width * 0.4,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                ],
              ).pOnly(top:10.0,bottom: 10.0),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: 30,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        TextWidget("Allocation Manager",color: greyColor,
                          fontSize: 14,),

                        Container(
                          width: Get.width * 0.5,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 30.0,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        InkWell(
                          onTap:(){
                            CustomWidgets.customBottomSheet(controller.allocationManagerList, "NAME",false, (data){
                              controller.selectManager.value = data['NAME'];
                              controller.selectManagerId.value = data['ID'];
                              controller.selectUser.value = "Select";
                              Get.back();
                            });
                            // showMenu(context: context,
                            //   position: const RelativeRect.fromLTRB(700.0, 300.0, 10.0, 0), items: controller.allocationManagerList.map((data) {
                            //     return  PopupMenuItem<dynamic>(
                            //       onTap: (){
                            //         controller.selectManager.value = data;
                            //       },
                            //       child: TextWidget(data,fontSize: 14,),
                            //
                            //
                            //
                            //     );
                            //   }).toList(),
                            // );

                          },
                          child: Row(children: [
                            TextWidget(controller.selectManager.value,fontSize: 14,color: const Color(0xff2f3237),),
                            5.widthBox,
                            const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                          ],),
                        ),

                        Container(
                          width: Get.width * 0.4,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                ],
              ).pOnly(top:10.0,bottom: 10.0),
              controller.selectManager.value == "Sales" ?
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: 30,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        TextWidget("User",color: greyColor,
                          fontSize: 14,),

                        Container(
                          width: Get.width * 0.5,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 30.0,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        InkWell(
                          onTap:(){
                            CustomWidgets.customBottomSheet(controller.flUsersList, "NAME",true, (data){
                              controller.selectUser.value = data['NAME'];
                              Get.back();
                            });


                          },
                          child: Row(children: [
                            TextWidget(controller.selectUser.value,fontSize: 14,color: const Color(0xff2f3237),),
                            5.widthBox,
                            const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                          ],),
                        ),

                        Container(
                          width: Get.width * 0.4,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                ],
              ).pOnly(top:10.0,bottom: 10.0) : const SizedBox(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: 30,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        TextWidget("Support Type",color: greyColor,
                          fontSize: 14,),

                        Container(
                          width: Get.width * 0.5,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 30.0,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        InkWell(
                          onTap:(){
                            CustomWidgets.customBottomSheet(controller.supTypeList, "NAME",true, (data){

                              controller.selectSupType.value = data['NAME'];
                              controller.selectSupTypeId.value = data['ID'];
                              Get.back();
                            });


                          },
                          child: Row(children: [
                            TextWidget(controller.selectSupType.value,fontSize: 14,color: const Color(0xff2f3237),),
                            5.widthBox,
                            const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                          ],),
                        ),

                        Container(
                          width: Get.width * 0.4,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                ],
              ).pOnly(top:10.0,bottom: 10.0),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: 30,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        TextWidget("Location",color: greyColor,
                          fontSize: 14,),

                        Container(
                          width: Get.width * 0.5,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 30.0,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        InkWell(
                          onTap:(){
                            CustomWidgets.customBottomSheet(controller.addressList, "NAME",true, (data){
                              controller.selectAddress.value = data['NAME'];
                              controller.addressDetails.value = data['ADD'];
                              controller.selectPhone.value = data['PHONE'];
                              controller.selectRegion.value = data['CITY'];
                              Get.back();
                            });


                          },
                          child: Row(children: [
                            TextWidget(controller.selectAddress.value,fontSize: 14,color: const Color(0xff2f3237),),
                            5.widthBox,
                            const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                          ],),
                        ),

                        Container(
                          width: Get.width * 0.4,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                ],
              ).pOnly(top:10.0,bottom: 10.0),




              SizedBox(
                height: controller.selectPhone.value.isNotEmpty ? 56.0 : 30.0,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,

                  children: [
                    TextWidget("Phone",color: greyColor,
                      fontSize: 14,),
                    10.heightBox,
                    controller.selectPhone.value.isNotEmpty ?  Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        TextWidget(controller.selectPhone.value,fontSize: 14,color: greyColor,),
                        8.heightBox,

                      ],
                    ) : const SizedBox(),
                    Container(
                      width: Get.width * 0.9,
                      height: 1,
                      color: const Color(0xffBDC0CE),
                    ),

                  ],
                ),
              ).pOnly(top: 10.0,bottom: 10.0),
              SizedBox(
                height: controller.addressDetails.value.isNotEmpty ? 56.0 : 30.0,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,

                  children: [
                    TextWidget("Address",color: greyColor,
                      fontSize: 14,),
                    10.heightBox,
                    controller.addressDetails.value.isNotEmpty ?  Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        TextWidget(controller.addressDetails.value,fontSize: 14,color: greyColor,),
                        8.heightBox,

                      ],
                    ) : const SizedBox(),
                    Container(
                      width: Get.width * 0.9,
                      height: 1,
                      color: const Color(0xffBDC0CE),
                    ),

                  ],
                ),
              ).pOnly(top: 10.0,bottom: 10.0),

              SizedBox(
                height: controller.selectRegion.value.isNotEmpty ? 56.0 : 30.0,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,

                  children: [
                    TextWidget("Region",color: greyColor,
                      fontSize: 14,),
                    10.heightBox,
                    controller.selectRegion.value.isNotEmpty ?  Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        TextWidget(controller.selectRegion.value,fontSize: 14,color: greyColor,),
                        8.heightBox,

                      ],
                    ) : const SizedBox(),
                    Container(
                      width: Get.width * 0.9,
                      height: 1,
                      color: const Color(0xffBDC0CE),
                    ),

                  ],
                ),
              ).pOnly(top: 10.0,bottom: 10.0),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: 30,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        TextWidget("Tally Serial",color: greyColor,
                          fontSize: 14,),

                        Container(
                          width: Get.width * 0.5,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 30.0,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        InkWell(
                          onTap:(){
                            CustomWidgets.customBottomSheet(controller.tallySrNo, "NAME",true, (data){
                              log("Tally Serial :$data");
                              controller.selectTallySrNo.value = data['NAME'];
                              Get.back();
                            });


                          },
                          child: Row(children: [
                            SizedBox(
                                width:Get.width * 0.3,
                                child: TextWidget(controller.selectTallySrNo.value,fontSize: 14,color: const Color(0xff2f3237),)),
                            5.widthBox,
                            const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                          ],),
                        ),

                        Container(
                          width: Get.width * 0.4,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                ],
              ).pOnly(top:10.0,bottom: 10.0),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: 30,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        TextWidget("Contact Person",color: greyColor,
                          fontSize: 14,),

                        Container(
                          width: Get.width * 0.5,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 30.0,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        InkWell(
                          onTap:(){
                            CustomWidgets.customBottomSheet(controller.contactList, "CNTNAME",true, (data){

                              controller.selectContact.value = data['CNTNAME'];
                              controller.selectContactEmail.value = data['EMAIL'];
                              controller.selectContactMobile.value = data['MOBILE'];
                              controller.selectContactId.value = data['CNTID'];
                              Get.back();
                            });


                          },
                          child: Row(children: [
                            TextWidget(controller.selectContact.value,fontSize: 14,color: const Color(0xff2f3237),),
                            5.widthBox,
                            const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                          ],),
                        ),

                        Container(
                          width: Get.width * 0.4,
                          height: 1,
                          color: const Color(0xffBDC0CE),
                        ),
                      ],
                    ),
                  ),
                ],
              ).pOnly(top:10.0,bottom: 10.0),

              SizedBox(
                height: controller.selectContactEmail.value.isNotEmpty ? 56.0 : 30.0,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,

                  children: [
                    TextWidget("Email Id",color: greyColor,
                      fontSize: 14,),
                    10.heightBox,
                    controller.selectContactEmail.value.isNotEmpty ?  Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        TextWidget(controller.selectContactEmail.value,fontSize: 14,color: greyColor,),
                        8.heightBox,

                      ],
                    ) : const SizedBox(),
                    Container(
                      width: Get.width * 0.9,
                      height: 1,
                      color: const Color(0xffBDC0CE),
                    ),

                  ],
                ),
              ).pOnly(top: 10.0,bottom: 10.0),
              SizedBox(
                height: controller.selectContactEmail.value.isNotEmpty ? 56.0 : 30.0,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,

                  children: [
                    TextWidget("Mobile No",color: greyColor,
                      fontSize: 14,),
                    10.heightBox,
                    controller.selectContactMobile.value.isNotEmpty ?  Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        TextWidget(controller.selectContactMobile.value,fontSize: 14,color: greyColor,),
                        8.heightBox,

                      ],
                    ) : const SizedBox(),
                    Container(
                      width: Get.width * 0.9,
                      height: 1,
                      color: const Color(0xffBDC0CE),
                    ),

                  ],
                ),
              ).pOnly(top: 10.0,bottom: 10.0),


              RadioListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 1),
                value: 1, groupValue: controller.selectCheckCollection.value, onChanged: (int? value){


                controller.selectCheckCollection.value = value!;
              },
                title: TextWidget("Cheque Collection",fontSize: 18,color: greyColor,),),

              TextField(
                controller: controller.remarkController,
                decoration: const InputDecoration(
                    hintText: "Remark"


                ),
                maxLines: 5,
                minLines: 5,
              ),
              10.heightBox,
              CustomButton(text: "Save",onPressed: (){controller.checkData();},),
              10.heightBox,


            ],
          ).pSymmetric(h: 16.0,v: 8.0),
          controller.isLoading.value ?
          const LoadingScreen() : const SizedBox()
        ],
      )),
    );

  }
}


import 'package:karma/Constants/Library.dart';

class ContactDetails extends GetView<ContactDetailsController> {
  const ContactDetails({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(ContactDetailsController());
    return Scaffold(
      appBar: AppBarWidget(title: 'Contact Details',
      ),
      body: SizedBox(
        width: Get.width,
        height: Get.height,
        child: Obx(()=>Stack(
          children: [

            ListView(
                physics: const BouncingScrollPhysics(),
                children: List.generate(controller.contactList.length, (index) => tileWidget(controller.contactList[index]))
            ).p8(),
            controller.isLoading.value ?
            const  LoadingScreen(): const SizedBox(),
          ],
        ))
      ),
    );
  }

 Widget tileWidget(var data) {
    print("de:${data}");
    return Container(
      width:Get.width,


      decoration: shapeDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(

            children: [
              const Icon(Icons.person_outline_rounded).circle(radius: 50,backgroundColor: Colors.grey[200],),
              10.widthBox,
              TextWidget(
                data['CNTNAME'],
                color: titleColor,
                fontSize: 16,

                fontWeight: FontWeight.w500,

              ),
            ],
          ),

          Row(

            children: [
              CustomWidgets.showSvgImage(path: callIcon1),
              10.widthBox,
              InkWell(
                onTap: (){
                  Utilities.onClickMobile(data['MOBILE'].toString().trim());
                },
                child: GradientTextWidget(data['MOBILE'].trim(),
                    color: Colors.lightBlueAccent,
                    fontSize: 16,
                textDecoration: TextDecoration.underline,),
              ),
            ],
          ),
         
          Row(

            children: [
              Padding(
                padding: const EdgeInsets.only(left: 15.0),
                child: CustomWidgets.showAssetImage(path: mailBrochure),
              ),
              20.widthBox,
              InkWell(
                onTap:(){
                  Utilities.onClickEmail(data['Name'].toString().trim());
                },
                child: GradientTextWidget(data['Name'],

                    fontSize: 16,
                textDecoration: TextDecoration.underline,),
              ),
            ],
          ),
          10.heightBox,


        ],
      ).p16(),
    ).p8();
 }
}

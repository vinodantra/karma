import 'package:karma/Constants/Library.dart';
import 'package:karma/Controller/createDataPointController.dart';

class CreateDataPoint extends GetView<CreateDataPointController> {
  const CreateDataPoint({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(CreateDataPointController());
    return Scaffold(
      appBar: AppBarWidget(
        title: "Create Data Point",
      ),
      body: SizedBox(
          width: Get.width,
          height: Get.height,
          child: Obx(()=>SizedBox(
            width: Get.width,
            height: Get.height,
            child: ListView(
              children: [
                Container(
                  width: Get.width,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      side:
                      const BorderSide(width: 1, color: Color(0xFFDFDFDF)),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    shadows: const [
                      BoxShadow(
                        color: Color(0x14919191),
                        blurRadius: 12,
                        offset: Offset(0, 2),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextWidget(
                       Utilities.checkString(controller.selectLead.value) ? controller.selectLead.value : "Lead Source",
                        color: blackColor,
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                      ),
                      const Icon(Icons.keyboard_arrow_down_rounded)
                    ],
                  ).pSymmetric(h: 20.0, v: 10.0),
                ).onInkTap(() {
                  CustomWidgets.customBottomSheet(controller.lead, "SOURCE",false, (data){

                    controller.selectLead.value = data['SOURCE'];
                    controller.selectLeadId.value = data['ID'];
                    Get.back();
                  });
                }),
                10.heightBox,
                textField(
                    controller: controller.companyName,
                    hintText: "Company Name"),
                10.heightBox,
                SizedBox(
                  width: Get.width * 0.9,
                  child: const Text.rich(
                    TextSpan(
                      children: [
                        TextSpan(
                          text: '*',
                          style: TextStyle(
                            color: Color(0xFFFF1313),
                            fontSize: 10,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        TextSpan(
                          text:
                          'Please double check the provided company name. Once saved, it can’t be altered again in future.',
                          style: TextStyle(
                            color: Color(0xFF7D8493),
                            fontSize: 10,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                textField(
                    controller: controller.companyWebsite,
                    hintText: "Company Website",
                    prefix: SizedBox(
                      width: 80,
                      height: 20,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          TextWidget(
                            "https://",
                            color: blackColor,
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                          ),
                          10.widthBox,
                          CustomWidgets.divider(height: 20.0, width: 1.0),
                          10.widthBox,
                        ],
                      ).pOnly(bottom: 5.0),
                    )),
                20.heightBox,
                SizedBox(
                  width: Get.width,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextWidget(
                        "Select Salutation",
                        color: blackColor,
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                      ),

                      SizedBox(
                        width: Get.width,

                        child: Row(
                          children: [
                            SizedBox(
                              width:70,

                              child: ListTile(
                                onTap: (){
                                  controller.selectSalutation.value = 1;
                                },
                                leading: SizedBox(
                                  width:20,
                                  height: 20,
                                  child: Radio(value: 1,groupValue: controller.selectSalutation.value,
                                    onChanged: (value){
                                      controller.selectSalutation.value = int.parse(value.toString());
                                    },),
                                ),
                                minLeadingWidth: 1.0,
                                contentPadding: const EdgeInsets.all(1.0),

                                title: TextWidget("Mr."),),
                            ),
                            SizedBox(
                              width:70,

                              child: ListTile(
                                onTap: (){
                                  controller.selectSalutation.value = 2;
                                },
                                leading: SizedBox(
                                  width:20,
                                  height: 20,
                                  child: Radio(value: 2,groupValue: controller.selectSalutation.value,
                                    onChanged: (value){
                                      controller.selectSalutation.value = int.parse(value.toString());
                                    },),
                                ),
                                minLeadingWidth: 1.0,
                                contentPadding: const EdgeInsets.all(1.0),

                                title: TextWidget("Mrs."),),
                            ),
                            SizedBox(
                              width:70,

                              child: ListTile(
                                onTap: (){
                                  controller.selectSalutation.value = 3;
                                },
                                leading: SizedBox(
                                  width:20,
                                  height: 20,
                                  child: Radio(value: 3,groupValue: controller.selectSalutation.value,
                                    onChanged: (value){
                                      controller.selectSalutation.value = int.parse(value.toString());
                                    },),
                                ),
                                minLeadingWidth: 1.0,
                                contentPadding: const EdgeInsets.all(1.0),

                                title: TextWidget("Miss."),),
                            ),

                            SizedBox(
                              width:70,

                              child: ListTile(
                                onTap: (){
                                  controller.selectSalutation.value = 4;
                                },
                                leading: SizedBox(
                                  width:20,
                                  height: 20,
                                  child: Radio(value: 4,groupValue: controller.selectSalutation.value,
                                    onChanged: (value){
                                      controller.selectSalutation.value = int.parse(value.toString());
                                    },),
                                ),
                                minLeadingWidth: 1.0,
                                contentPadding: const EdgeInsets.all(1.0),

                                title: TextWidget("Smt."),),
                            ),
                            SizedBox(
                              width:70,

                              child: ListTile(
                                onTap: (){
                                  controller.selectSalutation.value = 5;
                                },
                                leading: SizedBox(
                                  width:20,
                                  height: 20,
                                  child: Radio(value: 5,groupValue: controller.selectSalutation.value,
                                    onChanged: (value){
                                      controller.selectSalutation.value = int.parse(value.toString());
                                    },),
                                ),
                                minLeadingWidth: 1.0,
                                contentPadding: const EdgeInsets.all(1.0),

                                title: TextWidget("Shree."),),
                            ),
                          ],
                        ),
                      ),

                    ],
                  ),
                ),
                textField(
                    controller: controller.contactName,
                    hintText: "Contact Name"),
                10.heightBox,
                textField(
                    controller: controller.designation,
                    hintText: "Designation"),
                10.heightBox,
                textField(
                    controller: controller.mobile,
                    hintText: "Mobile Number"),
                10.heightBox,
                textField(
                    controller: controller.email,
                    hintText: "Email"),
                10.heightBox,
                textField(
                    controller: controller.landlineNumber,
                    hintText: "Landline Number"),
                20.heightBox,
                SizedBox(
                  width: Get.width,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextWidget(
                        "Is Tally User?",
                        color: blackColor,
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                      ),

                      SizedBox(
                        width: Get.width,

                        child: Row(
                          children: [
                            SizedBox(
                              width:70,

                              child: ListTile(
                                onTap: (){
                                  controller.selectTallyUser.value = 1;
                                },
                                leading: SizedBox(
                                  width:20,
                                  height: 20,
                                  child: Radio(value: 1,groupValue: controller.selectTallyUser.value,
                                    onChanged: (value){
                                      controller.selectTallyUser.value = int.parse(value.toString());
                                    },),
                                ),
                                minLeadingWidth: 1.0,
                                contentPadding: const EdgeInsets.all(1.0),

                                title: TextWidget("Yes"),),
                            ),
                            SizedBox(
                              width:70,

                              child: ListTile(
                                onTap: (){
                                  controller.selectTallyUser.value = 2;
                                },
                                leading: SizedBox(
                                  width:20,
                                  height: 20,
                                  child: Radio(value: 2,groupValue: controller.selectTallyUser.value,
                                    onChanged: (value){
                                      controller.selectTallyUser.value = int.parse(value.toString());
                                    },),
                                ),
                                minLeadingWidth: 1.0,
                                contentPadding: const EdgeInsets.all(1.0),

                                title: TextWidget("No"),),
                            ),



                          ],
                        ),
                      ),
                      selectItem(title: Utilities.checkString(controller.selectEpicenter.value) ? controller.selectEpicenter.value : "Epicenter",onPressed: (){
                        CustomWidgets.customBottomSheet(controller.epicenter.value, "NAME",false, (data){

                          controller.selectEpicenter.value = data['NAME'];
                          controller.selectEpicenterId.value = data['ID'].toString();
                          Get.back();
                        });
                      }),
                      20.heightBox,
                      CustomButton(text: "Save",width: Get.width,onPressed: (){
                        controller.checkData();
                      },),
                      20.heightBox,

                    ],
                  ),
                ),
              ],
            ).p16(),
          ),)),
    );
  }
}

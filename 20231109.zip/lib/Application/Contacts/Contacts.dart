// ignore_for_file: file_names

import 'package:karma/Constants/Library.dart';



class Contacts extends GetView<ContactsController> {
  const Contacts({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(ContactsController());
    return Scaffold(
      appBar: AppBarWidget(title: "Contact Details",),
      body: Obx(()=>SizedBox(
        width: Get.width,
        height: Get.height,
        child: controller.isLoading.value == false ?
        Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            SearchWidget(
              onChanged: (value){
                controller.search.value = value!;
                controller.searchUser();
              },
              controller: controller.searchController,
              hintText: "Search",
              onClose: (){
                controller.searchController.clear();
                controller.search.value = "";
                controller.searchUser();
              },
            ),
            controller.contactList.isNotEmpty ?
            Expanded(
              child: Container(
                child: ListView.builder(

                    itemCount: controller.contactList.length,
                    itemBuilder: (context, index) {
                      return tileWidget(controller.contactList[index]);
                    }).p16(),
              ),
            ) :  TextWidget("No Data Found.",fontSize: 25,
            fontWeight: FontWeight.w500,).pOnly(top: 200)
          ],
        ) : const LoadingScreen()

      ),),
    );
  }

  tileWidget(var data){
    return Container(
      width: Get.width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        boxShadow: const [
          BoxShadow(
            color: Color(0x3f919191),
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
        color: Colors.white,
      ),
      child: Row(
        children: [
         Utilities.checkString(data['IMAGE']) ?
             CustomWidgets.profileImage(url:data['IMAGE'],radius: 25) :
         const CircleAvatar(
            child: Icon(Icons.person),
          ),
          10.widthBox,
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextWidget(
                  data['NAME'],
                  color:
                  const Color(0xff3d3d3d),
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
                5.heightBox,
                TextWidget(
                  data['DESIGNATION'],
                  maxLines: 2,
                  color: const Color(
                      0xff787878),
                  fontSize: 12,
                ),
              ],
            ),
          ),
          Row(
            children: [
              IconButton(onPressed: (){
                Utilities.onClickMobile(data['MOBILE'].toString().trim());
              }, icon: const Icon(Icons.call,size: 20,)),
              IconButton(onPressed: (){
                Utilities.onClickMessage(data['MOBILE'].toString().trim());
              }, icon: const Icon(Icons.message,size: 20,)),
              IconButton(onPressed: (){
                Utilities.onClickEmail(data['USEREMAIL'].toString().trim());
              }, icon: const Icon(Icons.email,size: 20,)),
            ],
          ),
        ],
      ).p16(),
    ).pSymmetric(v: 4.0);
  }
}
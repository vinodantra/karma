// ignore_for_file: file_names

import '../../Constants/Library.dart';


class LoginPage extends GetView<LoginController> {
  const LoginPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(LoginController());
    return Scaffold(

      body: Obx(()=>Stack(
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              TextWidget("Welcome to Karma",
                color: const Color(0xff2f3237),
                fontSize: 24,

                fontWeight: FontWeight.w700,
              ),
              // 10.heightBox,
              // TextWidget("Enter your phone number or email to sign in or Create a new account",
              //   textAlign: TextAlign.center,
              //   color: greyColor,
              //   fontSize: 14,
              //
              // ).paddingSymmetric(horizontal: 25.0),
              36.heightBox,
              CustomTextField(
                controller: controller.userNameController,
                label: "Enter your username",
                keyboardType: TextInputType.emailAddress,
                errorText: controller.userNameErrorText.value,
                textInputAction: TextInputAction.next,
              ),
              10.heightBox,
              CustomTextField(
                controller: controller.passwordController,
                label: "Enter your password",
                obscureText: controller.isShowPassword.value,
                keyboardType: TextInputType.visiblePassword,
                suffixIcon: IconButton(onPressed: (){
                  controller.isShowPassword.value =  !controller.isShowPassword.value;
                },
                  icon: Icon(Icons.remove_red_eye_outlined,color: controller.isShowPassword.value ? Colors.grey : primaryColor,),
                ),
                errorText: controller.passwordErrorText.value,
                textInputAction: TextInputAction.done,
                onSubmitted: (value){
                  controller.checkData();
                },
              ),

              10.heightBox,
              InkWell(
                onTap: (){
                  controller.isRemember.value = !controller.isRemember.value;
                },
                child: ColoredBox(
                  color:Colors.transparent,
                  child: Row(
                    children: [
                      SizedBox(
                        width: 20,
                        child: Checkbox(
                          onChanged: (val){
                            controller.isRemember.value = val!;

                          },
                          value: controller.isRemember.value,
                        ),
                      ),
                      10.widthBox,
                      TextWidget(
                        "Remember Me",
                      ),
                    ],
                  ),
                ),
              ),

              70.heightBox,
              CustomButton(
                onPressed: (){

                  controller.checkData();

                },
                text: "Log In",
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * 0.08,

              ),


            ],
          ).pSymmetric(h: 25.0),
          //controller.isLoading.value ? const LoadingScreen() : const SizedBox()
        ],
      ))
    );
  }
}

// ignore_for_file: file_names


import 'package:karma/Application/Dashboard/DashboardNew.dart';
import 'package:karma/Application/Profile/profile.dart';
import 'package:karma/Application/Support/Support.dart';

import '../../Constants/Library.dart';

class DrawerWidget extends StatelessWidget {
  const DrawerWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: Get.height,
      decoration:  BoxDecoration(
          gradient: LinearGradient(colors: appGradientColor.value)),
      child: Drawer(
        child: Container(
          height: Get.height,
          decoration:  BoxDecoration(
              gradient: LinearGradient(colors: appGradientColor.value)),
          child: Column(
            children: [
              Stack(
                children: [
                  SizedBox(
                    height: Get.height * 0.25,
                    width: Get.width,
                    child: Column(
                      children: [
                        Image.asset(
                          drawerImage,
                          fit: BoxFit.cover,
                          width: Get.width,
                          height: Get.height * 0.2,
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    bottom: 5,
                    left: 10,
                    child: InkWell(
                      onTap: (){
                        Get.to(()=> const Profile());
                      },
                      child: Row(
                        children: [
                          CustomWidgets.profileImage(url: "${WebApis.rootUrl}/crm/image/A${DataInfo.profileId.value.toString()}.jpeg"),
                          // "${WebApis.rootUrl}/crm/image/A${DataInfo.userId.value.toString()}.jpeg".circularNetworkImage(
                          //     bgColor: Colors.transparent, radius: 40),
                          10.widthBox,
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: 150,
                                child: TextWidget(
                                  "${DataInfo.username}",
                                  color: Colors.white,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w900,
                                  maxLines: 2,
                                ),
                              ),
                              25.heightBox,
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start ,
                                children: [
                                  TextWidget(
                                    "+91 ${DataInfo.mobile.trim()}",
                                    color: const Color(0xfff4f5f7),
                                    fontSize: 12,
                                  ),
                                  5.heightBox,
                                  TextWidget(
                                    DataInfo.email.trim(),
                                    color: const Color(0xfff4f5f7),
                                    maxLines: 2,
                                    fontSize: 12,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              Expanded(
                child: ListView(
                  children: [
                    tileWidget(
                        onTap: () {
                          Get.back();
                          Get.to(() => const DashboardNew());
                        },
                        title: "Home",
                        iconName: homeIcon),
                    // tileWidget(
                    //     onTap: () {}, title: "About Us", iconName: aboutUsIcon),
                    tileWidget(
                        onTap: () {
                          Get.back();
                          Get.to(()=>const EpicenterDetails());
                        }, title: "Epicenter", iconName: notesIcon),
                    tileWidget(
                        onTap: () {
                          Get.back();
                          Get.to(()=>const Reports());
                        },
                        title: "Operations",
                        iconName: walletIcon),
                    // tileWidget(
                    //     onTap: () {},
                    //     title: "Social Events",
                    //     iconName: socialEvent),
                    tileWidget(
                        onTap: () {
                          Get.back();
                          Get.to(()=>const Products());
                        }, title: "Products", iconName: cartIcon),
                    tileWidget(
                        onTap: () {
                          Get.back();
                          Get.to(()=>const TicketStatus());
                        },
                        title: "Ticket Status",
                        iconName: tagsIcon),
                    tileWidget(
                        onTap: () {
                          Get.back();
                          Get.to(()=>const Contacts());
                        },
                        title: "Contact List",
                        iconName: tagsIcon),
                      tileWidget(
                        onTap: () {
                          Get.back();
                          Get.to(()=>const Support());
                        }, title: "Support Availability", iconName: notesIcon),
                    // tileWidget(
                    //     onTap: () {
                    //
                    //
                    //       //Get.toNamed("/products");
                    //     }, title: "Support", iconName: supportIcon),
                    // tileWidget(
                    //     onTap: () {},
                    //     title: "Settings",
                    //     iconName: settingsIcon),
                  ],
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextWidget(
                    "App Version - V${DataInfo.appVersion.value}",
                    color: const Color(0xfff4f5f7),
                    fontSize: 12,
                  ),
                  InkWell(
                    onTap: () {
                      DataInfo.box.erase();
                      DataInfo.isSelectUser.value = true;
                      DataInfo.selectTheme.value = 1;
                      Get.offAll(() => const LoginPage());
                    },
                    child: TextWidget(
                      "Logout",
                      color: const Color(0xfff4f5f7),
                      fontSize: 12,
                    ),
                  ),
                ],
              ).pSymmetric(h: 25.0, v: 8.0),
            ],
          ),
        ),
      ),
    );
  }

  Widget tileWidget({String? title, String? iconName, Function()? onTap}) {
    return ListTile(
      onTap: onTap,
      leading: CustomWidgets.showImage(path: iconName!),
      minLeadingWidth: 1.0,
      title: TextWidget(
        title,
        color: const Color(0xfff4f5f7),
        fontSize: 14,
        fontWeight: FontWeight.w500,
      ),
    ).pOnly(left: 10.0);
  }
}

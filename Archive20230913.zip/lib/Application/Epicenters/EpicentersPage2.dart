
import 'dart:developer';



import '../../Constants/Library.dart';

class EpicentersPage2 extends GetView<EpicentersPage2Controller> {
  const EpicentersPage2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(EpicentersPage2Controller());
    return Scaffold(
      appBar: AppBarWidget(title: "Epicenters"),
      body: Obx(()=>Stack(
        children: [
          SizedBox(
            width: Get.width,
            height: Get.height,
            child: Column(
              children: [
                SearchWidget(controller: controller.search,
                  onChanged: (value){
                    controller.list.value = controller.listData.where((element) => element['DPNAME'].toString().toLowerCase().contains(value!.trim().toLowerCase())).toList();
                  },
                  hintText: "Search",
                  onClose: (){
                    controller.search.clear();
                    controller.list.value = controller.listData;
                  },

                ),
                Expanded(
                  child: ListView.builder(
                    shrinkWrap: true,
                      itemCount: controller.list.length,
                      itemBuilder: (context, index) {
                        return tileWidget(controller.list[index]);
                      }),
                ),
              ],
            ),

          ),
          controller.isLoading.value ? const LoadingScreen() : const SizedBox()
        ],
      )),
    );
  }

  tileWidget(var data){
    List<String> status = [];
    if(data['TNS'] == "Yes")
      {
        status.add("TNS");
      }
    if(data['ISTALLY'] == "Yes")
    {
      status.add("ISTALLY");
    }
    if(data['SB'] == "Yes")
      {
        status.add("SB");
      }
    if(data['AMC'] == "Yes")
    {
      status.add("AMC");
    }


   // var status = "${data['TNS'] == "Yes" ? "TNS":""}${data['ISTALLY'] == "Yes" ? "ISTALLY/":""}${data['SB'] == "Yes" ? "SB/":""}${data['AMC'] == "Yes" ? "AMC":""}";
    return InkWell(
      onTap: (){
        log(data.toString());
        Get.to(()=> EpicentersDetails2(data: data,));
      },
      child: Container(
        width: Get.width,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: const Color(0xffeaecf0), width: 1, ),
          color: Colors.white,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 247,
              child: TextWidget(
                data['DPNAME'],

                color: titleColor,
                fontSize:titleFontSize,

                fontWeight: titleFontWeight,

              ),
            ),

            10.heightBox,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextWidget("Owner",
                    color: descriptionColor,
                    fontSize: descriptionFontSize),
                TextWidget(data['ACCOWNER'].toString(),
                    color: descriptionColor,
                    fontSize: descriptionFontSize),
              ],
            ),
            10.heightBox,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextWidget("Status",
                    color: descriptionColor,
                    fontSize: descriptionFontSize),
                TextWidget(
                    status.join("/").toString(),
                    color: descriptionColor,
                    fontSize: descriptionFontSize),
              ],
            ),
            10.heightBox,
          ],
        ).p8(),
      ).pLTRB(8.0, 4.0, 8.0, 8.0),
    );
  }
}


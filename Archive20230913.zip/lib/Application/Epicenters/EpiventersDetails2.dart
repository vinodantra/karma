import 'dart:developer';

import 'package:karma/Constants/Library.dart';
class EpicentersDetails2 extends StatelessWidget {
  var data;
   EpicentersDetails2({Key? key,this.data}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    log(data.toString());
    return Scaffold(
      appBar: AppBarWidget(title: data['DPNAME'].toString()),
      body: SizedBox(
        width: Get.width,
        height: Get.height,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            title(title: "Account Owner",content: data['ACCOWNER']),
            title(title: "Company",content: data['DPNAME']),
            title(title: "Contact Name",content: data['CONTNAME1']),
            title(title: "Contact Number",content: data['CONTNAME1']),
            title(title: "Transferable",content: data['ALOCATE']),
            title(title: "AMC",content: data['AMC']),
            title(title: "ISTALLY",content: data['ISTALLY']),
            title(title: "SB",content: data['SB']),
            title(title: "TNS",content: data['TNS']),
            RichText(

                text: TextSpan(
              text: "Address : ",
              style: TextStyle(
                color: titleColor,
                fontSize:16,
                fontWeight: titleFontWeight,

              ),
              children: [
                TextSpan(
                  text: data['ADD1'].toString().trim(),
                  style: TextStyle(
                    color: descriptionColor,
                    fontSize:16,
                    fontWeight: titleFontWeight,
                  )
                )
              ]
            )).pSymmetric(h: 10.0,v: 10.0)
          ],
        ),
      ),
    );
  }
  title({String? title,String? content}){
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextWidget(
              title,

              color: titleColor,
              fontSize:16,

              fontWeight: titleFontWeight,

            ),
            SizedBox(
              width: Get.width / 2,
              child: Align(
                alignment: Alignment.centerRight,
                child: TextWidget(
                  content,

                  color: descriptionColor,
                  fontSize:16,
                  maxLines: 5,
                 // textAlign: TextAlign.right,
                  fontWeight: titleFontWeight,

                ),
              ),
            ),
          ],
        ),
        10.heightBox,
        CustomWidgets.divider(),
      ],
    ).paddingSymmetric(horizontal: 10.0,vertical: 10.0);
  }

}

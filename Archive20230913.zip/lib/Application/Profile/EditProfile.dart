import '../../Constants/Library.dart';
import '../../Controller/profileController.dart';
class EditProfile extends GetView<ProfileController> {
  const EditProfile({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(ProfileController());
    return Scaffold(
      appBar: AppBarWidget(
        title: "Edit Personal Details",
      ),
      body: SizedBox(
        width: Get.width,
        height: Get.height,
        child: Obx(()=>Stack(
          children: [
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextWidget("Full Name:",fontSize: 14,color: Colors.black,),
                    SizedBox(
                      width: Get.width / 2,
                      child: TextField(
                        controller: controller.fullName,

                      ),
                    )
                  ],
                ),
                10.heightBox,
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextWidget("Designation:",fontSize: 14,color: Colors.black,),
                    SizedBox(
                      width: Get.width / 2,
                      child: TextField(
                        controller: controller.designation,

                      ),
                    )
                  ],
                ),
                20.heightBox,
                CustomButton(text: "Update",onPressed: (){controller.updateData();},)
              ],
            ).p16(),
            controller.isLoading.value ? const LoadingScreen() : const SizedBox(),
          ],
        ),)
      ),
    );
  }
}

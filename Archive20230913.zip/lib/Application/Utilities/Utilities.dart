

import 'package:encrypt/encrypt.dart' as en;
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:karma/Constants/Library.dart';




class Utilities {
  static bool checkString(String value) {
    if (value == null ||
        value == "null" ||
        value == "NULL" ||
        value.isEmpty ||
        value == "") {
      return false;
    }
    return true;
  }

  static Future<String> encryptData({@required String? data}) async{
    final key = en.Key.fromUtf8(DataInfo.encryptionKey.value);
    final iv = en.IV.fromLength(16);

    final encryptor = en.Encrypter(en.AES(key));

    final encrypted = encryptor.encrypt(data!, iv: iv);

    return encrypted.base64;
  }





  static dynamic decryptData({@required dynamic data}){

    final key = en.Key.fromUtf8(DataInfo.encryptionKey.value);
    final iv = en.IV.fromLength(16);

    final encryptor = en.Encrypter(en.AES(key,mode: en.AESMode.ecb));


    final decrypted = encryptor.decrypt64(data!, iv: iv);
    return decrypted;
  }


  static speak()async{
    FlutterTts flutterTts = FlutterTts();
    await flutterTts.speak("${greeting()} ${DataInfo.fullName}");

  }
 static String greeting() {
    var hour = DateTime.now().hour;
    if (hour < 12) {
      return 'Good Morning';
    }
    if (hour < 17) {
      return 'Good Afternoon';
    }
    return 'Good Evening';
  }
  static void onClickLink(String url) async{
    if (!await launchUrl(Uri.parse(url.toString()))) {
    throw Exception('Could not launch $url');
    }
  }
  static void onClickMobile(String mobile) async{
    if (!await launchUrl(Uri.parse('tel://$mobile'))) {
      throw Exception('Could not launch $mobile');
    }
    //launch('tel://$mobile');
  }
  static void onClickEmail(String email) async{
    if (!await launchUrl(Uri.parse('mailto:$email'))) {
      throw Exception('Could not launch $email');
    }
  //  launch('mailto:$email');
  }
  static void onClickMessage(String mobile) async{
    if (!await launchUrl(Uri.parse('sms:+91 $mobile?body='))) {
      throw Exception('Could not launch $mobile');
    }
   // launch('sms:+91 $mobile?body=');
  }
  static void onGoogleMap(String lat,String log)
  {
    launch('geo:$lat,$log');
  }
  static Future<LocationData> getLocation()async{
    Location location =  Location();

    bool _serviceEnabled;
    PermissionStatus _permissionGranted;
    late LocationData? _locationData;

    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
      if (!_serviceEnabled) {

      }
    }

    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted == PermissionStatus.granted) {
        _locationData = await location.getLocation();
      }
    }
    else
      {
        _locationData = await location.getLocation();
      }


    return _locationData!;
  }

  static getPackageInfo()async{
    PackageInfo packageInfo = await PackageInfo.fromPlatform();

    DataInfo.appVersion.value = packageInfo.version;
    // String appName = packageInfo.appName;
    // String packageName = packageInfo.packageName;
    // String version = packageInfo.version;
    // String buildNumber = packageInfo.buildNumber;
    // log("app details:${version}");
  }
 static dynamic decodeResponse(String data){
    try{
      return json.decode(data);
    }catch(e){
      return data;
    }
  }

 static getUserLocation() async {

    LocationData? myLocation;
    String error;
    Location location =  Location();
    try {
      myLocation = await location.getLocation();
    } on PlatformException catch (e) {
      if (e.code == 'PERMISSION_DENIED') {
        error = 'please grant permission';

      }
      if (e.code == 'PERMISSION_DENIED_NEVER_ASK') {
        error = 'permission denied- please enable it from app settings';

      }
      myLocation = null;
    }

   // List<geoLocation.Placemark> placemarks = await geoLocation.placemarkFromCoordinates(myLocation!.latitude!, myLocation.longitude!);

   // print('${placemarks.first}, ${placemarks.first.locality}, ${placemarks.first.subLocality}, ${placemarks.first.thoroughfare}, ${placemarks.first.subThoroughfare}');
  }

  static getAddressFromLatLng(double lat, double lng) async {
    String _host = 'https://maps.google.com/maps/api/geocode/json';
    final url = '$_host?key=${DataInfo.apiKey}&language=en&latlng=$lat,$lng';
    if(lat != null && lng != null){
      var response = await http.get(Uri.parse(url));
      if(response.statusCode == 200) {
        Map data = jsonDecode(response.body);
        String _formattedAddress = data["results"][0]["formatted_address"];
        print("response ==== $_formattedAddress");
        return _formattedAddress;
      } else return null;
    } else return null;
  }

}


extension Check on bool {

  static bool data(dynamic value){
    if(value  is String)
      {
        if(value != "null" && value.isNotEmpty)
          {
            return true;
          }
        else
          {
            return false;
          }
      }
    else if(value is List)
      {
        return value.isNotEmpty ? true : false;
      }
    else if(value is Map)
      {

        return value.isNotEmpty ? true : false;
      }
    else
      {

        return value != null ? true : false;
      }
  }


}


import '../../Constants/Library.dart';
import '../../Controller/ticketDetailsController.dart';
class TicketStatusDetails extends GetView<TicketDetailsController> {
  const TicketStatusDetails({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(TicketDetailsController());
    return Scaffold(
      appBar: AppBarWidget(title: "Details",),
      body: SizedBox(
        width: Get.width,
        height: Get.height,
        child: Obx(()=> controller.isLoading.value  == false ?

         ListView(
          children: [
            TextWidget(controller.ticketData['number'],fontSize: 16,fontWeight: FontWeight.w500,),
            10.heightBox,
            Column(
              children: List.generate(controller.interactionList.length, (index) => Container(
                width: Get.width,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: const Color(0xffeaecf0), width: 1, ),
                  color: Colors.white,
                ),
                child: Column(
                  children: [
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TextWidget("Interaction ${controller.interactionList[index]['int_no']}",
                        fontSize: 16,
                          color: appColor.value,
                          fontWeight: FontWeight.w500,
                        ),
                        TextWidget("${controller.interactionList[index]['date']}",
                          fontSize: 14,
                          color: Colors.grey[400],

                        ),
                      ],
                    ),
                    10.heightBox,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TextWidget("Subject :",fontSize: 16,),

                        TextWidget(controller.interactionList[index]['subject'].toString(),
                        fontSize: 16,
                          color: Colors.grey[400],
                        ),
                      ],
                    ),
                    10.heightBox,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TextWidget("Description :",fontSize: 16,),
                        SizedBox(
                          width: 200,
                          child: TextWidget(controller.interactionList[index]['desc'].toString(),
                            textAlign: TextAlign.right,
                            fontSize: 16,
                            color: Colors.grey[400],
                            maxLines: 5,
                          ),
                        ),
                      ],
                    ),
                  ],
                ).p16(),
              ).pSymmetric(v: 4.0))
            ),
          ],
        ).p16() : const LoadingScreen(),)
      ),
    );
  }
}

import 'package:karma/Constants/Library.dart';
import 'package:karma/Controller/tickerDetailsController1.dart';
class TicketDetails extends GetView<TicketDetailsController1> {
  const TicketDetails({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(TicketDetailsController1());
    return Scaffold(
      appBar: AppBarWidget(
        title: "Ticket Details",
      ),
      body: Obx(()=>SizedBox(
        width: Get.width,
        height: Get.height,
        child: Stack(
          children: [
            controller.interactionList.isNotEmpty ?  ListView.builder(
            itemCount: controller.interactionList.length,
            itemBuilder: (context,int index){
              return tile(controller.interactionList[index]);}).p16() : const SizedBox(),
            controller.isLoading.value ? const LoadingScreen() : const SizedBox(),
            controller.isLoading.value == false  && controller.interactionList.isEmpty  ?  Center(
              child: TextWidget("No data found.",
              fontSize: 25,color: Colors.black,fontWeight: FontWeight.w500,),
            ) : const SizedBox(),


          ],
        )
      ),)
    );
  }
  Widget tile(var data){
    return Container(
      width: Get.width,

      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        boxShadow: const [
          BoxShadow(
            color: Color(0x3f919191),
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              TextWidget("Interaction ${data['int_no']}",fontSize: 18,color: appColor.value,fontWeight: FontWeight.w500,),
              TextWidget("${data['date']}",fontSize: 16,color: Colors.grey[500],fontWeight: FontWeight.w500,),
            ],
          ),
          5.heightBox,
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextWidget("Subject",fontSize: 14,color: Colors.black,fontWeight: FontWeight.w500,),
              10.widthBox,
              SizedBox(
                  width: Get.width * 0.6,
                  child: TextWidget("${data['subject'].trim()}",fontSize: 14,color: Colors.grey[500],fontWeight: FontWeight.w500,maxLines: 5,)),
            ],
          ),
          5.heightBox,
         Utilities.checkString(data['desc'])  ?
         Column(
           crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextWidget("Description",fontSize: 14,color: Colors.black,fontWeight: FontWeight.w500,),
              5.heightBox,
              SizedBox(
                  width: Get.width * 0.85,
                  child: TextWidget("${data['desc'].trim()}",fontSize: 14,color: Colors.grey[500],fontWeight: FontWeight.w500,
                    maxLines: 50,)),
              5.heightBox,
            ],
          ) : const SizedBox(),


        ],
      ).p8(),
    ).pSymmetric(v: 4.0);
  }
}

import 'package:karma/Application/TicketStatus/TicketStatusDetails.dart';
import 'package:karma/Constants/Library.dart';


class TicketStatus extends GetView<TicketStatusController> {
  const TicketStatus({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(TicketStatusController());
    return Scaffold(
      appBar: AppBarWidget(title: "Ticket Status",),
      body: Obx(()=>SizedBox(
        width: Get.width,
        height: Get.height,
        child: controller.ticketList.isNotEmpty ?
        ListView.builder(
            itemCount: controller.ticketList.length,
            itemBuilder: (context, index) {
              return tileWidget(controller.ticketList[index]);
            }) :   controller.isLoading.value ? const  LoadingScreen() :   const ValidationWidget(),

      ),),
    );
  }

  tileWidget(var data){
    return InkWell(
      onTap: (){
        Get.to(()=> const TicketStatusDetails(),arguments: data);
      },
      child: Container(
        width: Get.width,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: const Color(0xffeaecf0), width: 1, ),
          color: Colors.white,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                  width: 247,
                  child: TextWidget(
                    data['NAME'],

                    color: titleColor,
                    fontSize:titleFontSize,

                    fontWeight: titleFontWeight,

                  ),
                ),
                TextWidget(data['STATUS'].toString(),
                    color: descriptionColor,
                    fontSize: descriptionFontSize),
              ],
            ),
            10.heightBox,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextWidget(data['TICKET'],
                    color: descriptionColor,
                    fontSize: descriptionFontSize),
                TextWidget(data['DATE'].toString(),
                    color: descriptionColor,
                    fontSize: descriptionFontSize),
              ],
            ),
            10.heightBox,
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                TextWidget("Contact Person",
                    color: descriptionColor,
                    fontSize: descriptionFontSize),
                // TextWidget(data['OWN'].toString(),
                //     color: descriptionColor,
                //     fontSize: descriptionFontSize),
              ],
            ),
            10.heightBox,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextWidget("Supported By",
                    color: descriptionColor,
                    fontSize: descriptionFontSize),
                TextWidget(data['CREATEDBY'].toString(),
                    color: descriptionColor,
                    fontSize: descriptionFontSize),
              ],
            ),
            10.heightBox,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextWidget("Last Interaction",
                    color: descriptionColor,
                    fontSize: descriptionFontSize),
                TextWidget(data['LASTINTDT'].toString(),
                    color: descriptionColor,
                    fontSize: descriptionFontSize),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    IconButton(onPressed: (){

                      CustomWidgets.showDialog(title: "Description",content: data['DESC']);
                    }, icon: const Icon(Icons.copy)),
                    IconButton(onPressed: (){
                      Get.bottomSheet(Obx(()=>Container(
                        height: 350,
                        decoration: const BoxDecoration(
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(36.0), topRight: Radius.circular(36.0)),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f929292),
                              blurRadius: 27,
                              offset: Offset(0, -4),
                            ),
                          ],
                          color: Colors.white,
                        ),
                        child: Column(
                          children: [
                            TextWidget("Update Ticket Status",fontSize: 20,fontWeight: FontWeight.w500,).p12(),
                            Expanded(
                              child: Scrollbar(
                                thickness: 5.0,
                                child: ListView(
                                  shrinkWrap: true,
                                  children: List.generate(controller.ticketStatus.length, (index) => ListTile(
                                    onTap: (){
                                      controller.selectTicketStatus.value = controller.ticketStatus[index]['NAME'];
                                      controller.selectTicketStatusId.value = controller.ticketStatus[index]['ID'];
                                    },
                                    title: TextWidget(controller.ticketStatus[index]['NAME'],fontSize: 16,),
                                    trailing: controller.selectTicketStatus.value == controller.ticketStatus[index]['NAME'] ? Icon(Icons.check) : SizedBox(),
                                  )),

                                ),
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                TextButton(onPressed: (){
                                  controller.selectTicketStatus.value = "";
                                  Get.back();
                                }, child: const Text("Cancel")),
                                CustomButton(text: "Save",onPressed: (){
                                  controller.updateStatus(data['TICKET'], controller.selectTicketStatusId.value);
                                  Get.back();
                                  controller.selectTicketStatusId.value = "";
                                },),
                              ],
                            ).pSymmetric(h: 20.0,v: 10.0),
                          ],
                        ),
                      )));
                    }, icon: const Icon(Icons.edit)),
                  ],
                ),
                Utilities.checkString(data['TCKSTATUS']) ? TextWidget(controller.ticketStatus[int.parse(data['TCKSTATUS'])]['NAME'],
                fontSize: 16,color: appColor.value,) : const SizedBox(),
              ],
            ),

          ],
        ).p8(),
      ).pLTRB(8.0, 4.0, 8.0, 8.0),
    );
  }
}
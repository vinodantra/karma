import 'package:flutter_html/flutter_html.dart';

import '../../Constants/Library.dart';
class ProductDetails extends StatelessWidget {
  var data;
   ProductDetails({Key? key,this.data}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarWidget(title: data['MODULENAME'],),
      body: SizedBox(
        width: Get.width,
        height: Get.height,
        child: Html(
          data: data['DESCR'],
        )
      ),
    );
  }
}

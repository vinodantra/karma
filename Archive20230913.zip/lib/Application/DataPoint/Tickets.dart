import 'package:karma/Application/TicketStatus/TickerDetails.dart';
import 'package:karma/Constants/Library.dart';

class Tickets extends GetView<TicketController> {
  const Tickets({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(TicketController());
    return Scaffold(
      appBar: AppBarWidget(
        title: "Tickets",
      ),
      body: Obx(()=>Stack(
        children: [

          SizedBox(
              width: Get.width,
              height: Get.height,
              child:Column(
                children: [
                  SearchWidget(
                    controller: controller.searchController,
                    hintText: "Search",
                    onChanged: (value){

                      controller.search.value = value!;

                      controller.filterDataList();

                    },
                    onClose: (){
                      FocusManager.instance.primaryFocus?.unfocus();
                      controller.searchController.clear();
                      controller.search.value = "";

                      controller.onInit();
                    },),
                  controller.list.isNotEmpty ?
                  Expanded(
                    child: ListView.builder(
                        itemCount: controller.list.length,
                        itemBuilder: (context,index ){return tile(controller.list[index],index);}),
                  ) : controller.isLoading.value == false ?
                  Center(child: TextWidget("No data found",fontSize: 20,fontWeight: FontWeight.w500,)) : const SizedBox()
                ],
              ),
          ),
          controller.isLoading.value ? const LoadingScreen() : const SizedBox(),
        ],
      )),
    );
  }

  Widget tile(var data,int i,){
    return GetBuilder<TicketController>(builder: (dashboardController){
      return InkWell(
        onTap:(){

         Get.to(()=> const TicketDetails(),arguments:controller.list[i]['TICKET']);
        },
        child: Container(
          width:Get.width,


          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: const Color(0xffeaecf0), width: 1, ),
            color: Colors.white,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextWidget(
                    data['TICKET'],

                    color: appColor.value,
                    fontSize: 18,

                    fontWeight: FontWeight.w500,

                  ),
                  TextWidget(
                    data['STATUS'],

                    color: const Color(0xff344053),
                    fontSize: 14,

                    fontWeight: FontWeight.w500,

                  ),

                ],
              ),
              5.heightBox,
              Container(
                width: Get.width,
                height: 1.0,
                color: Colors.grey[300],
              ).pOnly(bottom: 10.0),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextWidget(
                    "Date",

                    color: const Color(0xff344053),
                    fontSize: 14,

                    fontWeight: FontWeight.w500,

                  ),
                  TextWidget(
                    data['DATE'],

                    color: const Color(0xff344053),
                    fontSize: 14,

                    fontWeight: FontWeight.w500,

                  ),
                ],
              ),
              10.heightBox,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,


                children: [
                  TextWidget(
                    "Contact Person",

                    color: const Color(0xff344053),
                    fontSize: 14,

                    fontWeight: FontWeight.w500,

                  ),
                  TextWidget(
                    data['CNTPER'],

                    color: const Color(0xff344053),
                    fontSize: 14,

                    fontWeight: FontWeight.w500,

                  ),
                ],
              ),
              10.heightBox,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextWidget(
                    "Category",

                    color: const Color(0xff344053),
                    fontSize: 14,

                    fontWeight: FontWeight.w500,

                  ),
                  TextWidget(
                    data['CAT'],

                    color: const Color(0xff344053),
                    fontSize: 14,

                    fontWeight: FontWeight.w500,

                  ),
                ],
              ),
              10.heightBox,
              Row(

                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextWidget(
                    "Supported By",

                    color: const Color(0xff344053),
                    fontSize: 14,

                    fontWeight: FontWeight.w500,

                  ),
                  TextWidget(
                    data['CREATEDBY'],
                    maxLines: 5,
                    color: const Color(0xff344053),
                    fontSize: 14,

                    fontWeight: FontWeight.w500,

                  ),
                ],
              ),
              10.heightBox,



            ],
          ).p16(),
        ).p8(),
      );
    });
  }
}

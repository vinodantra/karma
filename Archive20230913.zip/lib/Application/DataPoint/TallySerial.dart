
import 'package:karma/Constants/Library.dart';


class TallySerial extends GetView<TallySerialController> {
  const TallySerial({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(TallySerialController());
    return Scaffold(
      appBar: AppBarWidget(
        title: "Tally Serial",
      ),
      body: Obx(()=>Stack(
        children: [
          SizedBox(
              width: Get.width,
              height: Get.height,
              child: controller.tallySerialList.isNotEmpty ?
              ListView.builder(
                  itemCount: controller.tallySerialList.length,
                  itemBuilder: (context,index ){return tile(controller.tallySerialList[index],index);}) : controller.isLoading.value == false ?
              Center(child: TextWidget("No data found",fontSize: 20,fontWeight: FontWeight.w500,)) : const SizedBox()
          ),
          controller.isLoading.value ? const LoadingScreen() : const SizedBox(),
        ],
      )),
    );
  }
  Widget tile(var data,int i,){
    return GetBuilder<TallySerialController>(builder: (dashboardController){
      return InkWell(
        onTap:(){

        },
        child: Container(
          width:Get.width,


          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: const Color(0xffeaecf0), width: 1, ),
            color: Colors.white,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: 247,
                    child: TextWidget(
                      data['MULTIUSER'],

                      color: appColor.value,
                      fontSize: 18,

                      fontWeight: FontWeight.w500,

                    ),
                  ),

                ],
              ),
              5.heightBox,
              Container(
                width: Get.width,
                height: 1.0,
                color: Colors.grey[300],
              ).pOnly(bottom: 10.0),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextWidget(
                    "Serial Number",

                    color: const Color(0xff344053),
                    fontSize: 14,

                    fontWeight: FontWeight.w500,

                  ),
                  TextWidget(
                    data['NAME'],

                    color: const Color(0xff344053),
                    fontSize: 14,

                    fontWeight: FontWeight.w500,

                  ),
                ],
              ),
              10.heightBox,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,


                children: [
                  TextWidget(
                    "Location",

                    color: const Color(0xff344053),
                    fontSize: 14,

                    fontWeight: FontWeight.w500,

                  ),
                  TextWidget(
                    data['LOCATION'],

                    color: const Color(0xff344053),
                    fontSize: 14,

                    fontWeight: FontWeight.w500,

                  ),
                ],
              ),
              10.heightBox,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: 247,
                    child: TextWidget(
                      "TNS DATE",

                      color: const Color(0xff344053),
                      fontSize: 14,

                      fontWeight: FontWeight.w500,

                    ),
                  ),
                  TextWidget(
                    data['TNSDT'],

                    color: const Color(0xff344053),
                    fontSize: 14,

                    fontWeight: FontWeight.w500,

                  ),
                ],
              ),
              10.heightBox,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: 247,
                    child: TextWidget(
                      "ASC DATE",

                      color: const Color(0xff344053),
                      fontSize: 14,

                      fontWeight: FontWeight.w500,

                    ),
                  ),
                  TextWidget(
                    data['ASCDT'],

                    color: const Color(0xff344053),
                    fontSize: 14,

                    fontWeight: FontWeight.w500,

                  ),
                ],
              ),
              10.heightBox,



            ],
          ).p16(),
        ).p8(),
      );
    });
  }
}

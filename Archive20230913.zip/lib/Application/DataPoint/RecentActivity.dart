import 'package:karma/Constants/Library.dart';

class RecentActivity extends GetView<RecentActivityController> {
  const RecentActivity({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(RecentActivityController());
    return Scaffold(
      appBar: AppBarWidget(
        title: "Recent Activity",
      ),
      body: Obx(()=>Stack(
        children: [
          SizedBox(
            width: Get.width,
            height: Get.height,
            child: ListView(
              children: List.generate(controller.activityList.length, (index) =>
                  Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextWidget(controller.activityList[index]['HSTTYPE'].toString(),
                    fontSize: 16,
                    color: appColor.value,
                    fontWeight: FontWeight.w500,),

                  10.heightBox,
                  TextWidget("Follwup Date",fontSize: 16,
                    color: Colors.black,fontWeight: FontWeight.w500,),
                  5.heightBox,
                  TextWidget(controller.activityList[index]['FLWDATE'].toString(),
                    fontSize: 16,
                    color: Colors.black,),
                  10.heightBox,
                  TextWidget("Regarding",fontSize: 16,
                    color: Colors.black,fontWeight: FontWeight.w500,),
                  5.heightBox,
                  TextWidget(controller.activityList[index]['REGARDING'].toString(),
                    fontSize: 16,
                    color: Colors.black,),
                  10.heightBox,
                  TextWidget("Details",fontSize: 16,
                    color: Colors.black,fontWeight: FontWeight.w500,),
                  5.heightBox,
                  TextWidget(controller.activityList[index]['DETAILS'].toString(),
                    fontSize: 16,
                    color: Colors.black,),
                  10.heightBox,
                  Container(
                    width: Get.width,
                    height: 1.0,
                    color: Colors.grey[400],
                  ),

                ],
              ).p8()),
            ).p8(),
          ),
          controller.isLoading.value ? const LoadingScreen() : const SizedBox(),

        ],
      )),
    );
  }
}

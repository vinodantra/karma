

import 'package:karma/Constants/Library.dart';

class DataPoints extends GetView<DataPointController> {
  const DataPoints({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(DataPointController());

    return WillPopScope(
      onWillPop: () async{
        Get.back();
        //Get.offAll(()=> const Dashboard());
        return true;
      },
      child: Scaffold(
        appBar: AppBarWidget(title: "Data Points",
        onBackPress: (){
          Get.back();
        },
        // onPressAdd: (){
        //   Get.to(()=> const CreateDataPoint());
        // },
        ),
        body: SizedBox(

          height: Get.height,
          width: Get.width,
          child: Obx(()=>Stack(
            children: [
              Column(
                children: [
                  SearchWidget(
                    onChanged: (value){
                      controller.search.value = value!;
                      controller.searchUser();
                    },
                    controller: controller.searchController,
                    hintText: "Search datapoints",
                  ),
                  10.heightBox,
                  Expanded(
                    child: controller.dataPointList.isNotEmpty?
                    ListView.builder(
                        itemCount: controller.dataPointList.length,
                        itemBuilder: (context,int index){
                          return tileWidget(controller.dataPointList[index],index);
                        }) : !controller.isLoading.value  ?
                    const ValidationWidget() : const SizedBox(),
                  )
                ],
              ),
              controller.isLoading.value ?
              const  LoadingScreen(): const SizedBox(),
            ],
          ))
        ),
      ),
    );
  }

  Widget tileWidget(final data,final index) {
    return  InkWell(
      onTap: (){
        Get.to(()=> DataPointInfo(),arguments: data);
      },
      child: Container(
        width: Get.width,
        height: 50,
        decoration: ShapeDecoration(
          color: Colors.white,
          shape: RoundedRectangleBorder(
            side: BorderSide(width: 0.50, color: Color(0xFFDFDFDF)),
            borderRadius: BorderRadius.circular(8),
          ),
          shadows: [
            BoxShadow(
              color: Color(0x14919191),
              blurRadius: 12,
              offset: Offset(0, 2),
              spreadRadius: 0,
            )
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            TextWidget(
              data['DPNAME'],

              color: Color(0xFF282828),
              fontSize: 14,

              fontWeight: FontWeight.w400,

            ),
            CustomWidgets.showSvgImage(path: callIcon1,onPressed: ()async{
              var userData = await controller.getUserData(data['DPID']);

              if(userData != null)
              {
                Get.dialog(Center(
                  child: SizedBox(

                    width: Get.width * 0.8,
                    child: Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          GradientText("Contact Details",
                              style: TextStyle(
                                  fontSize: 18
                              ),
                              gradient: LinearGradient(
                                  colors: appGradientColor.value
                              )),
                          15.heightBox,
                          Container(
                            width: Get.width * 0.8,
                            height: 1.0,
                            color: appColor.value,
                          ),
                          15.heightBox,
                          Container(
                            constraints: BoxConstraints(
                              minHeight: Get.height * 0.1,
                              maxHeight: Get.height * 0.7,
                            ),
                            child: ListView(
                              shrinkWrap: true,
                              primary: true,
                              children: List.generate(userData.length, (index) => Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      TextWidget("Name:",fontSize: 16,color: appColor.value,),
                                      5.widthBox,
                                      TextWidget("${userData[index]['CNTNAME']}",

                                        fontSize: 16,),
                                    ],
                                  ).pOnly(bottom: 5.0),
                                  Row(
                                    children: [
                                      TextWidget("Mobile:",fontSize: 16,color: appColor.value,),
                                      5.widthBox,
                                      InkWell(
                                        onTap:(){
                                          Utilities.onClickMobile(userData[index]['MOBILE']);
                                        },
                                        child: TextWidget("${userData[index]['MOBILE']}",fontSize: 16,
                                          color: appColor.value,
                                          textDecoration: TextDecoration.underline,),
                                      ),
                                    ],
                                  ).pOnly(bottom: 5.0),
                                  Row(
                                    children: [
                                      TextWidget("Email:",fontSize: 16,color: appColor.value,),
                                      5.widthBox,
                                      InkWell(
                                          onTap:(){
                                            Utilities.onClickEmail(userData[index]['Name']);
                                          },
                                          child: TextWidget("${userData[index]['Name']}",fontSize: 16,color: appColor.value,
                                            textDecoration: TextDecoration.underline,)),
                                    ],
                                  ).pOnly(bottom: 5.0),

                                  5.heightBox,
                                  Container(
                                    width: Get.width * 0.75,
                                    height: 1.0,
                                    color: Color(0xffBDC0CE),
                                  ),
                                  5.heightBox,
                                ],
                              ).pOnly(bottom: 10.0)),
                            ),
                          ),
                          15.heightBox,
                          CustomButton(text: "Close",onPressed: (){Get.back();},)


                        ],
                      ).p16(),
                    ),
                  ),
                ));
              }
            }),


          ],
        ).pSymmetric(h: 10.0),


      ).pSymmetric(h: 8.0,v: 4.0),
    );


    //   Column(
    //   children: [
    //     InkWell(
    //       onTap: (){
    //         Get.to(()=> DataPointInfo(),arguments: data);
    //       },
    //       child: Container(
    //         width: Get.width,
    //         height: 50,
    //         decoration: ShapeDecoration(
    //           color: Colors.white,
    //           shape: RoundedRectangleBorder(
    //             side: BorderSide(width: 0.50, color: Color(0xFFDFDFDF)),
    //             borderRadius: BorderRadius.circular(8),
    //           ),
    //           shadows: [
    //             BoxShadow(
    //               color: Color(0x14919191),
    //               blurRadius: 12,
    //               offset: Offset(0, 2),
    //               spreadRadius: 0,
    //             )
    //           ],
    //         ),
    //         child: Row(
    //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
    //           children: [
    //             TextWidget(
    //               data['DPNAME'],
    //
    //                 color: Color(0xFF282828),
    //                 fontSize: 14,
    //
    //                 fontWeight: FontWeight.w400,
    //
    //               ),
    //             CustomWidgets.showSvgImage(path: callIcon1,onPressed: ()async{
    //               var userData = await controller.getUserData(data['DPID']);
    //
    //               if(userData != null)
    //               {
    //                 Get.dialog(Center(
    //                   child: SizedBox(
    //
    //                     width: Get.width * 0.8,
    //                     child: Card(
    //                       shape: RoundedRectangleBorder(
    //                         borderRadius: BorderRadius.circular(10.0),
    //                       ),
    //                       child: Column(
    //                         mainAxisSize: MainAxisSize.min,
    //                         children: [
    //                           GradientText("Contact Details",
    //                               style: TextStyle(
    //                                   fontSize: 18
    //                               ),
    //                               gradient: LinearGradient(
    //                                   colors: appGradientColor.value
    //                               )),
    //                           15.heightBox,
    //                           Container(
    //                             width: Get.width * 0.8,
    //                             height: 1.0,
    //                             color: appColor.value,
    //                           ),
    //                           15.heightBox,
    //                           Container(
    //                             constraints: BoxConstraints(
    //                               minHeight: Get.height * 0.1,
    //                               maxHeight: Get.height * 0.7,
    //                             ),
    //                             child: ListView(
    //                               shrinkWrap: true,
    //                               primary: true,
    //                               children: List.generate(userData.length, (index) => Column(
    //                                 crossAxisAlignment: CrossAxisAlignment.start,
    //                                 children: [
    //                                   Row(
    //                                     children: [
    //                                       TextWidget("Name:",fontSize: 16,color: appColor.value,),
    //                                       5.widthBox,
    //                                       TextWidget("${userData[index]['CNTNAME']}",
    //
    //                                         fontSize: 16,),
    //                                     ],
    //                                   ).pOnly(bottom: 5.0),
    //                                   Row(
    //                                     children: [
    //                                       TextWidget("Mobile:",fontSize: 16,color: appColor.value,),
    //                                       5.widthBox,
    //                                       InkWell(
    //                                         onTap:(){
    //                                           Utilities.onClickMobile(userData[index]['MOBILE']);
    //                                         },
    //                                         child: TextWidget("${userData[index]['MOBILE']}",fontSize: 16,
    //                                           color: appColor.value,
    //                                           textDecoration: TextDecoration.underline,),
    //                                       ),
    //                                     ],
    //                                   ).pOnly(bottom: 5.0),
    //                                   Row(
    //                                     children: [
    //                                       TextWidget("Email:",fontSize: 16,color: appColor.value,),
    //                                       5.widthBox,
    //                                       InkWell(
    //                                           onTap:(){
    //                                             Utilities.onClickEmail(userData[index]['Name']);
    //                                           },
    //                                           child: TextWidget("${userData[index]['Name']}",fontSize: 16,color: appColor.value,
    //                                             textDecoration: TextDecoration.underline,)),
    //                                     ],
    //                                   ).pOnly(bottom: 5.0),
    //
    //                                   5.heightBox,
    //                                   Container(
    //                                     width: Get.width * 0.75,
    //                                     height: 1.0,
    //                                     color: Color(0xffBDC0CE),
    //                                   ),
    //                                   5.heightBox,
    //                                 ],
    //                               ).pOnly(bottom: 10.0)),
    //                             ),
    //                           ),
    //                           15.heightBox,
    //                           CustomButton(text: "Close",onPressed: (){Get.back();},)
    //
    //
    //                         ],
    //                       ).p16(),
    //                     ),
    //                   ),
    //                 ));
    //               }
    //             }),
    //
    //
    //           ],
    //         ).pSymmetric(h: 10.0),
    //
    //
    //       ).pSymmetric(h: 8.0),
    //     ),
    //     ListTile(
    //       onTap: (){
    //
    //         Get.to(()=> DataPointInfo(),arguments: data);
    //       },
    //       title: TextWidget(data['DPNAME'],
    //       fontSize: 18,),
    //       trailing: CustomWidgets.showSvgImage(path: callIcon1,onPressed: ()async{
    //       var userData = await controller.getUserData(data['DPID']);
    //
    //         if(userData != null)
    //           {
    //             Get.dialog(Center(
    //               child: SizedBox(
    //
    //                 width: Get.width * 0.8,
    //                 child: Card(
    //                   shape: RoundedRectangleBorder(
    //                     borderRadius: BorderRadius.circular(10.0),
    //                   ),
    //                   child: Column(
    //                     mainAxisSize: MainAxisSize.min,
    //                     children: [
    //                        GradientText("Contact Details",
    //                           style: TextStyle(
    //                               fontSize: 18
    //                           ),
    //                           gradient: LinearGradient(
    //                               colors: appGradientColor.value
    //                           )),
    //                       15.heightBox,
    //                       Container(
    //                         width: Get.width * 0.8,
    //                         height: 1.0,
    //                         color: appColor.value,
    //                       ),
    //                       15.heightBox,
    //                       Container(
    //                         constraints: BoxConstraints(
    //                           minHeight: Get.height * 0.1,
    //                           maxHeight: Get.height * 0.7,
    //                         ),
    //                         child: ListView(
    //                           shrinkWrap: true,
    //                           primary: true,
    //                           children: List.generate(userData.length, (index) => Column(
    //                             crossAxisAlignment: CrossAxisAlignment.start,
    //                             children: [
    //                               Row(
    //                                 children: [
    //                                   TextWidget("Name:",fontSize: 16,color: appColor.value,),
    //                                   5.widthBox,
    //                                   TextWidget("${userData[index]['CNTNAME']}",
    //
    //                                     fontSize: 16,),
    //                                 ],
    //                               ).pOnly(bottom: 5.0),
    //                               Row(
    //                                 children: [
    //                                   TextWidget("Mobile:",fontSize: 16,color: appColor.value,),
    //                                   5.widthBox,
    //                                   InkWell(
    //                                     onTap:(){
    //                                       Utilities.onClickMobile(userData[index]['MOBILE']);
    //                                     },
    //                                     child: TextWidget("${userData[index]['MOBILE']}",fontSize: 16,
    //                                       color: appColor.value,
    //                                       textDecoration: TextDecoration.underline,),
    //                                   ),
    //                                 ],
    //                               ).pOnly(bottom: 5.0),
    //                               Row(
    //                                 children: [
    //                                   TextWidget("Email:",fontSize: 16,color: appColor.value,),
    //                                   5.widthBox,
    //                                   InkWell(
    //                                       onTap:(){
    //                                         Utilities.onClickEmail(userData[index]['Name']);
    //                                       },
    //                                       child: TextWidget("${userData[index]['Name']}",fontSize: 16,color: appColor.value,
    //                                         textDecoration: TextDecoration.underline,)),
    //                                 ],
    //                               ).pOnly(bottom: 5.0),
    //
    //                               5.heightBox,
    //                               Container(
    //                                 width: Get.width * 0.75,
    //                                 height: 1.0,
    //                                 color: Color(0xffBDC0CE),
    //                               ),
    //                               5.heightBox,
    //                             ],
    //                           ).pOnly(bottom: 10.0)),
    //                         ),
    //                       ),
    //                       15.heightBox,
    //                       CustomButton(text: "Close",onPressed: (){Get.back();},)
    //
    //
    //                     ],
    //                   ).p16(),
    //                 ),
    //               ),
    //             ));
    //           }
    //       }),
    //
    //     ),
    //     Container(
    //       width: Get.width,
    //       height: 1.0,
    //       color: Colors.grey[200],
    //     )
    //   ],
    // );
  }
}


import 'package:karma/Constants/Library.dart';


class DataPointInfo extends GetView<DataPointInfoController> {

   DataPointInfo({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(DataPointInfoController());
    return WillPopScope(
      onWillPop: () async{
        Get.back();
        // Get.off(()=> const DataPoints());
        return true;
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBarWidget(title: controller.data['DPNAME'].toString(),

        onBackPress: (){
          Get.back();
         // Get.off(()=> const DataPoints());
        },),
        body: SizedBox(
          width: Get.width,
          height: Get.height,
          child: Obx(()=>Stack(
            children: [
              !controller.isLoading.value ?
              ListView(
                physics: const BouncingScrollPhysics(),
                children: [

                  Container (
                    width: Get.width,

                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: const Color(0xffeaecf0), width: 1, ),
                      color: Colors.white,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              "${WebApis.rootUrl}/crm/image/A${DataInfo.userId.value.toString()}.jpeg".circularNetworkImage(
                                  bgColor: Colors.transparent, radius: 20),

                              10.widthBox,
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  TextWidget(controller.info['CONTNAME1'].toString(),
                                    fontSize: 14,
                                  fontWeight: FontWeight.w500,),
                                  TextWidget(controller.info['CONTDESG1'].toString(),
                                    color: const Color(0xff667084),
                                    fontSize: 14,
                                  ),

                                  10.heightBox,
                                  Row(


                                    children: [
                                      InkWell(
                                        onTap: (){
                                          Utilities.onClickMobile(controller.info['CONTMOB1']);
                                        },
                                        child: Container(

                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(4),
                                            border: Border.all(color: const Color(0xffd0d5dd), width: 1, ),
                                          ),
                                          padding: const EdgeInsets.all(8),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children:[
                                              CustomWidgets.showImage(path: callIcon1,),
                                              5.widthBox,
                                              TextWidget(
                                                "Call",
                                                color: Color(0xff191d23),
                                                fontSize: 12,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      10.widthBox,
                                      InkWell(
                                        onTap: (){
                                          Utilities.onClickEmail(controller.info['CONTEMAIL1']);
                                        },
                                        child: Container(

                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(4),
                                            border: Border.all(color: const Color(0xffd0d5dd), width: 1, ),
                                          ),
                                          padding: const EdgeInsets.all(8),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children:[
                                              CustomWidgets.showImage(path: emailIcon,),
                                              5.widthBox,
                                              TextWidget(
                                                "Email",
                                                color: Color(0xff191d23),
                                                fontSize: 12,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      10.widthBox,
                                      InkWell(
                                        onTap: (){
                                          Utilities.onClickLink(controller.info['WEBSITE'].toString().trim());
                                        },
                                        child: Container(

                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(4),
                                            border: Border.all(color: const Color(0xffd0d5dd), width: 1, ),
                                          ),
                                          padding: const EdgeInsets.all(8),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children:[
                                              CustomWidgets.showImage(path: websiteIcon,),
                                              5.widthBox,
                                              TextWidget(
                                                "Website",
                                                color: Color(0xff191d23),
                                                fontSize: 12,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),

                                    ],
                                  ),

                                ],
                              ),
                            ],
                          ),
                      ],
                    ).p16(),
                  ),
                  // ColoredBox(
                  //   color: Colors.white,
                  //   child: Column(
                  //     children: [
                  //       Row(
                  //         children: [
                  //           const Icon(Icons.person),
                  //           10.widthBox,
                  //           TextWidget(controller.info['CONTNAME1'].toString(),
                  //             fontSize: 16,)
                  //         ],
                  //       ),
                  //       5.heightBox,
                  //       Row(
                  //         children: [
                  //           const Icon(Icons.email),
                  //           10.widthBox,
                  //           InkWell(
                  //             onTap:(){
                  //               Utilities.onClickEmail(controller.info['CONTEMAIL1']);
                  //             },
                  //             child: TextWidget(controller.info['CONTEMAIL1'].toString(),
                  //               color: appColor.value,
                  //               fontSize: 16,
                  //             textDecoration: TextDecoration.underline,),
                  //           )
                  //         ],
                  //       ),
                  //       5.heightBox,
                  //       Row(
                  //         children: [
                  //           const Icon(Icons.call_outlined),
                  //           10.widthBox,
                  //           InkWell(
                  //             onTap:(){
                  //               Utilities.onClickMobile(controller.info['CONTMOB1']);
                  //             },
                  //             child: TextWidget(controller.info['CONTMOB1'].toString().trim(),
                  //               fontSize: 16,
                  //               color: appColor.value,
                  //               textDecoration: TextDecoration.underline,),
                  //           )
                  //         ],
                  //       ),
                  //       5.heightBox,
                  //       Row(
                  //         children: [
                  //           const Icon(Icons.account_box_outlined),
                  //           10.widthBox,
                  //           TextWidget(controller.info['CONTDESG1'].toString(),
                  //             fontSize: 16,)
                  //         ],
                  //       ),
                  //       5.heightBox,
                  //       Row(
                  //         children: [
                  //           const Icon(Icons.email),
                  //           10.widthBox,
                  //           InkWell(
                  //             onTap:(){
                  //               Utilities.onClickLink(controller.info['WEBSITE'].toString().trim());
                  //             },
                  //             child: TextWidget(controller.info['WEBSITE'].toString(),
                  //               fontSize: 16,
                  //               color: appColor,
                  //               textDecoration: TextDecoration.underline,),
                  //           )
                  //         ],
                  //       ),
                  //       5.heightBox,
                  //     ],
                  //   ).p8(),
                  // ),
                  // 10.heightBox,
                  10.heightBox,
                  ColoredBox(
                    color: Colors.white,
                    child: Wrap(
                    //  mainAxisSize: MainAxisSize.min,
                      alignment: WrapAlignment.spaceBetween,
                      children: [
                        contentWidget(text: "Address Details",image: address,onPressed: (){
                          Get.to(()=> const AddressDetails(),arguments: controller.info);
                        }),
                        contentWidget(text: "MainBrochure",image:mailBrochure, onPressed: (){
                       // controller.getBrochureData();
                        Get.dialog(

                            Center(
                          child: SizedBox(

                            width: Get.width * 0.7,
                            child: Obx(()=>Card(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Container(
                                    height:50,
                                    decoration:  BoxDecoration(
                                      gradient: LinearGradient(
                                          colors: appGradientColor
                                      ),
                                      borderRadius: const BorderRadius.only(topLeft: Radius.circular(10.0),
                                          topRight: Radius.circular(10.0)),
                                    ),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        TextButton(onPressed: (){
                                          Get.back();
                                        }, child: TextWidget("Close",
                                          fontSize: 14,color: Colors.white,),),
                                        TextWidget("Brochure",fontSize: 14,color: Colors.white,),
                                        TextButton(onPressed: (){

                                          if(controller.selectBrochure.value.isEmpty || controller.selectBrochure.value == "Select")
                                            {
                                              CustomWidgets.snackBar(title: "Please select Brochure");
                                            }
                                          else if(controller.selectEmail.value.isEmpty || controller.selectEmail.value == "Select")
                                            {
                                              CustomWidgets.snackBar(title: "Please select Email");
                                            }
                                          else
                                            {
                                              controller.sendData();
                                              Get.back();
                                            }
                                        }, child: TextWidget("Send",
                                          fontSize: 14,color: Colors.white,))
                                      ],
                                    ),
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      TextWidget("Brochure",fontSize: 16.0,color: Colors.black,),
                                      TextButton(onPressed: (){
                                        showMenu(context: context, position: const RelativeRect.fromLTRB(60.0, 500.0, 100.0, 0), items: controller.brochureList.map((data) {
                                          return  PopupMenuItem<dynamic>(
                                            onTap: (){
                                              controller.selectBrochure.value = data['NAME'];
                                              controller.selectBrochureId.value = data['ID'].toString();
                                            },
                                            child: TextWidget(data['NAME'],fontSize: 14,),



                                          );
                                        }).toList(),
                                        );
                                      }, child: Row(
                                        children: [
                                          SizedBox(
                                              width: 100,
                                              child: TextWidget("${controller.selectBrochure.value} ",fontSize: 14,color: Colors.black,maxLines: 2,)),
                                          const Icon(Icons.keyboard_arrow_down_outlined,)
                                        ],
                                      )),
                                    ],
                                  ).p8(),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      TextWidget("Email",fontSize: 16.0,color: Colors.black,),
                                      TextButton(onPressed: (){
                                        showMenu(context: context, position: const RelativeRect.fromLTRB(60.0, 500.0, 100.0, 0), items: controller.emailList.map((data) {
                                          return  PopupMenuItem<dynamic>(
                                            onTap: (){
                                              controller.selectEmail.value = data['Name'];
                                              controller.selectCntName.value = data['CNTNAME'];
                                            },
                                            child: TextWidget(data['Name'],fontSize: 14,),



                                          );
                                        }).toList(),
                                        );
                                      }, child: Row(
                                        children: [
                                          SizedBox(
                                              width: 100,
                                              child: TextWidget("${controller.selectEmail.value} ",fontSize: 14,color: Colors.black,maxLines: 2,)),
                                          const Icon(Icons.keyboard_arrow_down_outlined,)
                                        ],
                                      )),
                                    ],
                                  ).p8(),


                                ],
                              ),
                            ),),
                          ),
                        ));
                        }),
                        contentWidget(text: "Call Booking",image: callBooking1, onPressed: (){
                          Get.to(()=>const CallBookingPage(),  arguments: controller.data)!.then((value) => controller.onInit());
                        }),
                        contentWidget(text: "Contact Details",image: contactDetails,
                        onPressed: (){
                          Get.to(()=> const ContactDetails(),arguments: controller.data);
                        }),
                        contentWidget(text: "Opportunity",image: opportunity1, onPressed: (){
                          Get.to(()=>const OpportunityDetails());
                        }),
                        contentWidget(text: "Product & Services", image:product, onPressed: (){
                          Get.to(()=> const ProductAndServices(),arguments: controller.data);
                        }),
                        // contentWidget(text: "Delivery Request",onPressed: (){
                        //   Get.to(()=> const DeliveryRequest(),arguments: controller.info);
                        // }),
                        contentWidget(text: "Recent Activity",image: recentActivity, onPressed: (){
                          Get.to(()=> const RecentActivity(),arguments: controller.data);
                        }),
                        contentWidget(text: "Tally Serial Number",image: tallySerialNumber, onPressed: (){
                          Get.to(()=> const TallySerial(),arguments: controller.data);
                        }),
                        contentWidget(text: "Tickets",image: tickets1, onPressed: (){
                          DataInfo.dpId.value = controller.data['DPID'].toString();
                          Get.to(()=> const Tickets(),arguments: controller.data);
                        }),
                        contentWidget(text: "Visit History",image: recentActivity,onPressed: (){
                          Get.to(()=> const VisitHistory(),arguments: controller.data);
                        }),
                        // contentWidget(text: "Other Details",onPressed: (){
                        //
                        //   Get.to(()=> const DataPointDetails());
                        // }),

                      ],
                    ),
                  ),

                ],
              ).p16() : const SizedBox(),
              controller.isLoading.value ?
              const  LoadingScreen(): const SizedBox(),
            ],
          ))
        ),
      ),
    );
  }

  Widget contentWidget({required String text, String? image = "datapoint",Function()? onPressed}){
    return InkWell(
      onTap: onPressed,
      child: Container(
        width: Get.width / 2.3,
        padding: const EdgeInsets.all(16),
        decoration: ShapeDecoration(
          color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          shadows: const [
            BoxShadow(
              color: Color(0x3F919191),
              blurRadius: 8,
              offset: Offset(0, 2),
              spreadRadius: 0,
            )
          ],
        ),
        child: Column(

          children: [
            SizedBox(width: 25,height: 25,child: CustomWidgets.showAssetImage(
                path: image!,
                width: 25,
                height: 25),),
            10.heightBox,
            TextWidget(text, fontSize: 13,

              fontWeight: FontWeight.w400,
              ),

          ],
        ).pSymmetric(h: 10.0),
      ).pSymmetric(v: 5.0),
    );

    //   Column(
    //   children: [
    //
    //
    //     ListTile(
    //       onTap: onPressed,
    //       title: TextWidget(text,
    //       fontSize: 16,),
    //       trailing: const Icon(Icons.arrow_forward_ios_outlined,
    //       size: 20,),
    //
    //     ),
    //     Container(
    //       width: Get.width,
    //       height: 1.0,
    //       color: Colors.grey[200],
    //     )
    //   ],
    // );
  }
}

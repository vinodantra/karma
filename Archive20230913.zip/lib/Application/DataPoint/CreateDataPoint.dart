import 'package:karma/Constants/Library.dart';
class CreateDataPoint extends StatelessWidget {
  const CreateDataPoint({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarWidget(title: "Create Data Point",
        ),
      body: SizedBox(
        width: Get.width,
        height: Get.height,
        child: Column(
          children: [

          ],
        ),
      ),
    );
  }
}

import 'package:karma/Constants/Library.dart';

class ContactDetails extends GetView<ContactDetailsController> {
  const ContactDetails({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(ContactDetailsController());
    return Scaffold(
      appBar: AppBarWidget(title: 'Contact Details',
      ),
      body: SizedBox(
        width: Get.width,
        height: Get.height,
        child: Obx(()=>Stack(
          children: [

            ListView(
                physics: const BouncingScrollPhysics(),
                children: List.generate(controller.contactList.length, (index) => tileWidget(controller.contactList[index]))
            ),
            controller.isLoading.value ?
            const  LoadingScreen(): const SizedBox(),
          ],
        ))
      ),
    );
  }

 Widget tileWidget(var data) {
    return Container(
      width:Get.width,


      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xffeaecf0), width: 1, ),
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(

            children: [
              const Icon(Icons.person_outline_rounded),
              10.widthBox,
              TextWidget(
                data['CNTNAME'],

                color: const Color(0xff344053),
                fontSize: 14,

                fontWeight: FontWeight.w500,

              ),
            ],
          ),
          10.heightBox,
          Row(

            children: [
              const Icon(Icons.phone_enabled_outlined),
              10.widthBox,
              InkWell(
                onTap: (){
                  Utilities.onClickMobile(data['MOBILE'].toString().trim());
                },
                child: TextWidget(data['MOBILE'],
                    color: Colors.lightBlueAccent,
                    fontSize: 14,
                textDecoration: TextDecoration.underline,),
              ),
            ],
          ),
          10.heightBox,
          Row(

            children: [
              const Icon(Icons.email_outlined),
              10.widthBox,
              InkWell(
                onTap:(){
                  Utilities.onClickEmail(data['Name'].toString().trim());
                },
                child: TextWidget(data['Name'],
                    color: Colors.lightBlueAccent,
                    fontSize: 14,
                textDecoration: TextDecoration.underline,),
              ),
            ],
          ),
          10.heightBox,


        ],
      ).p16(),
    ).p8();
 }
}

import 'dart:developer';


import 'package:karma/Constants/Library.dart';

import 'package:intl/intl.dart';
class CallBookingPage extends GetView<CallBookingController> {
  const CallBookingPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(CallBookingController());
    return WillPopScope(
      onWillPop: ()async{
        Get.back();
       // Get.offAll(()=>  DataPointInfo(),arguments: controller.data);
        return true;
      },
      child: Scaffold(

        appBar: AppBarWidget(title: controller.data['DPNAME'],

          onSubmit: (){
          controller.checkData();
        },),
        body: SizedBox(
            height: Get.height,
            width: Get.width,
            child:Obx(()=> Stack(
              children: [
                ListView(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          height: 30,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,

                            children: [
                              TextWidget("Call Date",color: Color(0xff7d8493),
                                fontSize: 14,),

                              Container(
                                width: Get.width * 0.5,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 30.0,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              InkWell(
                                onTap: () async{
                                  var de = await  CustomWidgets.pickDate(context);

                                  if(de != null) {
                                    controller.selectDate.value = de.toString();

                                    controller.currentDate.value = DateFormat('dd-MM-yyyy')
                                        .format(de);
                                  }
                                },
                                child: Row(
                                  children: [
                                    TextWidget(controller.currentDate.value,fontSize: 14,
                                        color: const Color(0xff2f3237)),
                                    5.widthBox,
                                    const Icon(Icons.calendar_today_outlined,size: 20,color: Color(0xff7E8494),),
                                    const  Icon(Icons.keyboard_arrow_down_outlined,size: 20,color: Color(0xff7E8494),)
                                  ],
                                ),
                              ),

                              Container(
                                width: Get.width * 0.4,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ).pOnly(top:10.0,bottom: 10.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          height: 30,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,

                            children: [
                              TextWidget("Call Time",color: Color(0xff7d8493),
                                fontSize: 14,),

                              Container(
                                width: Get.width * 0.5,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 30.0,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              InkWell(
                                onTap: () async{
                                  TimeOfDay? selectTime = await  CustomWidgets.pickTime(context);
                                  if(selectTime != null) {
                                    controller.selectTime.value =  selectTime.format(context).toString();
                                    controller.currentTime.value = selectTime.format(context).toString();
                                  }
                                },
                                child: Row(
                                  children: [
                                    TextWidget(controller.currentTime.value,fontSize: 14,
                                      color: const Color(0xff2f3237),),
                                    5.widthBox,
                                    const Icon(Icons.access_time,size: 20,color:  Color(0xff7E8494),),
                                    const  Icon(Icons.keyboard_arrow_down_outlined,size: 20,color:  Color(0xff7E8494),)
                                  ],
                                ),
                              ),

                              Container(
                                width: Get.width * 0.4,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ).pOnly(top:10.0,bottom: 10.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          height: 30,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,

                            children: [
                              TextWidget("Type of Call",color: Color(0xff7d8493),
                                fontSize: 14,),

                              Container(
                                width: Get.width * 0.5,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 30.0,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              InkWell(
                                onTap:(){
                                  CustomWidgets.customBottomSheet(controller.callTypeList, "NAME",false, (data){
                                    log("Type of Call :$data");
                                    controller.selectCallType.value = data['NAME'];
                                    controller.selectCallTypeId.value = data['ID'];
                                    Get.back();
                                  });

                                },
                                child: Row(children: [
                                  TextWidget(controller.selectCallType.value,fontSize: 14,color: Color(0xff2f3237),),
                                  5.widthBox,
                                  const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                                ],),
                              ),

                              Container(
                                width: Get.width * 0.4,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ).pOnly(top:10.0,bottom: 10.0),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          height: 30,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,

                            children: [
                              TextWidget("Nature of Call",color: Color(0xff7d8493),
                                fontSize: 14,),

                              Container(
                                width: Get.width * 0.5,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 30.0,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              InkWell(
                                onTap:(){
                                  CustomWidgets.customBottomSheet(controller.fNatureOfCall, "NAME",true, (data){
                                    log("Nature of call :$data");
                                    controller.selectNoc.value = data['NAME'];
                                    controller.selectNocId.value =  data['ID'];
                                    Get.back();
                                  });


                                },
                                child: Row(children: [
                                  SizedBox(
                                      width:130,
                                      child: TextWidget(controller.selectNoc.value,fontSize: 14,color: Color(0xff2f3237),textAlign: TextAlign.right,)),
                                  5.widthBox,
                                  const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                                ],),
                              ),

                              Container(
                                width: Get.width * 0.4,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ).pOnly(top:10.0,bottom: 10.0),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          height: 30,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,

                            children: [
                              TextWidget("Allocation Manager",color: Color(0xff7d8493),
                                fontSize: 14,),

                              Container(
                                width: Get.width * 0.5,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 30.0,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              InkWell(
                                onTap:(){
                                  CustomWidgets.customBottomSheet(controller.allocationManagerList, "NAME",false, (data){
                                    log("Allocation Manager :$data");
                                    controller.selectManager.value = data['NAME'];
                                    controller.selectManagerId.value = data['ID'];
                                    controller.selectUser.value = "Select";
                                    Get.back();
                                  });
                                  // showMenu(context: context,
                                  //   position: const RelativeRect.fromLTRB(700.0, 300.0, 10.0, 0), items: controller.allocationManagerList.map((data) {
                                  //     return  PopupMenuItem<dynamic>(
                                  //       onTap: (){
                                  //         controller.selectManager.value = data;
                                  //       },
                                  //       child: TextWidget(data,fontSize: 14,),
                                  //
                                  //
                                  //
                                  //     );
                                  //   }).toList(),
                                  // );

                                },
                                child: Row(children: [
                                  TextWidget(controller.selectManager.value,fontSize: 14,color: Color(0xff2f3237),),
                                  5.widthBox,
                                  const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                                ],),
                              ),

                              Container(
                                width: Get.width * 0.4,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ).pOnly(top:10.0,bottom: 10.0),
                    controller.selectManager.value == "Sales" ?
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          height: 30,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,

                            children: [
                              TextWidget("User",color: Color(0xff7d8493),
                                fontSize: 14,),

                              Container(
                                width: Get.width * 0.5,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 30.0,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              InkWell(
                                onTap:(){
                                  CustomWidgets.customBottomSheet(controller.flUsersList, "NAME",true, (data){
                                    log("User :$data");
                                    controller.selectUser.value = data['NAME'];

                                    Get.back();
                                  });


                                },
                                child: Row(children: [
                                  TextWidget(controller.selectUser.value,fontSize: 14,color: Color(0xff2f3237),),
                                  5.widthBox,
                                  const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                                ],),
                              ),

                              Container(
                                width: Get.width * 0.4,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ).pOnly(top:10.0,bottom: 10.0) : const SizedBox(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          height: 30,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,

                            children: [
                              TextWidget("Support Type",color: const Color(0xff7d8493),
                                fontSize: 14,),

                              Container(
                                width: Get.width * 0.5,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 30.0,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              InkWell(
                                onTap:(){
                                  CustomWidgets.customBottomSheet(controller.supTypeList, "NAME",true, (data){

                                    controller.selectSupType.value = data['NAME'];
                                    controller.selectSupTypeId.value = data['ID'];
                                    Get.back();
                                  });


                                },
                                child: Row(children: [
                                  TextWidget(controller.selectSupType.value,fontSize: 14,color: Color(0xff2f3237),),
                                  5.widthBox,
                                  const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                                ],),
                              ),

                              Container(
                                width: Get.width * 0.4,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ).pOnly(top:10.0,bottom: 10.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          height: 30,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,

                            children: [
                              TextWidget("Location",color: Color(0xff7d8493),
                                fontSize: 14,),

                              Container(
                                width: Get.width * 0.5,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 30.0,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              InkWell(
                                onTap:(){
                                  CustomWidgets.customBottomSheet(controller.addressList, "NAME",true, (data){
                                    log("Location :$data");
                                    controller.selectAddress.value = data['NAME'];
                                    controller.addressDetails.value = data['ADD'];
                                    controller.selectPhone.value = data['PHONE'];
                                    controller.selectRegion.value = data['CITY'];
                                    Get.back();
                                  });


                                },
                                child: Row(children: [
                                  TextWidget(controller.selectAddress.value,fontSize: 14,color: Color(0xff2f3237),),
                                  5.widthBox,
                                  const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                                ],),
                              ),

                              Container(
                                width: Get.width * 0.4,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ).pOnly(top:10.0,bottom: 10.0),




                    SizedBox(
                      height: controller.selectPhone.value.isNotEmpty ? 56.0 : 30.0,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,

                        children: [
                          TextWidget("Phone",color: Color(0xff7d8493),
                            fontSize: 14,),
                          10.heightBox,
                          controller.selectPhone.value.isNotEmpty ?  Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [

                              TextWidget(controller.selectPhone.value,fontSize: 14,color: Color(0xff7d8493),),
                              8.heightBox,

                            ],
                          ) : const SizedBox(),
                          Container(
                            width: Get.width * 0.9,
                            height: 1,
                            color: const Color(0xffBDC0CE),
                          ),

                        ],
                      ),
                    ).pOnly(top: 10.0,bottom: 10.0),
                    SizedBox(
                      height: controller.addressDetails.value.isNotEmpty ? 56.0 : 30.0,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,

                        children: [
                          TextWidget("Address",color: Color(0xff7d8493),
                            fontSize: 14,),
                          10.heightBox,
                          controller.addressDetails.value.isNotEmpty ?  Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [

                              TextWidget(controller.addressDetails.value,fontSize: 14,color: Color(0xff7d8493),),
                              8.heightBox,

                            ],
                          ) : const SizedBox(),
                          Container(
                            width: Get.width * 0.9,
                            height: 1,
                            color: const Color(0xffBDC0CE),
                          ),

                        ],
                      ),
                    ).pOnly(top: 10.0,bottom: 10.0),

                    SizedBox(
                      height: controller.selectRegion.value.isNotEmpty ? 56.0 : 30.0,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,

                        children: [
                          TextWidget("Region",color: Color(0xff7d8493),
                            fontSize: 14,),
                          10.heightBox,
                          controller.selectRegion.value.isNotEmpty ?  Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [

                              TextWidget(controller.selectRegion.value,fontSize: 14,color: Color(0xff7d8493),),
                              8.heightBox,

                            ],
                          ) : const SizedBox(),
                          Container(
                            width: Get.width * 0.9,
                            height: 1,
                            color: const Color(0xffBDC0CE),
                          ),

                        ],
                      ),
                    ).pOnly(top: 10.0,bottom: 10.0),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          height: 30,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,

                            children: [
                              TextWidget("Tally Serial",color: Color(0xff7d8493),
                                fontSize: 14,),

                              Container(
                                width: Get.width * 0.5,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 30.0,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              InkWell(
                                onTap:(){
                                  CustomWidgets.customBottomSheet(controller.tallySrNo, "NAME",true, (data){
                                    log("Tally Serial :$data");
                                    controller.selectTallySrNo.value = data['NAME'];
                                    Get.back();
                                  });


                                },
                                child: Row(children: [
                                  SizedBox(
                                      width:Get.width * 0.3,
                                      child: TextWidget(controller.selectTallySrNo.value,fontSize: 14,color: Color(0xff2f3237),)),
                                  5.widthBox,
                                  const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                                ],),
                              ),

                              Container(
                                width: Get.width * 0.4,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ).pOnly(top:10.0,bottom: 10.0),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          height: 30,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,

                            children: [
                              TextWidget("Contact Person",color: Color(0xff7d8493),
                                fontSize: 14,),

                              Container(
                                width: Get.width * 0.5,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 30.0,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              InkWell(
                                onTap:(){
                                  CustomWidgets.customBottomSheet(controller.contactList, "CNTNAME",true, (data){

                                    controller.selectContact.value = data['CNTNAME'];
                                    controller.selectContactEmail.value = data['EMAIL'];
                                    controller.selectContactMobile.value = data['MOBILE'];
                                    controller.selectContactId.value = data['CNTID'];
                                    Get.back();
                                  });


                                },
                                child: Row(children: [
                                  TextWidget(controller.selectContact.value,fontSize: 14,color: Color(0xff2f3237),),
                                  5.widthBox,
                                  const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                                ],),
                              ),

                              Container(
                                width: Get.width * 0.4,
                                height: 1,
                                color: const Color(0xffBDC0CE),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ).pOnly(top:10.0,bottom: 10.0),

                    SizedBox(
                      height: controller.selectContactEmail.value.isNotEmpty ? 56.0 : 30.0,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,

                        children: [
                          TextWidget("Email Id",color: Color(0xff7d8493),
                            fontSize: 14,),
                          10.heightBox,
                          controller.selectContactEmail.value.isNotEmpty ?  Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [

                              TextWidget(controller.selectContactEmail.value,fontSize: 14,color: Color(0xff7d8493),),
                              8.heightBox,

                            ],
                          ) : const SizedBox(),
                          Container(
                            width: Get.width * 0.9,
                            height: 1,
                            color: const Color(0xffBDC0CE),
                          ),

                        ],
                      ),
                    ).pOnly(top: 10.0,bottom: 10.0),
                    SizedBox(
                      height: controller.selectContactEmail.value.isNotEmpty ? 56.0 : 30.0,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,

                        children: [
                          TextWidget("Mobile No",color: Color(0xff7d8493),
                            fontSize: 14,),
                          10.heightBox,
                          controller.selectContactMobile.value.isNotEmpty ?  Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [

                              TextWidget(controller.selectContactMobile.value,fontSize: 14,color: Color(0xff7d8493),),
                              8.heightBox,

                            ],
                          ) : const SizedBox(),
                          Container(
                            width: Get.width * 0.9,
                            height: 1,
                            color: const Color(0xffBDC0CE),
                          ),

                        ],
                      ),
                    ).pOnly(top: 10.0,bottom: 10.0),


                    RadioListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 1),
                      value: 1, groupValue: controller.selectCheckCollection.value, onChanged: (int? value){


                      controller.selectCheckCollection.value = value!;
                    },
                      title: TextWidget("Cheque Collection",fontSize: 18,color: Color(0xff7d8493),),),

                    TextField(
                      controller: controller.remarkController,
                      decoration: const InputDecoration(
                          hintText: "Remark"


                      ),
                      maxLines: 5,
                      minLines: 5,
                    ),
                    10.heightBox,
                    CustomButton(text: "Save",onPressed: (){controller.checkData();},),
                    10.heightBox,


                  ],
                ).pSymmetric(h: 16.0,v: 8.0),
                controller.isLoading.value ?
                    const LoadingScreen() : const SizedBox()
              ],
            )),
        ),
      ),
    );
    
  }
}

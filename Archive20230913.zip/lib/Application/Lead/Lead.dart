
import 'package:karma/Application/Lead/LeadReceived.dart';
import 'package:karma/Constants/Library.dart';

class Lead extends GetView<LeadController> {
  const Lead({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(LeadController());
    return Scaffold(
      appBar: AppBarWidget(
        title: "Lead",
        onPressAdd: (){
          Get.to(()=> const CreateLead1());
        },
      ),
      body: SizedBox(
        width: Get.width,
        height: Get.height,


          child: Obx(()=>Stack(
            children: [
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextWidget("Select Lead",fontSize: 18,),
                      InkWell(
                        onTap: (){
                          CustomWidgets.customBottomSheet(
                              controller.filterData, "NAME", false,
                                  (data) {
                                controller.selectFilterData.value = data['NAME'];

                                Get.find<LeadController>().onInit();
                                Get.back();
                              });
                        },
                        child: ColoredBox(
                          color: Colors.transparent,
                          child: Row(
                            children: [
                              TextWidget(controller.selectFilterData.value,fontSize: 16,),
                              const Icon(Icons.keyboard_arrow_down_outlined)
                            ],
                          ),
                        ),
                      ),
                    ],
                  ).p8(),
                  10.heightBox,

                  Check.data(controller.leadData) ? Column(
                    children: [
                      tile("Accepted", controller.leadData['ACCEPTED'].toString(), "accepted.png"),
                      tile("Rejected", controller.leadData['REJECT'].toString(), "rej.png"),
                      tile("In Process", controller.leadData['INPROCESS'].toString(), "inpro.png"),
                      tile("Untouched", controller.leadData['UNTOUCHED'].toString(), "untoch.png"),



                    ],
                  ) : const SizedBox()
                ],
              ).p16(),

              controller.isLoading.value ?  const LoadingScreen() : const SizedBox(),

            ],
          )),
      ),
    );
  }

  Widget tile(String title,String value,String url){
    return  InkWell(
      onTap:(){
        Get.to(()=>LeadReceived(),arguments: {"lead":controller.selectFilterData.value,
        "leadtype":title})!.then((value) => Get.find<LeadController>().onInit());
      },
      child: Container(
        decoration: BoxDecoration(
          borderRadius:
          BorderRadius.circular(8),
          boxShadow: const [
            BoxShadow(
              color: Color(0x3f919191),
              blurRadius: 8,
              offset: Offset(0, 2),
            ),
          ],
          color: Colors.white,
        ),
        child: Row(
          children: [
            SizedBox(
              width: 80,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(50.0),
                child: Image.network("${WebApis.rootUrl}/CRM/Karma/www/img/$url"),
              ),
            ),
            10.widthBox,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextWidget(title,fontSize: 16,fontWeight: FontWeight.w500,color: Colors.grey[400],),
                10.heightBox,
                TextWidget(value,fontSize: 30,fontWeight: FontWeight.w500,color: Colors.black,),
              ],)
          ],
        ).p8(),


      ).pSymmetric(v: 4.0),
    );
  }
}

import 'package:karma/Constants/Library.dart';

class CreateLead1 extends GetView<CreateLeadController1> {
  const CreateLead1({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(CreateLeadController1());
    return Scaffold(
      appBar: AppBarWidget(
        title: "New Lead",
        onSubmit: (){
          controller.checkData();
        },
      ),
      body: SizedBox(
        width: Get.width,
        height: Get.height,
        child: Obx(()=>Stack(
          children: [
            ListView(
              children: [
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextWidget(
                          "Lead Source",
                          color: const Color(0xff344053),
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        InkWell(
                          onTap: () {
                            CustomWidgets.customBottomSheet(
                                controller.leadSourceList, "SOURCE", true, (data) {
                                  print("de:${data}");
                                  controller.selectLeadSourceId.value  = data['ID'];
                              controller.selectLeadSourceData.value = data['SOURCE'];

                              Get.back();
                            });
                          },
                          child: Row(
                            children: [
                              TextWidget(
                                controller.selectLeadSourceData.value,
                                fontSize: 14,
                                color: Color(0xff2f3237),
                              ),
                              5.widthBox,
                              const Icon(
                                Icons.keyboard_arrow_down_outlined,
                                color: Color(0xff7E8494),
                              )
                            ],
                          ),
                        ),
                      ],
                    ).pSymmetric(h: 15.0, v: 10.0),
                    5.heightBox,
                    Container(
                      width: Get.width,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),
                  ],
                ),
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextWidget(
                          "Interested In",
                          color: const Color(0xff344053),
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        InkWell(
                          onTap: () {
                            CustomWidgets.customBottomSheet(
                                controller.interestedDataList, "SOURCE", true, (data) {
                                  controller.selectInterestedId.value = data['ID'];
                              controller.selectInterestedData.value = data['SOURCE'];

                              Get.back();
                            });
                          },
                          child: Row(
                            children: [
                              TextWidget(
                                controller.selectInterestedData.value,
                                fontSize: 14,
                                color: Color(0xff2f3237),
                              ),
                              5.widthBox,
                              const Icon(
                                Icons.keyboard_arrow_down_outlined,
                                color: Color(0xff7E8494),
                              )
                            ],
                          ),
                        ),
                      ],
                    ).pSymmetric(h: 15.0, v: 10.0),
                    5.heightBox,
                    Container(
                      width: Get.width,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),
                  ],
                ),
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextWidget(
                          "Item",
                          color: const Color(0xff344053),
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        InkWell(
                          onTap: () {
                            CustomWidgets.customBottomSheet(
                                controller.itemList, "NAME", true, (data) {
                                  controller.selectItemId.value = data['ID'];
                              controller.selectItemData.value = data['NAME'];
                              Get.back();
                            });
                          },
                          child: Row(
                            children: [
                              TextWidget(
                                controller.selectItemData.value,
                                fontSize: 14,
                                color: Color(0xff2f3237),
                              ),
                              5.widthBox,
                              const Icon(
                                Icons.keyboard_arrow_down_outlined,
                                color: Color(0xff7E8494),
                              )
                            ],
                          ),
                        ),
                      ],
                    ).pSymmetric(h: 15.0, v: 10.0),
                    5.heightBox,
                    Container(
                      width: Get.width,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),
                  ],
                ),
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        TextWidget(
                          "Company Name",
                          color: const Color(0xff344053),
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        SizedBox(
                            width: Get.width / 2,
                            height: 50,
                            child: TextField(

                              controller: controller.companyName,
                              keyboardType: TextInputType.name,
                              textAlign: TextAlign.right,
                              textInputAction: TextInputAction.next,

                            )
                        ),
                      ],
                    ).pSymmetric(h: 15.0, v: 5.0),
                    5.heightBox,
                    Container(
                      width: Get.width,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),
                  ],
                ),
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        TextWidget(
                          "Contact Name",
                          color: const Color(0xff344053),
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        SizedBox(
                            width: Get.width / 2,
                            height: 50,
                            child: TextField(

                              controller: controller.contactName,
                              keyboardType: TextInputType.name,
                              textAlign: TextAlign.right,
                              textInputAction: TextInputAction.next,

                            )
                        ),
                      ],
                    ).pSymmetric(h: 15.0, v: 5.0),
                    5.heightBox,
                    Container(
                      width: Get.width,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),
                  ],
                ),
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        TextWidget(
                          "Contact Number",
                          color: const Color(0xff344053),
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        SizedBox(
                            width: Get.width / 2,
                            height: 50,
                            child: TextField(

                              controller: controller.contactNumber,
                              keyboardType: TextInputType.number,
                              textAlign: TextAlign.right,
                              textInputAction: TextInputAction.next,

                            )
                        ),
                      ],
                    ).pSymmetric(h: 15.0, v: 5.0),
                    5.heightBox,
                    Container(
                      width: Get.width,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),
                  ],
                ),
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        TextWidget(
                          "Email",
                          color: const Color(0xff344053),
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        SizedBox(
                            width: Get.width / 2,
                            height: 50,
                            child: TextField(

                              controller: controller.email,
                              keyboardType: TextInputType.emailAddress,
                              textAlign: TextAlign.right,
                              textInputAction: TextInputAction.next,

                            )
                        ),
                      ],
                    ).pSymmetric(h: 15.0, v: 5.0),
                    5.heightBox,
                    Container(
                      width: Get.width,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),
                  ],
                ),
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        TextWidget(
                          "City",
                          color: const Color(0xff344053),
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        SizedBox(
                            width: Get.width / 2,
                            height: 50,
                            child: TextField(

                              controller: controller.city,
                              keyboardType: TextInputType.name,
                              textAlign: TextAlign.right,
                              textInputAction: TextInputAction.next,

                            )
                        ),
                      ],
                    ).pSymmetric(h: 15.0, v: 5.0),
                    5.heightBox,
                    Container(
                      width: Get.width,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),
                  ],
                ),
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        TextWidget(
                          "Tally Serial Number",
                          color: const Color(0xff344053),
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        SizedBox(
                            width: Get.width / 2,
                            height: 50,
                            child: TextField(

                              controller: controller.tallySerialNumber,
                              keyboardType: TextInputType.number,
                              textAlign: TextAlign.right,
                              textInputAction: TextInputAction.next,

                            )
                        ),
                      ],
                    ).pSymmetric(h: 15.0, v: 5.0),
                    5.heightBox,
                    Container(
                      width: Get.width,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),
                  ],
                ),
                TextWidget(
                  "Comment",
                  color: const Color(0xff344053),
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ).pSymmetric(h: 15.0,v: 10.0),
                TextField(

                  controller: controller.comment,
                  keyboardType: TextInputType.multiline,
                  decoration: const InputDecoration(
                      hintText: "Write Additional detail/Comment here"
                  ),
                  minLines: 10,
                  maxLines: 10,

                ).pSymmetric(h: 15.0,v: 10.0)

              ],
            ),
            controller.isLoading.value ?  const LoadingScreen() : const SizedBox(),
          ],
        )),
      ),
    );
  }

  Widget tile(
      {String? title,
        String? data,
        String type = "1",
        List<dynamic>? list,
        String pa = "",
        String selectData = "",ValueChanged<Map<String,dynamic>>? updateData,}) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextWidget(
              title,
              color: const Color(0xff344053),
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
            type == "1"
                ? SizedBox(
              width: Get.width / 2,
              child: TextWidget(
                data,
                color: const Color(0xff667084),
                fontSize: 16,
                fontWeight: FontWeight.w500,
                textAlign: TextAlign.right,
                maxLines: 10,
              ),
            )
                : type == "2"
                ? InkWell(
              onTap: () {
                Utilities.onClickMobile(data!);
              },
              child: TextWidget(
                data,
                color: Colors.lightBlueAccent,
                fontSize: 16,
                fontWeight: FontWeight.w500,
                textDecoration: TextDecoration.underline,
              ),
            )
                : InkWell(
              onTap: () {
                CustomWidgets.customBottomSheet(
                    list, pa, false, (data) {
                  updateData!(data);
                  Get.back();
                });
              },
              child: Row(
                children: [
                  TextWidget(
                    selectData,
                    fontSize: 14,
                    color: Color(0xff2f3237),
                  ),
                  5.widthBox,
                  const Icon(
                    Icons.keyboard_arrow_down_outlined,
                    color: Color(0xff7E8494),
                  )
                ],
              ),
            ),
          ],
        ).pSymmetric(h: 15.0, v: 10.0),
        5.heightBox,
        Container(
          width: Get.width,
          height: 1.0,
          color: Colors.grey[400],
        ),
      ],
    );
  }


}

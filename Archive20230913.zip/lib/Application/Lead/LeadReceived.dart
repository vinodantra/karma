import 'package:karma/Application/Lead/UpdateLead.dart';
import 'package:karma/Constants/Library.dart';
import 'package:karma/Controller/leadReceivedController.dart';
class LeadReceived extends GetView<LeadReceivedController> {
  const LeadReceived({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(LeadReceivedController());
    return Scaffold(
        appBar: AppBarWidget(
          title: DataInfo.desCat.value == "L1" ? "Lead Received" : "Lead Given",
        ),
        body: Obx(()=>SizedBox(
            width: Get.width,
            height: Get.height,
            child: Stack(
              children: [
                controller.list.isNotEmpty ?  ListView.builder(
                    itemCount: controller.list.length,
                    itemBuilder: (context,int index){
                      return tile(controller.list[index]);}).p16() : const SizedBox(),
                controller.isLoading.value ? const LoadingScreen() : const SizedBox(),
                controller.isLoading.value == false  && controller.list.isEmpty  ?  Center(
                  child: TextWidget("No data found.",
                    fontSize: 25,color: Colors.black,fontWeight: FontWeight.w500,),
                ) : const SizedBox(),


              ],
            )
        ),)
    );
  }

  Widget tile(var data){
    return InkWell(
      onTap: (){
        Get.to(()=> const UpdateLead(),arguments: {"leadData":data,

        "showData":controller.lead.value != "Given"  && (controller.leadType.value == "In Process" || controller.leadType.value == "Untouched" )})!.then((value) => Get.find<LeadReceivedController>().onInit());
      },
      child: Container(
        width: Get.width,

        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          boxShadow: const [
            BoxShadow(
              color: Color(0x3f919191),
              blurRadius: 8,
              offset: Offset(0, 2),
            ),
          ],
          color: Colors.white,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextWidget("${data['DPNAME']}",fontSize: 18,color: appColor.value,fontWeight: FontWeight.w500,),

                controller.lead.value != "Given"  && (controller.leadType.value == "In Process" || controller.leadType.value == "Untouched" )?  IconButton(onPressed: (){

                  Get.dialog(Obx(()=>Center(
                    child: Card(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          TextWidget("Create Ticket",fontSize: 16,color: appColor.value,fontWeight: FontWeight.w500,),
                          20.heightBox,
                          CustomWidgets.divider(width: Get.width,height: 1,color: appColor.value),
                          20.heightBox,
                          TextField(
                            controller: controller.description,
                            minLines: 1,
                            maxLines: 10,
                            decoration: const InputDecoration(
                                hintText: "Have Description? Write Here.....",
                                border: OutlineInputBorder()
                            ),
                          ).pSymmetric(h: 25.0),
                          15.heightBox,
                          InkWell(
                            onTap: (){
                              CustomWidgets.customBottomSheet(
                                  controller.ticketTypeList, "TYPE", false,
                                      (data) {
                                    controller.selectTicket.value = data['TYPE'];
                                    controller.selectTicketId.value = data['ID'].toString();
                                    Get.back();
                                  });
                            },
                            child: Container(

                              height: 60,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  border: Border.all(color: const Color(0xff3d3d3d),width: 1.0),
                                  color: Colors.white
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  TextWidget(controller.selectTicket.value,fontSize: 16,color: const Color(0xff3d3d3d),),
                                  const Icon(Icons.keyboard_arrow_down_outlined)
                                ],
                              ).pSymmetric(h: 10.0),
                            ).pSymmetric(h: 25.0),
                          ),
                          15.heightBox,
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              TextButton(onPressed: (){
                                Get.back();
                              }, child: TextWidget("Cancel",fontSize: 16,color: const Color(0xff3d3d3d),)),
                              
                              CustomButton(text: "Save",onPressed: (){
                                Get.back();
                                controller.createTicket(data['ID']);
                              },)
                            ],
                          ).pSymmetric(h: 25.0),

                        ],
                      ).p16(),
                    ).p16(),
                  )));
                }, icon: const Icon(Icons.more_vert)) : const SizedBox()
              ],
            ),
            5.heightBox,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextWidget("Received",fontSize: 14,color: const Color(0xff3d3d3d),fontWeight: FontWeight.w500,),
                TextWidget("${data['NAME']}",fontSize: 16,color: const Color(
                    0xff787878),fontWeight: FontWeight.w500,maxLines: 5,)
              ],
            ),
            5.heightBox,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextWidget("Create Date",fontSize: 14,color: const Color(0xff3d3d3d),fontWeight: FontWeight.w500,),
                TextWidget("${data['CREATEDATE']}",fontSize: 16,color: const Color(
                    0xff787878),fontWeight: FontWeight.w500,maxLines: 5,)
              ],
            ),
            5.heightBox,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextWidget("Attend Date",fontSize: 14,color: const Color(0xff3d3d3d),fontWeight: FontWeight.w500,),
                TextWidget("${data['ATNDATE']}",fontSize: 16,color: const Color(
                    0xff787878),fontWeight: FontWeight.w500,maxLines: 5,)
              ],
            ),
            Row(
              children: [
                IconButton(onPressed: (){
                  Utilities.onClickMobile(data['MOB']);
                }, icon: const Icon(Icons.call,size: 20,)),
                IconButton(onPressed: (){
                  Utilities.onClickMessage(data['MOB']);
                }, icon: const Icon(Icons.message,size: 20,)),
              ],
            ),




          ],
        ).p8(),
      ).pSymmetric(v: 4.0),
    );
  }
}

import '../../Constants/Library.dart';
class IntroScreen extends StatefulWidget {
  const IntroScreen({Key? key}) : super(key: key);

  @override
  State<IntroScreen> createState() => _IntroScreenState();
}

class _IntroScreenState extends State<IntroScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: context.screenWidth,
        height: context.screenHeight,
        child: PageView.builder(
            itemCount: 3,
            itemBuilder: (context,index){
              return Container(
                width: context.screenWidth,
                height: context.screenHeight,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment
                        .centerLeft,
                    end: Alignment
                        .centerRight,
                    colors: [
                      Color(0xffe0659b),
                      Color(0xff8b4de6)
                    ],
                  ),
                ),
                child: Column(),
              );
            }),
      ),
    );
  }
}

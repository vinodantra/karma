

import '../../Constants/Library.dart';
class TargetReport extends GetView<TargetReportController> {
  const TargetReport({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(TargetReportController());
    return Scaffold(
      appBar: AppBarWidget(title: controller.args['title'],onPressAdd: (){},),
      body: SizedBox(
        width: Get.width,
        height:Get.height,
        child: Obx(()=>ListView(
          children: [

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextWidget(controller.args['status'] == "weekly" ?  "Select Week" : "Select Monthly",fontSize: 16,color: Colors.black,),
                InkWell(
                  onTap: (){
                    CustomWidgets.customBottomSheet(
                        controller.filterList, "NAME", false,
                            (data) {
                          controller.selectData.value = data['NAME'];
                          controller.selectId.value = data['ID'].toString();
                          controller.getData();
                          Get.back();
                        });
                  },
                  child: Row(
                    children: [

                      TextWidget(
                        controller.selectData.value,
                        color: const Color(0xff7d8493),
                        fontSize: 16,
                      ),
                      const Icon(
                        Icons.keyboard_arrow_down_outlined,
                        color: Color(0xff7E8494),
                      )
                    ],
                  ),
                ),
              ],
            ).pSymmetric(h: 15.0,v: 10.0),
           controller.args['type'] == "individual" ?  Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextWidget("Select User",fontSize: 16,color: Colors.black,),
                InkWell(
                  onTap: (){
                    CustomWidgets.customBottomSheet(
                        controller.filterUserList, "NAME", true,
                            (data) {
                          controller.selectUser.value = data['NAME'];
                          controller.selectUserId.value = data['ID'].toString();
                          controller.getData();
                          Get.back();
                        });
                  },
                  child: Row(
                    children: [

                      TextWidget(
                        controller.selectUser.value,
                        color: const Color(0xff7d8493),
                        fontSize: 16,
                      ),
                      const Icon(
                        Icons.keyboard_arrow_down_outlined,
                        color: Color(0xff7E8494),
                      )
                    ],
                  ),
                ),
              ],
            ).pSymmetric(h: 15.0,v: 10.0) : const SizedBox(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                    width: Get.width / 4,
                    child: TextWidget("Milestone",fontSize: 18,color: appColor.value,)),
                TextWidget("Target",fontSize: 18,color: appColor.value,),
                TextWidget("Done",fontSize: 18,color: appColor.value,),
              ],
            ).paddingSymmetric(horizontal: 15.0,vertical: 10.0),
            CustomWidgets.divider(),
            Column(
              children: List.generate(controller.listData.length, (index) => tile(controller.listData[index]))
            ),

          ],
        ),),
      ),
    );
  }

  tile(data) {
    return controller.args['action'] != "SLSREPORT" ?
    Card(
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                  width: Get.width / 4,
                  child: TextWidget(data['HEADER'].toString(),fontSize: 15,color: Colors.black,
                  maxLines: 2,)),
              TextWidget(data['TARGET'].toString(),fontSize: 15,color: Colors.black,),
              TextWidget(data['VALUE'].toString(),fontSize: 15,color: Colors.black,),

            ],
          ),
          10.heightBox,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: Get.width * 0.75,
                height: 10,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20.0),
                  color: Colors.grey[300]
                ),
              ),
              TextWidget(data['PERC'].toString(),fontSize: 15,color: Colors.black,),
            ],
          ),
        ],
      ).p8(),
    ).pSymmetric(h: 15.0,v: 4.0) : Card(
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                  width: Get.width / 4,
                  child: TextWidget(data['NAME'].toString(),fontSize: 15,color: Colors.black,
                    maxLines: 2,)),
              TextWidget(data['UINPUT'].toString(),fontSize: 15,color: Colors.black,),
              TextWidget(data['ACHIVEED'].toString(),fontSize: 15,color: Colors.black,),

            ],
          ),
          10.heightBox,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: Get.width * 0.75,
                height: 10,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20.0),
                    color: Colors.grey[300]
                ),
              ),
              TextWidget(data['PERC'].toString(),fontSize: 15,color: Colors.black,),
            ],
          ),
        ],
      ).p8(),
    ).pSymmetric(h: 15.0,v: 4.0);
  }
}

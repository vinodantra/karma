import 'package:karma/Constants/Library.dart';

import 'package:intl/intl.dart';
class ConveyReport extends GetView<ConveyReportController> {
  const ConveyReport({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(ConveyReportController());
    return Scaffold(


      appBar: AppBarWidget(title: "Conveyance Report",onPressAdd: (){},),
      body: SizedBox(
        width: Get.width,
        height: Get.height,
        child: Obx(()=>Stack(
          children: [
            ListView(
              children: [
                controller.listData.isNotEmpty?
                Column(
                  children: [
                    TextWidget("Total Amount",fontSize: 16,color: Colors.grey[500],fontWeight: FontWeight.w500,),
                    10.heightBox,
                    TextWidget(controller.listData.map((e) => e['AMOUNT']).toList().reduce((a, b) => a + b).toString(),fontSize: 24,color: Colors.black,fontWeight: FontWeight.w700,)
                  ],
                ).pSymmetric(v: 10.0) : const SizedBox(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextWidget("Select Month",fontSize: 16,color: Colors.grey[700],fontWeight: FontWeight.w500,),
                    InkWell(
                      onTap: ()async{
                        var de = await  CustomWidgets.pickMonth(context);

                        if(de != null) {
                          // controller.selectDate.value = de.toString();

                          controller.selectDate.value = DateFormat('MMM yyyy')
                              .format(de);

                          controller.getData();

                        }
                      },
                      child: ColoredBox(
                        color: Colors.transparent,
                        child: Row(
                          children: [
                            TextWidget("1 ${controller.selectDate.value}",fontSize: 16,color: Colors.black,fontWeight: FontWeight.w500,),
                            10.widthBox,
                            const Icon(Icons.calendar_today_outlined)
                          ],
                        ),
                      ),
                    ),
                  ],
                ).pSymmetric(h: 20.0),
                20.heightBox,
                controller.listData.isNotEmpty ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: List.generate(controller.listData.length, (index) => tile(controller.listData[index])),
                ) : controller.isLoading.value == false && controller.listData.isEmpty ?  Center(child: TextWidget("No data found.",fontSize: 24,color: Colors.black,)) : const SizedBox(),


              ],
            ),
            controller.isLoading.value ? const LoadingScreen() : const SizedBox(),
          ],
        )),
      ),
    );
  }

  tile(data) {
    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextWidget(data['COMPANY'],fontSize: 20,color: appColor.value,),
          10.heightBox,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextWidget("Date",fontSize: 18,color: Colors.grey[700],),
                  5.heightBox,
                  TextWidget(data['DATE'],fontSize: 18,color: Colors.black,),
                ],
              ),
              SizedBox(
                width: Get.width/3,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextWidget("Amount",fontSize: 18,color: Colors.grey[700],),
                    5.heightBox,
                    TextWidget(data['AMOUNT'].toString(),fontSize: 18,color: Colors.red,),
                  ],
                ),
              ),
            ],
          ),
          10.heightBox,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextWidget("From",fontSize: 18,color: Colors.grey[700],),
                  5.heightBox,
                  TextWidget(data['FROMLOC'],fontSize: 18,color: Colors.black,),
                ],
              ),
              SizedBox(
                width: Get.width/3,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextWidget("To",fontSize: 18,color: Colors.grey[700],),
                    5.heightBox,
                    TextWidget(data['TOLOC'].toString(),fontSize: 18,color: Colors.black,),
                  ],
                ),
              ),
            ],
          ),
          10.heightBox,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextWidget("By",fontSize: 18,color: Colors.grey[700],),
                  5.heightBox,
                  TextWidget(data['TRANSPORTMODE'],fontSize: 18,color: Colors.black,),
                ],





              ),
              SizedBox(
                width: Get.width/3,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextWidget("Remark",fontSize: 18,color: Colors.grey[700],),
                    5.heightBox,
                    TextWidget(data['REMARK'].toString(),fontSize: 18,color: Colors.black,),
                  ],
                ),
              ),
            ],
          ),
        ],
      ).p12(),
    ).pSymmetric(h: 15.0);
  }
}

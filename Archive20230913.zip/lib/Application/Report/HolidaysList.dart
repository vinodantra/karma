import 'package:karma/Constants/Library.dart';

class HolidaysList extends GetView<LeaveReportController> {
  const HolidaysList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(LeaveReportController());
    return Scaffold(
      appBar: AppBarWidget(title: "Holidays List-${DateTime.now().year}"),
      body: SizedBox(
        width: Get.width,
        height: Get.height,
        child: Obx(()=>Scrollbar(
          thickness: 5.0,
          trackVisibility: true,
          child: ListView(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                      width:Get.width / 3.5,
                      child: TextWidget("Date",fontSize: 20,color: appColor.value,)),
                  SizedBox(
                      width:Get.width / 3.5,
                      child: TextWidget("Type",fontSize: 20,color: appColor.value,textAlign: TextAlign.center,)),
                  SizedBox(
                      width:Get.width / 3.5,
                      child: TextWidget("Holidays",fontSize: 20,color: appColor.value,textAlign: TextAlign.center,)),
                ],
              ).pSymmetric(h: 15.0,v: 10.0),
              CustomWidgets.divider(),
              Column(
                children: List.generate(controller.holidaysList.length, (index) => Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                            width:Get.width / 3.5,
                            child: TextWidget(controller.holidaysList[index]['DATE'],fontSize: 14,color: Colors.black,
                            )),
                        SizedBox(
                            width:Get.width / 3.5,
                            child: TextWidget(controller.holidaysList[index]['TYPE'],fontSize: 14,color: Colors.black,maxLines: 2,
                            textAlign: TextAlign.center,)),
                        SizedBox(
                            width:Get.width / 3.5,
                            child: TextWidget(controller.holidaysList[index]['HOLIDAY'],fontSize: 14,color: Colors.black,maxLines: 2,
                            textAlign: TextAlign.center,)),
                      ],
                    ).pSymmetric(v: 10.0),
                    5.heightBox,
                    CustomWidgets.divider(),
                  ],
                )),
              ).pSymmetric(h: 15.0),

            ],
          ),
        ),),
      ),
    );
  }
}

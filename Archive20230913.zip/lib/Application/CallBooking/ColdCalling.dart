import 'dart:async';

import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../Constants/Library.dart';

class ColdCalling extends StatefulWidget {
  LocationData? locationData;
   ColdCalling({Key? key,this.locationData}) : super(key: key);

  @override
  _ColdCallingState createState() => _ColdCallingState();
}

class _ColdCallingState extends State<ColdCalling> {
  final Completer<GoogleMapController> _controller =
  Completer<GoogleMapController>();

  static const CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(37.42796133580664, -122.085749655962),
    zoom: 14.4746,
  );

  static const CameraPosition _kLake = CameraPosition(
      bearing: 192.8334901395799,
      target: LatLng(37.43296265331129, -122.08832357078792),
      tilt: 59.440717697143555,
      zoom: 19.151926040649414);


  @override
  Widget build(BuildContext context) {
    return Scaffold(body: SizedBox(
      width: Get.width,
      height: Get.height,
      child: GoogleMap(

        initialCameraPosition: _kGooglePlex,

      ),
    ),);
  }


}

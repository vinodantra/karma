import 'package:karma/Constants/Library.dart';


class SupportDetails extends GetView<SupportDetailsController> {
  const SupportDetails({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(SupportDetailsController());
    return Scaffold(
      appBar: AppBarWidget(
        title: "Call Details",
      ),
      body: SizedBox(
          width: Get.width,
          height: Get.height,
          child: Obx(
            () => Stack(
              children: [
                ListView(
                  children: [
                    tile(
                        title: "Company Person",
                        data: controller.supportDetails['CNTPER']),
                    tile(
                        title: "Email-ID",
                        data: controller.supportDetails['CNTEMAIL']),
                    tile(
                        title: "Level Of Call",
                        data: controller.supportDetails['PRIORITY']),
                    tile(
                        title: "Call Mode",
                        data: controller.supportDetails['MODEOFCALL']),
                    tile(
                        title: "Call Status",
                        data: controller.supportDetails['SUPSTATUS']),
                    tile(
                        title: "Call Category",
                        data: controller.supportDetails['SUPCATID']),
                    tile(
                        title: "Tally Serial No",
                        data: controller.supportDetails['TALLYSRNO']),
                    tile(
                        title: "Start Time",
                        data: controller.supportDetails['STARTTIME']),
                    tile(
                        title: "End Time",
                        data: controller.supportDetails['ENDTIME']),
                    tile(
                        title: "Remark",
                        data: controller.supportDetails['REMARK']),
                  ],
                ),
                controller.isLoading.value
                    ? const LoadingScreen()
                    :  const SizedBox(),
              ],
            ),
          )),
    );
  }

  Widget tile({String? title, String? data, String type = "1"}) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextWidget(
              title,
              color: const Color(0xff344053),
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
            type == "1"
                ? SizedBox(
                    width: Get.width / 2,
                    child: TextWidget(
                      data.toString(),
                      color: const Color(0xff667084),
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      textAlign: TextAlign.right,
                      maxLines: 10,
                    ),
                  )
                : InkWell(
                    onTap: () {
                      Utilities.onClickMobile(data!);
                    },
                    child: TextWidget(
                      Utilities.checkString(data!) ? data : "",
                      color: Colors.lightBlueAccent,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      textDecoration: TextDecoration.underline,
                    ),
                  ),
          ],
        ).pSymmetric(h: 15.0, v: 10.0),
        5.heightBox,
        Container(
          width: Get.width,
          height: 1.0,
          color: Colors.grey[300],
        ),
      ],
    );
  }
}




import 'package:karma/Constants/Library.dart';

import 'package:intl/intl.dart';
class CallBookingDetails extends GetView<CallBookingDetailsController> {
  const CallBookingDetails({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(CallBookingDetailsController());
    return Scaffold(
      appBar: AppBarWidget(
        title: "Call Details",
        onLocation: ()async{


          if(DateFormat('yyyy-MM-dd').format(DateTime.now()).toString() == controller.data['NRMLCALLDATE'])
            {
              if(Utilities.checkString(controller.data['CHKIN']) == false || controller.data['CHKIN'] == "00")
                {
                //  controller.isLoading.value = true;

                  CustomWidgets.showAlertDialog1(icon: const Icon(Icons.info,color: Colors.orangeAccent,size: 45,),
                  title: "Check In",content: "You want to check in?",text1:"Check In",onClick: ()async{
                    Get.back();
                        Loader();
                        LocationData locationData = await Utilities.getLocation();
                        String data = await  Utilities.getAddressFromLatLng(locationData.latitude!,locationData.longitude!);

                        controller.updateStatus(
                            controller.data, locationData.latitude.toString(),
                            locationData.longitude.toString(),data);
                      },text2: "Cancel",onCancel: (){


                    Get.back();
                      });
                  controller.isLoading.value = false;
                }
              else{
                controller.isLoading.value = true;

                CustomWidgets.showAlertDialog1(icon: const Icon(Icons.info_outline,color: Colors.orangeAccent,size: 50,),
                    title: "Check Out",content: "You want to check out?",text1:"Check out ",onClick: ()async{
                    Get.back();
                    Loader();
                      LocationData locationData = await Utilities.getLocation();
                      String data = await  Utilities.getAddressFromLatLng(locationData.latitude!,locationData.longitude!);

                      controller.updateStatus(
                          controller.data, locationData.latitude.toString(),
                          locationData.longitude.toString(),data);
                    },text2: "Cancel",onCancel: (){


                      Get.back();
                    });
                controller.isLoading.value = false;
              }

            }
          else
            {
              CustomWidgets.showDialog(title: "Access Denied",
              content: "You can only do check in/out for today's call.",);
            }
          // if(!Utilities.checkString(controller.data['CHKIN']) || !Utilities.checkString(controller.data['CHKOUT'])) {
          //
          //   if(!Utilities.checkString(controller.data['CHKIN']))
          //     {
          //       CustomWidgets.showAlertDialog1(title:"Are you sure?",content: "You want to Check In",onCancel: (){
          //         Get.back();
          //       },onClick: ()async{
          //         Get.back();
          //         LocationData locationData = await Utilities.getLocation();
          //
          //         controller.updateStatus(
          //             controller.data, locationData.latitude.toString(),
          //             locationData.longitude.toString());
          //       },text1: "Check In");
          //     }
          //   else if(Utilities.checkString(controller.data['CHKOUT']))
          //     {
          //       CustomWidgets.showAlertDialog1(title:"Are you sure?",content: "You want to Check Out",onCancel: (){
          //         Get.back();
          //       },onClick: ()async{
          //         Get.back();
          //         LocationData locationData = await Utilities.getLocation();
          //
          //         controller.updateStatus(
          //             controller.data, locationData.latitude.toString(),
          //             locationData.longitude.toString());
          //       },text1: "Check Out");
          //     }
          //
          // }
          // else
          //   {
          //     CustomWidgets.showAlertDialog(title:"Call Details",content: "You have already check in and check out");
          //   }
        },
        onStatus: (){

          CustomWidgets.customBottomSheet(controller.optionList1,
              "NAME", false, (value) {
            if(value['ID'] == "1")
              {
                Get.back();
                Get.to(()=> const CreateLead(),arguments: controller.data);
              }
            if(value['ID'] == "2")
              {
                Get.back();
                Get.to(()=> const Tickets(),arguments: controller.data);
              }
                if(value['ID'] == "3")
                  {

                    if(controller.data['CHKIN'] != "00")
                    {
                      Get.back();

                        Get.to(()=> const SupportList(),arguments: controller.data);
                    }
                    else
                    {
                      CustomWidgets.showDialog(title: "Opps!!",
                          content: "CheckIn Entry is must to be add Support Entry!");
                    }
                  }

            if(value['ID'] == "4")
            {
              Get.back();
              Get.to(()=> const ConveyanceEntry(),arguments: controller.data);
            }



              });
        },
      ),
      body: SizedBox(
        width: Get.width,
        height: Get.height,
        child: Obx(()=>Stack(
          children: [
            ListView(
              children: [
                tile(title: "Company Name",
                  data: controller.data['CMP'],
                ),
                tile(title: "Company Person",
                  data: controller.data['CNTPERSON'],
                ),
                tile(title: "Gateway Installation",
                  data: controller.data['GATEWAY'],
                ),
                tile(title: "Admin Email",
                  data: controller.data['ADMINEMAIL'],
                ),
                tile(title: "Account Owner",
                  data: controller.data['ACCOWNER'],

                ),
                tile(title: "Acc Owner No",
                    data: controller.data['ACCMOBILE'],
                    type: "2"
                ),
                tile(title: "Customer Mobile",
                    data: controller.data['MOB'],
                    type: "2"
                ),
                tile(title: "Landline",
                    data: controller.data['PHONE'],
                    type: "2"
                ),tile(title: "Address",
                  data: controller.data['ADDRESS'],
                ),
                tile(title: "Call Date",
                  data: controller.data['CALLDATE'],
                ),
                tile(title: "Tally Serial No",
                  data: controller.data['TALLYSRLNO'],
                ),
                tile(title: "Call Schedule",
                  data: controller.data['SHEDULE'],
                ),
                tile(title: "Remark",
                  data: controller.data['REMARK'],
                ),
                tile(title: "Note",
                  data: controller.data['SPNOTE'],
                ),


              ],
            ),
            controller.isLoading.value ? const LoadingScreen() : const SizedBox(),
          ],
        ))
      ),
    );
  }

  Widget tile({String?title,String? data,String type = "1" }){
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextWidget(
              title,

              color: const Color(0xff344053),
              fontSize: 16,

              fontWeight: FontWeight.w500,

            ),
           type == "1" ?
           SizedBox(
             width: Get.width / 2,
             child: TextWidget(
                data,

                color: const Color(0xff667084),
                fontSize: 16,

                fontWeight: FontWeight.w500,
               textAlign: TextAlign.right,
               maxLines: 10,

              ),
           ) : InkWell(
             onTap: (){
               Utilities.onClickMobile(data!);
             },
              child: TextWidget(
               data,
               color: Colors.lightBlueAccent,
               fontSize: 16,

               fontWeight: FontWeight.w500,
                textDecoration: TextDecoration.underline,

           ),
            ),
          ],
        ).pSymmetric(h: 15.0,v: 10.0),
        5.heightBox,
        Container(
          width: Get.width,
          height: 1.0,
          color: Colors.grey[400],
        ),
      ],
    );
  }
}

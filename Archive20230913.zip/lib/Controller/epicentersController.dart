import 'package:karma/Constants/Library.dart';

class EpicentersController extends GetxController{
  RxList<dynamic> mstdtlsList = [].obs;
  RxList<dynamic> list = [].obs;
  RxList<dynamic> epcdtlsList = [].obs;
  RxBool isLoading = false.obs;
  final search =  TextEditingController();
  @override
  void onInit() {
    getData();
    super.onInit();
  }

  void getData() async{
    isLoading.value = true;
    Api().fetchApi(data: json.encode({"UID":DataInfo.userId.value,"UNAME":DataInfo.username.value}),action: "GETEPCDATA").then((value) {
      if(value!.success) {
        var response = value.data!;

        mstdtlsList.value = response['RESULT']['MSTDTLS'];
        list.value = response['RESULT']['MSTDTLS'];
        epcdtlsList.value = response['RESULT']['EPCDTLS'];
        isLoading.value = false;

      }

    });

  }
}
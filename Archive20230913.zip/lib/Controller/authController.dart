// ignore_for_file: file_names

import 'dart:developer';
import 'dart:io';

import 'package:karma/Application/Dashboard/DashboardNew.dart';
import 'package:karma/Constants/Library.dart';
import 'package:karma/Controller/appThemeController.dart';
import 'package:karma/Controller/notificationController.dart';
import 'package:provider/provider.dart';

class AuthController extends GetxController {

  NotificationController notificationController = NotificationController();
  @override
  void onReady() {

    Utilities.getPackageInfo();
    notificationController.requestNotificationPermission();
    checkData();
    super.onReady();
  }

   getDeviceInfo() async {
    Map<String, dynamic> deviceData = <String, dynamic>{};

   try{
     if(!kIsWeb) {
       DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();

       AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;

       IosDeviceInfo iosInfo = await deviceInfo.iosInfo;

       if (Platform.isAndroid) {
         DataInfo.isPhysicalDevice.value = androidInfo.isPhysicalDevice;

         DataInfo.deviceName.value =
         "${androidInfo.manufacturer} ${androidInfo.product}";
         DataInfo.platform.value = Platform.isIOS
             ? "IOS"
             : Platform.isAndroid
             ? "ANDROID"
             : "";
         DataInfo.device.value =
         "${androidInfo.manufacturer} ${androidInfo.product}";
         DataInfo.deviceId.value = androidInfo.id;
         DataInfo.deviceToken.value = "";
         deviceData = {
           'deviceName': "${androidInfo.manufacturer} ${androidInfo.product}",
           'device': "${androidInfo.manufacturer} ${androidInfo.product}",
           'deviceId': androidInfo.id,
           'deviceToken': "",
           'platform': Platform.isIOS
               ? "IOS"
               : Platform.isAndroid
               ? "ANDROID"
               : ""
         };
       }
       else {
         DataInfo.isPhysicalDevice.value = iosInfo.isPhysicalDevice;
         DataInfo.isPhysicalDevice.value = androidInfo.isPhysicalDevice;

         DataInfo.deviceName.value =
         "${iosInfo.name}";
         DataInfo.platform.value = Platform.isIOS
             ? "IOS"
             : Platform.isAndroid
             ? "ANDROID"
             : "";
         DataInfo.device.value =
         "${iosInfo.name}";
         DataInfo.deviceId.value = iosInfo.identifierForVendor!;
         DataInfo.deviceToken.value = "";
         deviceData = {
           'deviceName': "${iosInfo.name}",
           'device': "${iosInfo.name}",
           'deviceId': iosInfo.identifierForVendor,
           'deviceToken': "",
           'platform': Platform.isIOS
               ? "IOS"
               : Platform.isAndroid
               ? "ANDROID"
               : ""
         };
       }
     }
   }catch(e){
     log("device error:${e.toString()}");
   }
   // Get.put(DeviceInfo.fromMap(deviceData));
  }

  void checkData() async{
      await getDeviceInfo();
      await updateTheme();
    try{
      if (DataInfo.box.hasData('userId') && DataInfo.box.hasData("userInfo")) {
        var loginData = json.decode(DataInfo.box.read('userData'));
        await login(loginData);

        //Get.offAll(() => const Dashboard());
      } else {

        Get.offAll(() => const LoginPage());
      }
    }catch(e){
      log("check data:${e.toString()}");
    }
  }
  Future<void> login(var loginData) async {

    Api().fetchApi(data:json.encode({
      "USER":loginData['username'],
      "PWD": loginData['password'],
      "VERSION": "536",
      "DEVICETYPE": Platform.isAndroid ? "ANDROID" : 'IOS'
    }),action: "LOGIN").then((value) {
      try {


          if(value!.success){
            if (value.data.toString().contains("Invalid Username or Password") ==
                false) {
              var jsonResponse =
                  value.data;
              if (jsonResponse['records'].first['STATUS'] == "Yes") {

                var userData = jsonResponse['records'].first;
                log("user data :${userData}");
                DataInfo.username.value = loginData['username'];
                DataInfo.password.value = loginData['password'];
                DataInfo.userId.value = userData['UID'];
                DataInfo.profileId.value = userData['UID'];
                DataInfo.enrollId.value = userData['ENROLLID'];
                DataInfo.rollId.value = userData['ROLLID'];
                DataInfo.imageUrl.value = userData['IMGURL'];
                DataInfo.pid.value = userData['PID'];
                DataInfo.desCat.value = userData['DESCAT'];
                DataInfo.encKey.value = userData['ENCKEY'];
                DataInfo.tcId.value =userData['TCID'];

                //DataInfo.aboutMe.value = userData['ABOUTME'];

                var data = DataInfo.box.read("userInfo");

                DataInfo.fullName.value = data['FULLNAME'];
                DataInfo.name.value = data['NAME'];
                DataInfo.designation.value = data['DESIGNATION'];
                DataInfo.mobile.value = data['MOBILE'];
                DataInfo.email.value = data['USEREMAIL'];
                DataInfo.box.write("status", 1);

                 registerData(userData);
              }
            } else {

              CustomWidgets.snackBar(title: value.data.toString());
            }
          }

      } catch (e) {
        log("login error:$e");
      }
    });

  }

  void registerData(var userData) async {
    NotificationController notificationController = NotificationController();
    String? deviceToken = await notificationController.getToken();

    log("Device Token:${deviceToken.toString()}");
    Api().fetchApi(data:json.encode({
      "Uid": DataInfo.userId.value,
      "tokenID": DataInfo.deviceId.value,
      "device": DataInfo.platform.value,
      "UUID":kReleaseMode ?  deviceToken.toString() : ""
    }),action: "REGISTERID").then((value) {
      try {


        if (value!.data == "YES") {

          DataInfo.box.write("userId", DataInfo.userId.value);
          userData['username'] = DataInfo.username.value;
          userData['password'] = DataInfo.password.value;
          DataInfo.box.write("userData", json.encode(userData));
          getUserData();
          Get.offAll(() => const  DashboardNew());
        } else {

          CustomWidgets.snackBar(title: "Server Error");
        }
      } catch (e) {
        log("register error: $e");
      }
    });

  }
  getUserData() async {
    var responseData = await Apis.sendData(
        DataInfo.username.value, "GETUSERDITAILS&ENCKEY=${DataInfo.encKey.value}&SRC=KARMA");
    var de = json.decode(responseData.body);
    var data = de[0];
    DataInfo.box.write("userInfo", data);
    DataInfo.fullName.value = data['FULLNAME'];
    DataInfo.name.value = data['NAME'];
    DataInfo.designation.value = data['DESIGNATION'];
    DataInfo.mobile.value = data['MOBILE'];
    DataInfo.email.value = data['USEREMAIL'];
    DataInfo.aboutMe.value =  data['ABOUTME'];


  }

  updateTheme() async{
    final themeController = Provider.of<AppThemeController>(Get.context!,listen: false);
    if(DataInfo.box.hasData("theme")){
      int index = DataInfo.box.read("theme");

      DataInfo.selectTheme.value  = index - 1;
      if(DataInfo.selectTheme.value == -1){
        DataInfo.selectTheme.value = index;
      }
      appGradientColor.value = appTheme[index - 1];
      appColor.value = appColorList[index - 1];
      var theme = Get.put(AppTheme());
      theme.appGradientColor.value = appTheme[index - 1];
      theme.appColor.value = appColorList[index - 1];
      theme.changeTheme(appTheme[index - 1]);
      themeController.changeTheme(appTheme[index - 1]);
      update();
    }
    else{

      DataInfo.selectTheme.value  = 1;
      appGradientColor.value = appTheme.first;
      appColor.value = appColorList.first;
      var theme = Get.put(AppTheme());
      theme.appGradientColor.value = appTheme.first;
      theme.appColor.value = appColorList.first;
      theme.changeTheme(appTheme.first);
      themeController.changeTheme(appTheme.first);
      update();
    }


  }
}

import '../Constants/Library.dart';

class TicketStatusController extends GetxController{
  RxBool isLoading = false.obs;
  RxList<dynamic> ticketList = [].obs;
  RxList<dynamic> ticketStatus = [{"ID":"0","NAME":"Normal"},{"ID":"1","NAME":"Escalation"},
    {"ID":"2","NAME":"Emergency"},{"ID":"3","NAME":"Experience"}].obs;
  RxString selectTicketStatus = "".obs;
  RxString selectTicketStatusId = "".obs;
  @override
  void onInit() {
    getData();
    super.onInit();
  }

  void getData() async{
    isLoading.value = true;
    Api().fetchApi(data:"30|${DataInfo.userId.value}",action: "GETSUPPALLPENDTICKET").then((value) {
      try{

        if(value!.success)
        {
          var jsonData = value.data;
          ticketList.value = jsonData['records'];

          isLoading.value = false;

        }
        else
        {
          isLoading.value = false;
        }
      }catch(e){
        isLoading.value = false;
      }
    });

  }
  void updateStatus(String ticket,String id) async{

    Api().fetchApi(data:"$ticket|$id",action: "ACTTCKUPDATE").then((value) {

      try{

        if(value!.success)
        {
         getData();

        }
        else
        {
          isLoading.value = false;
        }
      }catch(e){
        isLoading.value = false;
      }
    });

  }


}
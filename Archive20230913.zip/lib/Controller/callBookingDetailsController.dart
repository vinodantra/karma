import 'dart:developer';
import 'package:karma/Constants/Library.dart';

class CallBookingDetailsController extends GetxController {
  RxMap data = {}.obs;
  List<dynamic> optionList1 = [
    {"ID": "1", "NAME": "Create Lead"},
    {"ID": "2", "NAME": "Ticket History"},
    {"ID": "3", "NAME": "Support/Visit History"},
    {"ID": "4", "NAME": "Conveyance Entry"},
  ];
  RxBool isLoading = false.obs;
  @override
  void onInit() {
    data.value = Get.arguments;

    DataInfo.dpId.value = data['COMPANYID'].toString();
    super.onInit();
  }

  Future<void> updateStatus(
      var data, String latitude, String longitude, String address) async {
    isLoading.value = true;
    String sendData = "";
    sendData =
        "${data['ID']}|${data['COMPANYID']}|${DateTime.now()}|$latitude,$longitude||$latitude|$longitude|${data['UNAME']}|${DataInfo.userId.value}|";
    Api().fetchApi(data: sendData.trim(), action: "CHKINOUTDATA").then((value) {
      try {
        if (value!.success) {
          var response = value.data;
          if (response == "YES") {
            getData();
            Get.dialog(Center(
              child: Card(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextWidget(
                      "Check In/Out",
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      textAlign: TextAlign.center,
                    ).p8(),
                    Container(
                      width: Get.width,
                      height: 1.0,
                      color: Colors.grey[400],
                    ),
                    10.heightBox,
                    TextWidget(
                      address,
                      fontSize: 16,
                      maxLines: 10,
                      textAlign: TextAlign.center,
                    ),
                    10.heightBox,
                    CustomButton(
                      text: "OK",
                      onPressed: () {
                        Get.back();

                      },
                      width: 120,
                      height: 40,
                    )
                  ],
                ).p8(),
              ).p8(),
            )).then((value) => Get.back(canPop: false));
          } else {
            CustomWidgets.snackBar(title: value.data);
          }

          isLoading.value = false;
        } else {
          isLoading.value = false;
        }
      } catch (e) {
        isLoading.value = false;

        if (kDebugMode) {
          print("error:$e");
        }
      }
    });
  }
  void getData() async{

    Api().fetchApi(data: DataInfo.userId.value,action: "CALLBOOK").then((value) {
      try{
        if(value!.success) {
          var response = value.data!;


          List<dynamic> jsonData = response['ROOT'][0]['DETAILS'];

          List<dynamic> list = jsonData.where((element) => element['ID'].toString() == data['ID'].toString()).toList();
          if(list.isNotEmpty){
            data.value = list.first;
          }


        }
        else{
          isLoading.value = false;
        }
      }catch(e){
        isLoading.value = false;
      }
    });
    // try{
    //   var responseData = await Apis.sendData4(
    //       id.value,
    //       "CALLBOOK");
    //
    //   if(responseData != null)
    //   {
    //     var jsonResponse =
    //     json.decode(responseData.body);
    //
    //     var jsonData = jsonResponse['ROOT'][0]['DETAILS'];
    //
    //     for(int  i = 0;i<jsonData.length;i++)
    //       {
    //
    //         if(DateTime.parse(jsonData[i]['NRMLCALLDATE']).isAfter(DateTime.now()))
    //         {
    //          // callList.add(jsonData[i]);
    //
    //           fCallList.add(jsonData[i]);
    //           fCallList.sort((a, b) => a['CALLDATE'].compareTo(b['CALLDATE']));
    //         }
    //         else if(DateFormat('yyyy-MM-dd').format(DateTime.now()).toString() == jsonData[i]['NRMLCALLDATE'])
    //         {
    //           //todayCallList.add(jsonData[i]);
    //
    //
    //           fTodayCallList.add(jsonData[i]);
    //           fTodayCallList.sort((a, b) => a['CALLDATE'].compareTo(b['CALLDATE']));
    //         }
    //
    //         else
    //           {
    //           //  previousCallList.add(jsonData[i]);
    //             fPreviousCallList.add(jsonData[i]);
    //             fPreviousCallList.sort((a, b) => a['CALLDATE'].compareTo(b['CALLDATE']));
    //
    //
    //           }
    //
    //       }
    //     callList.value = fCallList.reversed.toList();
    //     todayCallList.value = fTodayCallList.reversed.toList();
    //     previousCallList.value = fPreviousCallList.reversed.toList();
    //     isLoading.value = false;
    //
    //   }
    //   else
    //   {
    //     isLoading.value = false;
    //   }
    // }catch(e){
    //   isLoading.value = false;
    //   if (kDebugMode) {
    //     print("error:$e");
    //   }
    // }
  }
}

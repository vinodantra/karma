import 'dart:developer';
import 'package:karma/Constants/Library.dart';

class OpportunityDataController extends GetxController {
  RxMap data = {}.obs;
  RxString selectType = "1".obs;
  RxList<dynamic> activityList = [].obs;
  RxList<dynamic> proposalList = [].obs;
  RxString proformaData = "".obs;

  @override
  void onInit() {
    data.value = Get.arguments;

    getActivityData();
    getProposalData();
    getProformaData();
    super.onInit();
  }

  getActivityData() async {
    Api()
        .fetchApi(
            data: json
                .encode({"OPPID": "${data['ID']}", "DPID": "${data['DPID']}"}),
            action: "OPPRECENTACTIVITY")
        .then((value) {
      try {
        if (value!.success) {
          var jsonResponse = value.data;
          activityList.value = jsonResponse;
        }
      } catch (e) {
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });
  }

  getProposalData() async {
    Api()
        .fetchApi(
            data: json
                .encode({"OPPID": "${data['ID']}", "DPID": "${data['DPID']}"}),
            action: "PROPOSALLIST")
        .then((value) {
      try {
        if (value!.success) {
          var jsonResponse = value.data;
          proposalList.value = jsonResponse;
        }
      } catch (e) {
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });
  }

  getProformaData() async {
    Api()
        .fetchApi(
            data: json.encode({
              "OPPID": "${data['ID']}",
              "DPID": "${data['DPID']}",
              "ISMAIL": "220"
            }),
            action: "PREFORMAINVOIC")
        .then((value) {
      try {
        if (value!.success) {
          var jsonResponse = value.data;
          proformaData.value = jsonResponse;
        }
      } catch (e) {
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });
  }
}

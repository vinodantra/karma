import 'dart:developer';
import '../Constants/Library.dart';
class OutstandingController extends GetxController{
  RxList<dynamic> list = [].obs;
  RxString date = "".obs;
  @override
  void onInit() {
    getData();
    super.onInit();
  }

  void getData() async{

    try{
      await Future.delayed(const Duration(microseconds: 500));
      Loader();
      Api().fetchApi(
          data: json.encode({"UNAME":DataInfo.username.value,"UID":DataInfo.userId.value,"UST":"GROUP"}),
          action: "USEROUTSTANDING").then((value) {

            if(value!.success){
              date.value = value.data['LASTUPDATE'][0]['DATE'].toString();
                list.value = value.data['MIS'];
              Loader().hide();
            }else{
              Loader().hide();
            }

      });
    }catch(e){
      log("error:$e");
      Loader().hide();
    }

  }
}
import '../Constants/Library.dart';
class TicketDetailsController extends GetxController{
  RxMap args = {}.obs;
  RxBool isLoading =  false.obs;
  RxMap ticketData = {}.obs;
  RxList<dynamic> interactionList = [].obs;
  @override
  void onInit() {
    args.value = Get.arguments;

    getData();
    super.onInit();
  }
  void getData() async{
    isLoading.value = true;



    try{

      var response =  await Apis.sendData5("TICKETDETAILS|${args['TICKET']}|");
      if(response != null){
        var responseData = json.decode(response.body);

        ticketData.value = responseData['ROOT']['ticket_details'];
        interactionList.value = responseData['ROOT']['ticket_details']['interaction'];

        isLoading.value = false;

      }
      else{
        isLoading.value = false;
      }
    }catch(e){
      print("error1:${e.toString()}");
      isLoading.value = false;
    }

  }
}
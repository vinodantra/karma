import 'package:firebase_messaging/firebase_messaging.dart';

class NotificationController {
  FirebaseMessaging firebaseMessaging =  FirebaseMessaging.instance;
  void requestNotificationPermission()async{
    NotificationSettings notificationSettings = await firebaseMessaging.requestPermission(
      alert: true,
      announcement: true,
      badge: true,
      criticalAlert: true,
      provisional: true,
      sound: true
    );
    if(notificationSettings.authorizationStatus== AuthorizationStatus.authorized){

    }
  }
  Future<String?> getToken()async{

    return await firebaseMessaging.getToken();

  }
}
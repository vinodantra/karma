import 'package:karma/Constants/Library.dart';

class SupportListController extends GetxController {
  RxMap data = {}.obs;
  RxList<dynamic> list = [].obs;
  RxBool isLoading = false.obs;
  @override
  void onInit() {
    data.value = Get.arguments;
    getData();
    super.onInit();
  }

  void getData() async {
    isLoading.value = true;


    Api().fetchApi(
        data:data['ID'],
        action: "EXISTSUPENTRY").then((value){
      try {


        if (value!.success) {
          var jsonResponse = value.data;
          if (jsonResponse['ROOT'][0] != null) {
            var jsonData = jsonResponse['ROOT'][0]['DETAILS'];

            list.value = jsonData;
          }

          isLoading.value = false;
        } else {
          isLoading.value = false;
        }
      } catch (e) {
        isLoading.value = false;
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });

  }
}

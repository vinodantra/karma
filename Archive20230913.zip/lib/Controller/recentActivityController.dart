import 'package:karma/Constants/Library.dart';
class RecentActivityController extends GetxController{
  RxMap data  = {}.obs;
  RxString selectType = "1".obs;
  RxList<dynamic> activityList = [].obs;
  RxList<dynamic> proposalList = [].obs;
  RxString proformaData = "".obs;
  RxBool isLoading  = false.obs;
  @override
  void onInit() {
    data.value = Get.arguments;
    getActivityData();
    super.onInit();
  }
  getActivityData()async{
    isLoading.value = true;

    Api().fetchApi(
        data: json.encode({"OPPID":"0","DPID":"${data['DPID']}"}),
        action: "OPPRECENTACTIVITY").then((value) {
      try{

        if(value!.success)
        {
          var jsonResponse =
          value.data;
          activityList.value = jsonResponse;

          isLoading.value = false;
        }

      }catch(e){
        isLoading.value = false;
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });


  }
}
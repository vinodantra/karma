import '../Constants/Library.dart';
class ProfileController extends GetxController{
 final fullName =  TextEditingController();
 final designation = TextEditingController();
 RxBool isLoading = false.obs;

 @override
  void onInit() {
    fullName.text =  DataInfo.name.value;
    designation.text  = DataInfo.designation.value;
    super.onInit();
  }

  updateData() async{
   isLoading.value = true;
   Api().fetchApi(data:"${fullName.text.trim()}|${designation.text.trim()}|${DataInfo.mobile.value}|${DataInfo.email.value}|${DataInfo.username.value}",action: "UPDATEUSERDETAILS").then((value) {
     try{

       if(value!.success)
       {
         getUserData();
          Get.back();

         isLoading.value = false;

       }
       else
       {
         isLoading.value = false;
         return null;
       }
     }catch(e){
       isLoading.value = false;
       if (kDebugMode) {
         print("error:$e");
       }
       return null;
     }
   });

 }

 getUserData() async {
   var responseData = await Apis.sendData(
       DataInfo.username.value, "GETUSERDITAILS&ENCKEY=${DataInfo.encKey.value}&SRC=KARMA");
   var de = json.decode(responseData.body);
   var data = de[0];
   DataInfo.box.write("userInfo", data);
   DataInfo.fullName.value = data['FULLNAME'];
   DataInfo.name.value = data['NAME'];
   DataInfo.designation.value = data['DESIGNATION'];
   DataInfo.mobile.value = data['MOBILE'];
   DataInfo.email.value = data['USEREMAIL'];
   DataInfo.aboutMe.value =  data['ABOUTME'];


 }

}
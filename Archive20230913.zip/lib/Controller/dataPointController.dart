import 'package:karma/Constants/Library.dart';

class DataPointController extends GetxController{
  RxList<dynamic> dataPointList = [].obs;
  RxList<dynamic> listData = [].obs;
  RxBool isLoading = false.obs;
  RxString search = "".obs;
  TextEditingController searchController = TextEditingController();
  @override
  void onInit() {
    getData();
    super.onInit();
  }






  void getData() async{
    isLoading.value = true;

    Api().fetchApi(data:DataInfo.username.value,action: "GETDATAPOINT").then((value) {
      try{

        if(value!.success)
        {
          var jsonResponse =
          value.data;

          var data = jsonResponse['ROOT'][0]['DETAILS'];
          dataPointList.value = data;
          listData.value = data;

          isLoading.value = false;
          update();
        }
        else
        {
          isLoading.value = false;
        }
      }catch(e){
        isLoading.value = false;
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });

  }

  dynamic getUserData(String dpId) async{
    isLoading.value = true;
    Api().fetchApi(data:dpId,action: "GETUSER").then((value) {
      try{

        if(value!.success)
        {
          var jsonResponse =
          value.data;

          var data = jsonResponse['records'];


          isLoading.value = false;
          update();
          return data;
        }
        else
        {
          isLoading.value = false;
          return null;
        }
      }catch(e){
        isLoading.value = false;
        if (kDebugMode) {
          print("error:$e");
        }
        return null;
      }
    });

  }
  searchUser() {
    dataPointList.value = listData
        .where((element) => element['DPNAME']
        .toString()
        .trim()
        .toLowerCase()
        .contains(search.trim().toLowerCase()))
        .toList();
    update();
  }
}
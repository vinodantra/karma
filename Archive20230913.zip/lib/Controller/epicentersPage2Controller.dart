import 'dart:developer';

import '../Constants/Library.dart';
class EpicentersPage2Controller extends GetxController{
  RxMap<String,dynamic> args = <String,dynamic>{}.obs;

  RxList<dynamic> list = [].obs;
  RxList<dynamic> list1 = [].obs;
  RxList<dynamic> listData = [].obs;
  RxString id = "".obs;
  final search =  TextEditingController();
  RxBool isLoading = false.obs;


  @override
  void onInit() {
    args.value = Get.arguments;
    id.value = args['id'];
    list1.value = args['data'];
    list.value = list1.where((element) => element['EPIID'].toString() == id.value).toList();
    listData.value = list1.where((element) => element['EPIID'].toString() == id.value).toList();

    log(args.toString());

    super.onInit();
  }
}
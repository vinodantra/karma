import 'package:karma/Constants/Library.dart';

class ContactDetailsController extends GetxController{
  RxList<dynamic> contactList = [].obs;
  RxBool isLoading = false.obs;
  RxMap data  = {}.obs;
  @override
  void onInit() {
    data.value = Get.arguments;
    getData();
    super.onInit();
  }

  void getData() async{
    isLoading.value = true;



    Api().fetchApi(data:data['DPID'],action: "GETUSER").then((value) {
      try{

        if(value!.success)
        {
          var jsonResponse =
          value.data;

          var data = jsonResponse['records'];
          contactList.value = data;

          isLoading.value = false;

        }
        else
        {
          isLoading.value = false;
        }
      }catch(e){
        isLoading.value = false;
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });

  }
}
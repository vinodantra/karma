import 'package:karma/Constants/Library.dart';

class SupportDetailsController extends GetxController {
  RxMap data = {}.obs;
  RxBool isLoading = false.obs;
  RxMap supportDetails = {}.obs;
  @override
  void onInit() {
    data.value = Get.arguments;
    getData();
    super.onInit();
  }

  void getData() async {
    isLoading.value = true;
    Api().fetchApi(data: data['ID'], action: "SUPENTRY").then((value){
      try {


        if (value!.success) {
          var jsonResponse = value.data;

          supportDetails.value = jsonResponse['ROOT'][0]['DETAILS'][0];

          isLoading.value = false;
        } else {
          isLoading.value = false;
        }
      } catch (e) {
        isLoading.value = false;
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });




  }
}

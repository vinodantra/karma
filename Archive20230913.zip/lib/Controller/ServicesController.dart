import 'package:karma/Constants/Library.dart';
class ServicesController extends GetxController{
  RxBool  isLoading = false.obs;
  RxMap data  = {}.obs;
  RxList<dynamic> boosterList = [].obs;
  RxList<dynamic> addonsList  = [].obs;
@override
  void onInit() {
  data.value = Get.arguments;
    getData(data);
    super.onInit();
  }

  void getData(var data) async{
    isLoading.value = true;



    Api().fetchApi(
        data:json.encode({"DPID":data['DPID']}), action: "GETDPPRODUCTINFO").then((value) {
      try{


        if(value!.success)
        {
          var jsonResponse =
          value.data;
          addonsList.value =  jsonResponse['ADDONS'];
          if(jsonResponse.containsKey('BOOSTER'))
          {
            boosterList.value = jsonResponse['BOOSTER'];
          }



          isLoading.value = false;
          update();
        }
        else
        {
          isLoading.value = false;
        }
      }catch(e){
        isLoading.value = false;
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });

  }
}
import 'package:karma/Constants/Library.dart';

class LeadController extends GetxController{



  RxList<dynamic> filterData = [{"ID":"1",
    "NAME":"Given"},{"ID":"2",
    "NAME":"Received"},].obs;
  RxMap<String,dynamic> leadData = <String,dynamic>{}.obs;
  RxBool isLoading =  false.obs;
  RxString selectFilterData = "Given".obs;
  @override
  void onInit() {
    getData();
    super.onInit();
  }

  void getData() async{
    isLoading.value = true;
    leadData.value = {};
    await Future.delayed(const Duration(seconds: 2));
    Api().fetchApi(data: json.encode({"LEADTYPE":selectFilterData.value.toUpperCase(),"UID":DataInfo.userId.value}),action: "LEADDASHBOARD").then((value) {
      if(value!.success) {
        var response = value.data!;
         if(response['ROOT'][0].containsKey("DETAILS"))
           {
             leadData.value =  response['ROOT'][0]['DETAILS'][0];
             isLoading.value = false;
           }
      }

      else{
        leadData.value = {};
        isLoading.value = false;
      }
    });
  }
}

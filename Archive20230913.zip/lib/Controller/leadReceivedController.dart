import 'package:karma/Constants/Library.dart';
class LeadReceivedController extends GetxController{
  RxString lead = "".obs;
  RxString leadType = "".obs;
  RxList<dynamic> list = [].obs;
  RxBool isLoading =  false.obs;
  final description = TextEditingController();
  RxList<dynamic> ticketTypeList = [].obs;
  RxString selectTicket = "Ticket Type".obs;
  RxString selectTicketId = "".obs;
  @override
  void onInit() {
    lead.value = Get.arguments['lead'];
    leadType.value = Get.arguments['leadtype'];


    getData();
    getTickerData();
    super.onInit();
  }





  void getData() async{
    isLoading.value = true;


    try{
      Api().fetchApi(data: json.encode({"USERID":DataInfo.userId.value,"LEADTYPE":leadType.value.toUpperCase(),}),action: lead.value == "Given" ? "LEADLIST":"RCVLEADLIST").then((value) {
        if(value!.success) {
          var response = value.data!;
          if(response['ROOT'][0].containsKey("DETAILS"))
          {
            list.value =  response['ROOT'][0]['DETAILS'];

            isLoading.value = false;
          }
          else{
            isLoading.value = false;
          }
        }

        else{

          isLoading.value = false;
        }
      });
    }catch(e){
      isLoading.value = false;
    }
  }

  void getTickerData() async{
    try{
      Api().fetchApi(action: "TCKLEADSTYPE").then((value) {
        if(value!.success) {
          var response = value.data!;
          ticketTypeList.value = response['records'];
        }


      });
    }catch(e){
      if (kDebugMode) {
        print(e);
      }
    }
  }
  createTicket(String id)async{
    Loader();
    if(selectTicketId.isEmpty){
      CustomWidgets.snackBar(title: "Please select Ticket Type");
    }
    else{
      try{
        Api().fetchApi(data:json.encode({"LEADID":id,"LEADTYPE":selectTicketId.value,"DESCR":description.text.trim()}), action: "LEADTICKET").then((value) {
          selectTicket.value = "";
          selectTicketId.value = "";
          description.clear();

          Loader().hide();

          CustomWidgets.showDialog(title: "Alert",content: value!.message);
          getData();

        });
      }catch(e){
        Loader().hide();
        if (kDebugMode) {

          print(e);
        }
      }
    }
  }
}
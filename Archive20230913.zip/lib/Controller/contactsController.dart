import 'dart:developer';
import 'package:karma/Constants/Library.dart';

class ContactsController extends GetxController {
  RxList<dynamic> contactList = [].obs;
  RxList<dynamic> listData = [].obs;
  RxBool isLoading = false.obs;
  RxString search = "".obs;
  final searchController =  TextEditingController();
  @override
  void onInit() {
    getData();
    super.onInit();
  }

  void getData() async {
    isLoading.value = true;

    Api().fetchApi(action: "ANTRAUSER&ISNEW=YES").then((value) {
      try {
        if (value!.success) {
          var jsonData = value.data;
          contactList.value = jsonData['records'];
          listData.value = jsonData['records'];
          log("de:${contactList.first}");
          isLoading.value = false;
        } else {
          isLoading.value = false;
        }
      } catch (e) {
        if (kDebugMode) {
          print("error:$e");
        }
        isLoading.value = false;
      }
    });
  }
  searchUser() {
    contactList.value = listData
        .where((element) => element['NAME']
        .toString()
        .trim()
        .toLowerCase()
        .contains(search.trim().toLowerCase()) || element['DESIGNATION']
        .toString()
        .trim()
        .toLowerCase()
        .contains(search.trim().toLowerCase()))
        .toList();
    update();
  }
}

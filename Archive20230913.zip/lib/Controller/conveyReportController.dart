import 'package:karma/Constants/Library.dart';
import 'package:intl/intl.dart';
class ConveyReportController extends GetxController{
  RxBool isLoading = false.obs;
  RxList<dynamic> listData = [].obs;

  RxString selectDate = DateFormat('MMM yyyy')
      .format(DateTime.now()).obs;
  @override
  void onInit() {
    getData();
    super.onInit();
  }

  void getData() async{

    isLoading.value = true;
    Api().fetchApi(data: DataInfo.username.value,action: "GETUSERDITAILS").then((value) {
     if(value!.success) {
  var response = value.data!;

 // isLoading.value = false;
  }

    });


    Api().fetchApi(data: json.encode({"UNAME":DataInfo.username.value,"FROMDATE":"1 ${selectDate.value}"}),action: "CONVREPORT").then((value) {
      if(value!.success) {
        var response = value.data!;

        listData.value = response;
        isLoading.value = false;

      }

    });


  }



}
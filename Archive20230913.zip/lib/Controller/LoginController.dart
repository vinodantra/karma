// ignore_for_file: file_names
import 'dart:io';

import 'package:karma/Application/Dashboard/DashboardNew.dart';
import 'package:karma/Controller/notificationController.dart';

import '../Constants/Library.dart';

class LoginController extends GetxController {
  final userNameController = TextEditingController();
  final passwordController = TextEditingController();
  RxBool isShowPassword = true.obs;
  bool isValid = true;
  RxString userNameErrorText = "".obs;
  RxString passwordErrorText = "".obs;
  RxBool isLoading = false.obs;
  RxBool isRemember = true.obs;
  void checkData() async {
    isValid = true;

    isLoading.value = true;
    Loader();

    userNameErrorText.value = "";
    passwordErrorText.value = "";

    if (userNameController.text.trim().isEmpty) {
      isValid = false;
      isLoading.value = false;
      Loader().hide();
      userNameErrorText.value = "Please enter username";
    }
    // if(emailController.text.isNotEmpty && emailController.text.trim().validateEmail() == false)
    //   {
    //       isValid = false;
    //       isLoading.value = false;
    //       emailErrorText.value = "Please enter valid email";
    //   }
    if (passwordController.text.trim().isEmpty) {
      isValid = false;
      isLoading.value = false;
      Loader().hide();
      passwordErrorText.value = "Please enter password";
    }
    if (isValid) {
      login();
    }
  }

  void login() async {

    Api().fetchApi(data: json.encode({
      "USER": userNameController.text.trim(),
      "PWD": passwordController.text.trim(),
      "VERSION": "536",
      "DEVICETYPE":  Platform.isAndroid ? "ANDROID" : 'IOS'
    }),action: "LOGIN").then((value) {
     if(value!.success)
       {
         isShowPassword.value = true;
         var response = value.data!;
         if (response['records'].first['STATUS'] == "Yes") {

           var userData = response['records'].first;
           DataInfo.username.value = userNameController.text.trim();
           DataInfo.password.value = passwordController.text.trim();
           DataInfo.userId.value = userData['UID'];
           DataInfo.profileId.value = userData['UID'];
           DataInfo.enrollId.value = userData['ENROLLID'];
           DataInfo.rollId.value = userData['ROLLID'];
           DataInfo.imageUrl.value = userData['IMGURL'];
           DataInfo.pid.value = userData['PID'];
           DataInfo.desCat.value = userData['DESCAT'];
           DataInfo.encKey.value = userData['ENCKEY'];
         //  DataInfo.aboutMe.value = userData['ABOUTME'];
           DataInfo.tcId.value = userData['TCID'];
           DataInfo.box.write("status", 1);
           if(DataInfo.desCat.value == "L1"){
             DataInfo.showData.value = true;
           }
           else{
             DataInfo.showData.value = false;
           }
           registerData(userData);
         }
         else
         {
           isLoading.value = false;
           Loader().hide();
         }
       }else{
       isLoading.value = false;
       Loader().hide();
     }

    });
    // try {
    //   var responseData = await Apis.sendData(
    //       json.encode({
    //         "USER": userNameController.text.trim(),
    //         "PWD": passwordController.text.trim(),
    //         "VERSION": "536",
    //         "DEVICETYPE": "ANDROID"
    //       }),
    //       "LOGIN");
    //
    //   if (responseData != null) {
    //     if (responseData.body.contains("Invalid Username or Password") ==
    //         false) {
    //
    //       var jsonResponse =
    //           json.decode(responseData.body) as Map<String, dynamic>;
    //
    //       if (jsonResponse['records'].first['STATUS'] == "Yes") {
    //         var userData = jsonResponse['records'].first;
    //         DataInfo.username.value = userNameController.text.trim();
    //         DataInfo.password.value = passwordController.text.trim();
    //         DataInfo.userId.value = userData['UID'];
    //         DataInfo.enrollId.value = userData['ENROLLID'];
    //         DataInfo.rollId.value = userData['ROLLID'];
    //         DataInfo.imageUrl.value = userData['IMGURL'];
    //         DataInfo.pid.value = userData['PID'];
    //         DataInfo.desCat.value = userData['DESCAT'];
    //         DataInfo.encKey.value = userData['ENCKEY'];
    //         DataInfo.tcId.value =userData['TCID'];
    //
    //         registerData(userData);
    //       }
    //     } else {
    //       isLoading.value = false;
    //       CustomWidgets.snackBar(title: responseData.body.toString());
    //     }
    //   } else {
    //     isLoading.value = false;
    //     //CustomWidgets.snackBar(title: responseData.body.toString());
    //   }
    // } catch (e) {
    //   log("login error:$e");
    // }
  }

  void registerData(var userData) async {
    NotificationController notificationController = NotificationController();
    String? deviceToken = await notificationController.getToken();
    var de = {
      "Uid":DataInfo.userId.value,
      "tokenID":DataInfo.deviceId.value,
      "device":DataInfo.platform.value,
      "UUID":deviceToken.toString()
    };
    print("send data:${de}");
    Api().fetchApi(data: json.encode({
      "Uid":DataInfo.userId.value,
      "tokenID":DataInfo.deviceId.value,
      "device":DataInfo.platform.value,
      "UUID": kReleaseMode ? deviceToken : ""  //deviceToken.toString()
    }), action: "REGISTERID",isSubmit: true).then((value)async{
      if(value!.success)
        {
          await getUserData();
          isLoading.value = false;
          Loader().hide();
          if (isRemember.value) {
            DataInfo.box.write("userId", DataInfo.userId.value);
              userData['username'] = DataInfo.username.value;
            userData['password'] = DataInfo.password.value;
            DataInfo.box.write("userData", json.encode(userData));
          }

          Get.to(() => const DashboardNew());


        }
      else
        {
          isLoading.value = false;
          Loader().hide();
          //CustomWidgets.snackBar(title: "Server Error");
        }
    });
    // try {
    //   var responseData = await Apis.sendData(
    //       json.encode({
    //         "Uid": DataInfo.userId.value,
    //         "tokenID": DataInfo.deviceId.value,
    //         "device": DataInfo.platform.value
    //       }),
    //       "REGISTERID&ENCKEY=${DataInfo.encKey.value}&SRC=KARMA");
    //
    //   if (responseData.body == "YES") {
    //
    //    await getUserData();
    //    isLoading.value = false;
    //     if (isRemember.value) {
    //       DataInfo.box.write("userId", DataInfo.userId.value);
    //       userData['username'] = DataInfo.username.value;
    //       userData['password'] = DataInfo.password.value;
    //       DataInfo.box.write("userData", json.encode(userData));
    //     }
    //
    //     Get.to(() => const Dashboard());
    //
    //   } else {
    //     isLoading.value = false;
    //     CustomWidgets.snackBar(title: "Server Error");
    //   }
    // } catch (e) {
    //   log("register error: $e");
    // }
  }

   getUserData() async {
    var responseData = await Apis.sendData(
        DataInfo.username.value, "GETUSERDITAILS&ENCKEY=${DataInfo.encKey.value}&SRC=KARMA");
    var de = json.decode(responseData.body);
    var data = de[0];
    DataInfo.box.write("userInfo", data);
    DataInfo.fullName.value = data['FULLNAME'];
    DataInfo.name.value = data['NAME'];
    DataInfo.designation.value = data['DESIGNATION'];
    DataInfo.mobile.value = data['MOBILE'];
    DataInfo.email.value = data['USEREMAIL'];
    DataInfo.aboutMe.value =  data['ABOUTME'];


  }
}


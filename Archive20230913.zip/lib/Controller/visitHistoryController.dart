import 'package:karma/Constants/Library.dart';
class VisitHistoryController extends GetxController{
  RxMap data  = {}.obs;
  RxString selectType = "1".obs;
  RxList<dynamic> list = [].obs;
  RxList<dynamic> proposalList = [].obs;
  RxString proformaData = "".obs;
  RxBool isLoading  = false.obs;
  @override
  void onInit() {
    data.value = Get.arguments;
    getActivityData();
    super.onInit();
  }
  getActivityData()async{
    isLoading.value = true;

    Api().fetchApi(data:"${DataInfo.username.value}|${data['DPID']}",
        action: "CALLENTRYDETAILS").then((value) {
          try{
            if(value!.success){
              var jsonResponse =
                  value.data;
              list.value = jsonResponse['ROOT'][0]['DETAILS'];

              isLoading.value = false;
            }
          }catch(e){
            isLoading.value= false;
          }
    });


  }
}
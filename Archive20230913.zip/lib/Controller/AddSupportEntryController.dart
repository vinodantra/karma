import 'dart:developer';
import 'package:karma/Constants/Library.dart';
import 'package:intl/intl.dart';
class AddSupportEntryController extends GetxController{
  RxMap data  = {}.obs;
  TextEditingController tallySerialController = TextEditingController();
  TextEditingController tallyNumberController = TextEditingController();
  TextEditingController tallyNoController = TextEditingController();
  TextEditingController name = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController remark = TextEditingController();
  RxString selectTallyDate = DateFormat('dd/MM/yyyy').format(DateTime.now()).obs;
  RxString tallyDate = DateFormat('ddMMMyyyy').format(DateTime.now()).obs;
  RxString selectDate = "".obs;
  RxString selectTicketType = "Select".obs;
  RxString selectTicketTypeId = "".obs;
  RxString selectTypeOfCall = "Select".obs;
  RxString selectTypeOfCallId = "".obs;
  RxBool isLoading = false.obs;
  RxList<dynamic> categoryList = [].obs;
  RxString selectCategory = "Select".obs;
  RxString selectCategoryId = "".obs;
  RxInt experienceTicket = 1.obs;
   RxList<dynamic> typeOfCallList = [
    {
      "ID":"95",
      "NAME":"Onsite Demo",

    },
    {
      "ID":"87",
      "NAME":"Onsite Visit",
    },
    {
      "ID":"82",
      "NAME":"Product Support Calls",

    },
    {
      "ID":"91",
      "NAME":"Requirement Discussions",
    },
    {
      "ID":"88",
      "NAME":"Training",
    },


  ].obs;
  RxList<dynamic> typeOfCallList1 = [].obs;

  RxList<dynamic> ticketTypeList = [
    {
      "ID":"1",
      "NAME":"TLY",

    },
    {
      "ID":"2",
      "NAME":"AWT",
    }

  ].obs;
RxList<dynamic> levelList = [{"ID":"1","NAME":"Critical"},
  {"ID":"2","NAME":"Major"},
  {"ID":"3","NAME":"Minor"},
  {"ID":"4","NAME":"Requirement"},].obs;
RxString selectLevel = "Select".obs;
RxString selectLevelId=  "".obs;
  RxList<dynamic> statusList = [{"ID":"1","NAME":"Pending"},
    {"ID":"2","NAME":"Resolved"},
    ].obs;
  RxString selectStatus = "Select".obs;
  RxString selectStatusId=  "".obs;
  @override
  void onInit() {
    data.value = Get.arguments;
    log("args:$data");
    name.text = data['ACCOWNER'];
    email.text = data['CMPEMAIL'];
    tallySerialController.text = data['TALLYSRLNO'];
    if(data['TEAMID'] == "1"){
      getCategoryData();
    }
    super.onInit();
  }

  updateStatus()async{
    var responseData;
    // if(tallyNumberController.text.trim().isEmpty)
    //   {
    //     CustomWidgets.snackBar(title: "Please enter Ticket number");
    //   }
     if(selectTypeOfCallId.isEmpty)
      {
        CustomWidgets.snackBar(title: "Please select type of call");
      }
     else if(selectLevelId.isEmpty && data['TEAMID'] == "1"){
       CustomWidgets.snackBar(title: "Please select level of call");
     }
     else if(selectCategoryId.isEmpty && data['TEAMID'] == "1"){
       CustomWidgets.snackBar(title: "Please select category");
     }
     else if(selectStatusId.isEmpty && data['TEAMID'] == "1"){
       CustomWidgets.snackBar(title: "Please select status");
     }
    else if(name.text.isEmpty)
    {
      CustomWidgets.snackBar(title: "Please enter attend person");
    }else if(email.text.isEmpty)
    {
      CustomWidgets.snackBar(title: "Please enter attend person email");
    }

    else if(remark.text.isEmpty)
    {
      CustomWidgets.snackBar(title: "Please enter remark");
    }
    else
      {

        //308770|96|16:02|21:09||Critical|34|Resolved|test|Hassan|hassan%40antraweb.com|pranali t|ASC|1|731065725|||||YES
        Api().fetchApi(data:"${data['ID']}|${selectTypeOfCallId.value}|${data['CHKIN']}|${data['CHKOUT'] != "00"  ? data['CHKOUT'] :"${TimeOfDay.now().hour.toString()}:${TimeOfDay.now().minute.toString()}"}|${tallyNumberController.text}|${data['TEAMID'] == "1" ? selectLevel.value : ""}|${data['TEAMID'] == "1" ? selectCategoryId.value : "18"}|${data['TEAMID'] == "1" ? selectStatus.value : ""}|${remark.text}|${name.text}|${email.text}|${DataInfo.username.value}|${data['CALLTYPID']}|${data['TEAMID']}|${tallySerialController.text}|||||${data['TEAMID'] == "1" ? experienceTicket.value == 2 ? "YES":"NO" : "NO"}",
            action:"UPDATECALL").then((value) {
          if(value!.success){

            if(value.data == "YES")
            {
              Get.dialog(Center(
                child: Card(
                  color: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.check,color: Colors.lightGreen,size: 50,),
                      20.heightBox,
                      TextWidget("Well Done!",fontSize: 18,color: Colors.black,),
                      15.heightBox,
                      TextWidget("Successfully Updated.",fontSize: 16,color: Colors.grey[500],),
                      20.heightBox,
                      CustomButton(text: "Ok",onPressed: (){
                        Get.back(result: true);

                        //Get.to(()=>  const SupportList(),arguments: data);
                      },),
                      10.heightBox,
                    ],
                  ).p24(),
                ),

              ),
                barrierDismissible: false,
              ).then((value) {
                Get.back(result: true);
                // Get.offAll(()=>  const SupportList(),arguments: data);
              });
            }

            isLoading.value = false;
          }else{
            isLoading.value = false;
          }
        });
      }

  }

  void getCategoryData() async{
      try{
        Api().fetchApi(data:DataInfo.username.value,
            action:"CATEGORYTYPE").then((value) {
          if(value!.success){
            typeOfCallList1.value = value.data['ROOT'][0]['CATEGORY'];
            categoryList.value = value.data['ROOT'][0]['SUPCATEGORY'];






            isLoading.value = false;
          }else{
            isLoading.value = false;
          }
        });
      }catch(e){
        if (kDebugMode) {
          print(e);
        }
      }
  }
}
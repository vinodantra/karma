import 'package:karma/Constants/Library.dart';
class TicketDetailsController1 extends GetxController{
  RxString ticketNumber = "".obs;
  RxBool isLoading = false.obs;
  RxList<dynamic> interactionList = [].obs;
  @override
  void onInit() {
    ticketNumber. value = Get.arguments;
    getData();
    super.onInit();
  }

  void getData() async{
    isLoading.value = true;



    try{

      var response =  await Apis.sendData5("TICKETDETAILS|${ticketNumber}|");
      if(response != null){
        var responseData = json.decode(response.body);


        interactionList.value = responseData['ROOT']['ticket_details']['interaction'];


        isLoading.value = false;

      }
      else{
        isLoading.value = false;
      }
    }catch(e){
      print("error:${e.toString()}");
      isLoading.value = false;
    }

  }
}
import 'dart:developer';
import 'package:karma/Constants/Library.dart';

class DataPointInfoController extends GetxController {
  RxMap data = {}.obs;
  RxBool isLoading = false.obs;
  RxMap info = {}.obs;
  RxList<dynamic> brochureList = [].obs;
  RxList<dynamic> emailList = [].obs;
  RxString selectBrochure = "Select".obs;
  RxString selectBrochureId = "".obs;
  RxString selectEmail = "Select".obs;
  RxString selectId = "".obs;
  RxString selectCntName = "".obs;

  @override
  void onInit() {
    data.value = Get.arguments;

    getData();
    getBrochureData();
    getEmailData();
    super.onInit();
  }

  void getData() async {
    isLoading.value = true;
    Api()
        .fetchApi(data: json.encode({"DPID": data['DPID']}), action: "GETDPINF")
        .then((value) {
      try {
        if (value!.success) {
          var jsonResponse = value.data;

          var data1 = jsonResponse['records'][0];
          info.value = data1;

          isLoading.value = false;
          update();
        } else {
          isLoading.value = false;
        }
      } catch (e) {
        isLoading.value = false;
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });
  }

  void getBrochureData() async {
    isLoading.value = true;
    Api().fetchApi(action: "BROCHUREMASTER").then((value) {
      try {
        if (value!.success) {
          var jsonResponse = value.data;

          brochureList.value = jsonResponse;

          isLoading.value = false;
          update();
        } else {
          isLoading.value = false;
        }
      } catch (e) {
        isLoading.value = false;
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });
  }

  void getEmailData() async {
    isLoading.value = true;

    Api().fetchApi(data: data['DPID'], action: "GETUSER").then((value) {
      try {
        if (value!.success) {
          var jsonResponse = value.data;

          emailList.value = jsonResponse['records'];

          isLoading.value = false;
          update();
        } else {
          isLoading.value = false;
        }
      } catch (e) {
        isLoading.value = false;
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });
  }

  void sendData() async {
    isLoading.value = true;

    Api()
        .fetchApi(
            data: json.encode({
              "CNTNAME": selectCntName.value.trim(),
              "CNTEMAIL": selectEmail.value.trim(),
              "OWNEREMAIL": info['CONTEMAIL1'].trim(),
              "BROCHURE": selectBrochure.value,
              "BROCHUREID": selectBrochureId.value,
              "DPID": data['DPID']
            }),
            action: "BROCHEREMAIL")
        .then((value) {
      try {
        if (value!.success) {
          isLoading.value = false;
          update();
        } else {
          isLoading.value = false;
        }
      } catch (e) {
        isLoading.value = false;
        CustomWidgets.snackBar(title: value!.data.toString());
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });
  }
}

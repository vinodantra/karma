// ignore_for_file: file_names, must_be_immutable, avoid_init_to_null

import 'package:karma/Constants/Library.dart';

class TextWidget extends StatelessWidget {
  String? text;
  Color? color;
  double? fontSize;
  FontWeight? fontWeight;
  TextAlign? textAlign;
  int maxLines;
  TextDecoration textDecoration;
  TextWidget(this.text,
      {Key? key,
      this.color,
      this.fontSize = 12,
      this.fontWeight = FontWeight.normal,
      this.textAlign = null,
      this.maxLines = 1,
      this.textDecoration = TextDecoration.none})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      text!.trim().toString(),
      textAlign: textAlign,
      maxLines: maxLines,
      style: GoogleFonts.inter(
          color: color, fontSize: fontSize, fontWeight: fontWeight,
      decoration: textDecoration),
    );
  }
}

import '../Constants/Library.dart';
class Loader {
  Loader() : super(){
    loader();
  }

  void loader(){
    showDialog(
        context: Get.context!,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children:  [
                Card(
                  elevation: 10.0,
                  child:  CircularProgressIndicator(
                    color: appColor.value,
                  ).p20(),
                ),
              ],
            ),
          );
        });
    // Get.dialog(
    //     Center(
    //   child: Column(
    //     mainAxisSize: MainAxisSize.min,
    //     children:  [
    //       Card(
    //         elevation: 10.0,
    //         child: const CircularProgressIndicator(
    //           color: appColor,
    //         ).p20(),
    //       ),
    //     ],
    //   ),
    // ));
  }

  hide(){
    Navigator.pop(Get.context!);
    Navigator.pop(Get.context!);


  }
}
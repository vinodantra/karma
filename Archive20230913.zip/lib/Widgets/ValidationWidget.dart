import 'package:karma/Constants/Library.dart';
class ValidationWidget extends StatelessWidget {
  const ValidationWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            TextWidget("No data found.",fontSize: 30,)
          ],
        ),
      ),
    );
  }
}

import 'package:karma/Constants/Library.dart';
class SearchWidget extends StatelessWidget {
  TextEditingController? controller;
  String? hintText;
  Function(String? value)?onChanged;
  Function()? onClose;
   SearchWidget({Key? key,this.controller,this.hintText,this.onChanged,this.onClose}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      // decoration: BoxDecoration(
      //   borderRadius: BorderRadius.circular(10.0),
      //   color: Colors.grey[200],
      //
      // ),
        decoration: ShapeDecoration(
          color: Color(0x1E767680),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),

        child: TextField(
        key: key,
        onChanged: onChanged,
        controller: controller,
        decoration: InputDecoration(
          hintText: hintText ?? "",
          border: InputBorder.none,
          prefixIcon: const Icon(Icons.search),
          suffixIcon: controller!.text.trim().isNotEmpty ?
          IconButton(onPressed: onClose,
          icon: const Icon(Icons.close),
          ) : null,
          constraints: BoxConstraints(
            minHeight: 45,
            maxHeight: 45
          )
        ),


      )
    ).p8();
  }
}

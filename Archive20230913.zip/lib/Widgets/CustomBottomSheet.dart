import 'package:karma/Constants/Library.dart';

class CustomBottomSheet extends StatefulWidget {
  List<dynamic> list;
  String parameter;
  bool showSearchWidget;
  ValueChanged<Map<String,dynamic>>? data;
  String? title;

  CustomBottomSheet(
      {Key? key,
      required this.list,
      required this.parameter,
      this.showSearchWidget = true,this.data,this.title})
      : super(key: key);

  @override
  _CustomBottomSheetState createState() => _CustomBottomSheetState(
      list: list, parameter: parameter, showSearchWidget: showSearchWidget);
}

class _CustomBottomSheetState extends State<CustomBottomSheet> {
  List<dynamic> list;
  bool showSearchWidget;
  String parameter;
  _CustomBottomSheetState(
      {required this.list,
      required this.parameter,
      this.showSearchWidget = true});
  List<dynamic> fList = [];
  String search = "";
  TextEditingController searchController = TextEditingController();
  String selectData = "";
  @override
  void initState() {
    fList = list;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 375,
      height: list.length > 3 ? 450 : 240,

      decoration: const BoxDecoration(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(36.0), topRight: Radius.circular(36.0)),
        boxShadow: [
          BoxShadow(
            color: Color(0x3f929292),
            blurRadius: 27,
            offset: Offset(0, -4),
          ),
        ],
        color: Colors.white,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [

        showSearchWidget ?
        Container(
              width: Get.width * 0.9,
             // height: 40,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: const Color(0xfff4f5f7),
              ),
              // padding: const EdgeInsets.symmetric(
              //   horizontal: 16,
              //   vertical: 8,
              // ),
              child: TextField(
                onChanged: (value) {
                  setState(() {
                    search = value;
                    filterData();
                  });
                },
                controller: searchController,

                decoration: InputDecoration(
                    hintText: "Search",
                    hintStyle: const TextStyle(
                      color: Color(0xff555b69),
                      fontSize: 12,
                    ),
                    border: InputBorder.none,
                    constraints: BoxConstraints(
                      minHeight: 40,
                      maxHeight: 50
                    ),

                    prefixIcon: const Icon(Icons.search),
                    suffixIcon: search.trim().isNotEmpty
                        ? IconButton(
                            onPressed: () {
                              updateData();
                            },
                            icon: const Icon(Icons.close))
                        : const SizedBox()),
              )).pOnly(top: 20.0,bottom: 10.0 ) : const SizedBox(height: 30,),
          fList.isNotEmpty
              ? Expanded(
                child: Scrollbar(
                  thickness: 5.0,
                  trackVisibility: true,

                  thumbVisibility: true,
                  child: ListView.builder(

                      itemCount: fList.length,
                      itemBuilder: (context, index) {
                        return InkWell(
                          onTap: () {
                            setState(() {
                              selectData = fList[index][parameter];
                              widget.data!(fList[index]);
                            });
                            // controller.selectNoc
                            //     .value =
                            // bookingController
                            //     .fNatureOfCall[
                            // index]['NAME'];
                            //
                            // Get.back();
                          },
                          child: Container(
                            width: Get.width,
                            height: 60,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0x3fb0b0b0),
                                  blurRadius: 4,
                                  offset: Offset(0, 2),
                                ),
                              ],
                              color: Colors.white,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                SizedBox(
                                  width: Get.width * 0.7,
                                  child: TextWidget(
                                    "${fList[index][parameter]}",
                                    color: const Color(0xff2f3237),
                                    fontSize: 16,
                                  ),
                                ),
                                selectData == fList[index][parameter]
                                    ? const Icon(
                                        Icons.check,
                                        color: Color(0xffBDC0CE),
                                      )
                                    : const SizedBox(),
                              ],
                            ).pSymmetric(h: 25.0),
                          ),
                        );
                      }),
                ),
              )
              : Center(
                  child: TextWidget(
                    "No data found.",
                    fontSize: 25,
                  ),
                )
        ],
      ),
    );
  }

  updateData() {
    setState(() {
      searchController.text = "";
      search = "";
      fList = list;
    });
  }

  filterData(){
    setState(() {
      fList = list
          .where((element) =>
          element[parameter]
              .toString()
              .trim()
              .toLowerCase()
              .contains(search.trim().toLowerCase()))
          .toList();
    });
  }
}

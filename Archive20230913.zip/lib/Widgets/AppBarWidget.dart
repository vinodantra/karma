// ignore_for_file: file_names, must_be_immutable

import 'package:flutter/services.dart';
import 'package:karma/Constants/Library.dart';
import 'package:karma/Controller/appThemeController.dart';
import 'package:provider/provider.dart';


class AppBarWidget extends StatelessWidget implements PreferredSizeWidget{
  final String title;

    Function()? onBackPress;
    Function()? onPressAdd;
    Function()?onSubmit;
    Function()?onLocation;
    List<Color> ? colors;

    Function()? onStatus;
    Function()? onClick;


    AppBarWidget({Key? key,required this.title,this.colors,this.onBackPress,this.onPressAdd,this.onSubmit,this.onLocation,this.onStatus,this.onClick}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return PreferredSize(
        preferredSize: const Size.fromHeight(60.0),
        child: AppBar(
          systemOverlayStyle: const SystemUiOverlayStyle(statusBarColor: Colors.transparent),
          flexibleSpace: Container(
            decoration:  BoxDecoration(

                gradient: LinearGradient(
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                    colors:Provider.of<AppThemeController>(context).appGradientColor
                )
            ),

          ),
          elevation: 0,
          leadingWidth: 30.0,
          leading: onBackPress != null ? IconButton(onPressed: onBackPress,icon: const Icon(Icons.arrow_back,color: Colors.white,),) : null,
          title: TextWidget(title, color: const Color(0xfff4f5f7),
            fontSize: 16,),
          actions: [
            onPressAdd != null ?
            CustomWidgets.showSvgImage(path: addIcon,onPressed: onPressAdd) : const SizedBox(),
            onSubmit != null ?
            IconButton(onPressed: onSubmit,
                icon:const Icon(Icons.check,color: Colors.white,)) : const SizedBox(),
            onLocation != null ?
            IconButton(onPressed: onLocation,
                icon:const Icon(Icons.location_on_outlined,color: Colors.white,)) : const SizedBox(),
            onStatus != null ?
            IconButton(onPressed: onStatus,
                icon:const Icon(Icons.keyboard_arrow_down_outlined,color: Colors.white,)) : const SizedBox(),
            onClick != null ?
            IconButton(onPressed: onClick,
                icon:const Icon(Icons.more_vert,color: Colors.white,)) : const SizedBox(),
          ],
        )

    );
  }
  @override

  Size get preferredSize => const Size(
      double.maxFinite,
      60
  );
}


// ignore_for_file: file_names


import 'package:karma/Application/Dashboard/DashboardNew.dart';
import 'package:karma/Constants/Library.dart';

class AppRoutes{
  static String loginPage  = "/login";
  static String dashboard  = "/dashboard";
  static String product = "/products";

  static List<GetPage<dynamic>> routes = <GetPage<dynamic>>[
   GetPage<SplashScreen>(name: "/", page: ()=> const SplashScreen(),transition: Transition.rightToLeft),
    GetPage<LoginPage>(name: "/login", page: ()=> const LoginPage(),transition: Transition.rightToLeft),
    GetPage<LoginPage>(name: "/dashboard", page: ()=> const DashboardNew(),transition: Transition.rightToLeft),
    GetPage<LoginPage>(name: "/products", page: ()=> const Products(),transition: Transition.rightToLeft),


  ];
}



import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:karma/Application/Utilities/Utilities.dart';
import 'package:karma/Services/webApis.dart';
import 'package:karma/Widgets/CustomWidgets.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';
import '../Constants/dataInfo.dart';


class Api{
  final Dio _dio = Dio();

  final String baseUrl;
   Map<String,dynamic> defaultHeader = {
    'Content-Type':'application/json'
  };
  Api({this.baseUrl = ""}){
    _dio.options.headers = defaultHeader;
    _dio.options.receiveTimeout = const Duration(minutes: 5);
    _dio.interceptors.add(PrettyDioLogger(
      request: false,
      requestBody: false,
      requestHeader: false,
      responseBody: true,
      responseHeader: false,
    ));



  }

 Dio get sendRequest => _dio;


  Future<ApiResponse?> _fetchApi({String? data = "",required String action,bool isSubmit = false})async{
    // if (kDebugMode) {
    //   print("send request:${DateTime.now()}");
    // }
    
    Response response = await Api().sendRequest.get("${WebApis.baseUrl}DATA=$data&ACTION=$action&ENCKEY=${DataInfo.encKey.value}&SRC=KARMA",
    onReceiveProgress: (a,b){
      //log("a:$a-b:$b");
    });
    // if (kDebugMode) {
    //   print("get request:${DateTime.now()}");
    // }
    return ApiResponse.fromResponse(response,isSubmit: isSubmit);

  }

  Future<ApiResponse?> fetchApi({String? data = "",required String action,bool isSubmit = false}) async{
    ApiResponse ? apiResponse;
    apiResponse = await _fetchApi(data: data,action:action,isSubmit: isSubmit );
    if(apiResponse!.success == true)
      {
        return apiResponse;
      }
      else
        {

          CustomWidgets.snackBar(title: apiResponse.message!.isNotEmpty ? apiResponse.message! : apiResponse.data);
          return apiResponse;
        }

  }

}

class ApiResponse {
  bool success;
  dynamic data;
  String? message;
  ApiResponse({required this.success,this.data,this.message});

  factory ApiResponse.fromResponse(Response response,{bool isSubmit = false})
  {
      final data = response.data;

      return isSubmit ?

      ApiResponse(
          success: data.toString().toLowerCase() == "yes"
              ? true
              : false,
          data: data,
          message: ""
      ) : ApiResponse(
          success: Check.data(data) ?  response.statusCode != 200 || Utilities.decodeResponse(data) is String ? data.toString().toLowerCase() == "yes" ? true : false : true : false,
          data:  Check.data(data) ? Utilities.decodeResponse(data) : "",
          message: Check.data(data) ? Utilities.decodeResponse(data) is String ? data.trim() : "" : data.toString().contains("Cannot login in this device") ? data.toString() : "Server Error"
      );
  }

}


// ignore_for_file: file_names

import 'dart:developer';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:karma/Constants/dataInfo.dart';
import 'package:karma/Services/webApis.dart';



class Apis {
  static dynamic sendData(String data, String action) async {
    http.Response response;

    try {
      log("url:${"${WebApis.baseUrl}DATA=$data&ACTION=$action"}");
      print("send request:${DateTime.now()}");
      var url = Uri.parse("${WebApis.baseUrl}DATA=$data&ACTION=$action");

      response = await http.get(url).timeout(
        const Duration(seconds: 50),
        onTimeout: () {
          return http.Response('Error', 408);
        },
      );

      if (response.statusCode == 200) {
        log("response:${response.body.toString()}");
        print("get request:${DateTime.now()}");
        return response;
      } else {
        if (kDebugMode) {
          print('Request failed with status: ${response.statusCode}.');
        }
        return null;
      }
    } catch (e) {
      if (kDebugMode) {
        print("error:${e.toString()}");
      }
      return null;
    }
  }

  static dynamic sendData1(String data, String action) async {
    http.Response response;

    try {
      log("url:${"${WebApis.customerBaseUrl}DATA=$data&ACTION=$action"}");
      print("send request:${DateTime.now()}");
      var url = Uri.parse("${WebApis.customerBaseUrl}DATA=$data&ACTION=$action");

      response = await http.get(url).timeout(
        const Duration(seconds: 50),
        onTimeout: () {
          return http.Response('Error', 408);
        },
      );

      if (response.statusCode == 200) {
        log("response:${response.body.toString()}");
        print("get request:${DateTime.now()}");
        return response;
      } else {
        if (kDebugMode) {
          print('Request failed with status: ${response.statusCode}.');
        }
        return null;
      }
    } catch (e) {
      if (kDebugMode) {
        print("error:${e.toString()}");
      }
      return null;
    }
  }

  static dynamic sendData2(String action) async {
    http.Response response;

    try {
      log("url:${"${WebApis.customerBaseUrl}ACTION=$action"}");
      print("send request:${DateTime.now()}");
      var url = Uri.parse("${WebApis.customerBaseUrl}ACTION=$action");

      response = await http.get(url).timeout(
        const Duration(seconds: 50),
        onTimeout: () {
          return http.Response('Error', 408);
        },
      );

      if (response.statusCode == 200) {
        log("response:${response.body.toString()}");
        print("get request:${DateTime.now()}");
        return response;
      } else {
        if (kDebugMode) {
          print('Request failed with status: ${response.statusCode}.');
        }
        return null;
      }
    } catch (e) {
      if (kDebugMode) {
        print("error:${e.toString()}");
      }
      return null;
    }
  }

  static dynamic sendData4(String data, String action) async {
    http.Response response;

    try {
      log("url:${"${WebApis.baseUrl}DATA=$data&ACTION=$action&ENCKEY=${DataInfo.encKey.value}&SRC=KARMA"}");
      print("send request:${DateTime.now()}");
      var url = Uri.parse("${WebApis.baseUrl}DATA=$data&ACTION=$action&ENCKEY=${DataInfo.encKey.value}&SRC=KARMA");

      response = await http.get(url).timeout(
        const Duration(seconds: 50),
        onTimeout: () {
          return http.Response('Error', 408);
        },
      );

      log("response:${response.body.toString()}");
      print("get request:${DateTime.now()}");
      if (response.statusCode == 200) {

        return response;
      } else {
        if (kDebugMode) {
          print('Request failed with status: ${response.statusCode}.');
        }
        return null;
      }
    } catch (e) {
      if (kDebugMode) {
        print("error:${e.toString()}");
      }
      return null;
    }
  }

  static dynamic sendData5(String data) async {
    http.Response response;

    try {
      log("url:${"${WebApis.customerBaseUrl}data=$data"}&ENCKEY=${DataInfo.encKey.value}&SRC=KARMA");

      var url = Uri.parse("${WebApis.customerBaseUrl}data=$data&ENCKEY=${DataInfo.encKey.value}&SRC=KARMA");

      response = await http.get(url).timeout(
        const Duration(seconds: 50),
        onTimeout: () {
          return http.Response('Error', 408);
        },
      );

      if (response.statusCode == 200) {
        log("response:${response.body.toString()}");

        return response;
      } else {
        if (kDebugMode) {
          print('Request failed with status: ${response.statusCode}.');
        }
        return null;
      }
    } catch (e) {
      if (kDebugMode) {
        print("error:${e.toString()}");
      }
      return null;
    }
  }
}

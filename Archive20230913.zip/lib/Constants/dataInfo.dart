// ignore_for_file: file_names

import 'Library.dart';

class DataInfo extends GetxController {
  static RxString userId = "".obs;
  static RxString errorInfo = "".obs;
  static RxBool isPhysicalDevice = true.obs;
  static RxString enrollId = "".obs;
  static RxString rollId = "".obs;
  static RxString imageUrl = "".obs;
  static RxString pid = "".obs;
  static RxString tcId = "".obs;
  static RxString encKey = "".obs;
  static RxString name = "".obs;
  static RxString username = "".obs;
  static RxString fullName = "".obs;
  static RxString mobile = "".obs;
  static RxString email = "".obs;
  static RxString desCat = "".obs;
  static RxString aboutMe = "".obs;
  static RxString selectUserId = "".obs;
  static RxString selectUserName = "".obs;
  static RxString designation = "".obs;
  static RxString deviceName = "".obs;
  static RxString device  =  "".obs;
  static RxString deviceId = "".obs;
  static RxString deviceToken = "".obs;
  static RxString platform = "".obs;
  static RxString password = "".obs;
  static RxString encryptionKey = "4086808640868086".obs;
  static RxString appVersion = "".obs;
  static RxString dpId = "".obs;
  static final box = GetStorage();
  static String apiKey = "AIzaSyD4Jn26OMzsW0o1rgy0jA629Z9txkCs4TQ";
  static RxBool showData = true.obs;
  static RxBool isSelectUser = true.obs;
  static RxString profileId = "".obs;
  static RxInt selectTheme = 1.obs;
}

// ignore_for_file: file_names

import 'package:flutter/material.dart';
import 'package:get/get.dart';

const primaryColor = Colors.blue;
Rx<dynamic> appColor = Color(0xffe0659b).obs;
RxList<Color> appGradientColor = [Color(0xffe0659b), Color(0xff8b4de6)].obs;
const backgroundColor = Colors.white;
const  textColor = Colors.white;
const titleColor = Color(0xff344053);
const descriptionColor = Color(0xff667084);

var appColorList = [Color(0xffe0659b),Color(0xff38CC9F),Color(0xff060606),
  Color(0xffFF616D),Color(0xff598AE5)];

const appTheme = [
  [Color(0xffe0659b), Color(0xff8b4de6)],
  [Color(0xff38CC9F), Color(0xff0A815D)],
  [Color(0xff060606), Color(0xff424242)],
  [Color(0xffFFBD71), Color(0xffFF616D)],
  [Color(0xff598AE5), Color(0xff36CFDC)],];

const themeName = ["Default","Mild","Deap Sea","Sweet Morning","Scooter"];

class AppTheme extends GetxController{
  Rx<dynamic> appColor = Color(0xffe0659b).obs;
  RxList<Color> appGradientColor = [Color(0xffe0659b), Color(0xff8b4de6)].obs;

  Rx<Gradient> appBarGradientColor = LinearGradient(
    colors: [Color(0xffe0659b), Color(0xff8b4de6)]
  ).obs;

  changeTheme(List<Color> colors){
    appBarGradientColor.value = LinearGradient(
        colors: colors
    );
  }
}
// ignore_for_file: file_names, unused_import

import 'dart:developer';
import 'package:firebase_database/firebase_database.dart';
import 'package:karma/Application/Dashboard/DashboardNew.dart';
import 'package:karma/Constants/Library.dart';
import 'package:karma/Controller/appThemeController.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:intl/intl.dart';
class DashboardController extends GetxController {
  RxBool isLoading = false.obs;
  RxList<dynamic> targetList = [].obs;
  RxInt selectTab = 0.obs;
  List<ChartData> chartData = [];
  PageController pageController = PageController(initialPage: 0,viewportFraction: 1.0);
  RxMap<String, dynamic> dataPoint = <String, dynamic>{}.obs;
  RxMap<String, dynamic> epicData = <String, dynamic>{}.obs;
  RxMap<String, dynamic> zoneData = <String, dynamic>{}.obs;
  RxMap<String, dynamic> outstandingData = <String, dynamic>{}.obs;
  RxMap<String, dynamic> callBookingData = <String, dynamic>{}.obs;
  RxMap<String, dynamic> businessData = <String, dynamic>{}.obs;
  RxMap<String, dynamic> leadData = <String, dynamic>{}.obs;
  RxList<dynamic> opportunityList = [].obs;
  RxBool selectCategory1 = true.obs;
  RxString selectL2Category1 = "1".obs;
  RxList<dynamic> userList = [].obs;
  RxList<dynamic> filterUserList = [].obs;
  TextEditingController searchController = TextEditingController();
  TextEditingController searchController1 = TextEditingController();
  RxList<dynamic> listData = [].obs;
  RxString search = "".obs;
  RxString selectPrdId = "".obs;
  RxMap selectData = {}.obs;
  RxMap monthlyL2Data = {}.obs;
  RxMap quarterlyL2Data = {}.obs;
  RxMap allL2Data = {}.obs;
  RxString avgRating = "".obs;
  RxString overAllRating = "0".obs;
  RxMap mapDataL2 = {}.obs;
  RxString status = "0.0L/(0.0L)".obs;
  RxString selectUser = "User".obs;
  RxString callBooking = "".obs;
  RefreshController refreshController =
  RefreshController(initialRefresh: false);
  var themeController = null;
  RxBool showData =  false.obs;
  RxInt selectTabL2 = 0.obs;
  RxString selectTallyDate = DateFormat('dd/MM/yyyy').format(DateTime.now()).obs;
  RxString selectTicketType = "Select".obs;
  RxString selectTicketTypeId = "".obs;
  RxString tallyDate = DateFormat('ddMMMyyyy').format(DateTime.now()).obs;
  RxString selectDate = "".obs;
  TextEditingController tallyNoController = TextEditingController();
  TextEditingController content = TextEditingController();
  RxString ticketNumber = "".obs;

  RxString remindMeDate = DateFormat('dd/MM/yyyy').format(DateTime.now()).obs;
  RxString selectRemindMeDate = "".obs;
  RxString selectTime = "".obs;
  TextEditingController content1 = TextEditingController();
  RxList<dynamic> remindMeList = [].obs;
  RxList<dynamic> ticketTypeList = [
    {
      "ID":"1",
      "NAME":"TLY",

    },
    {
      "ID":"2",
      "NAME":"AWT",
    }

  ].obs;
  @override
  void onInit() {


    mapDataL2.value = {"pprc":"0",
    "ticket":"0",
    "onsitevisits":"0",
    "lead":"0"};
    themeController = Provider.of<AppThemeController>(Get.context!);
    getData();
    if(DataInfo.box.hasData("remindMe")){
      remindMeList.value = DataInfo.box.read("remindMe");
    }
    super.onInit();
  }

  void getData() async {
    isLoading.value = true;
    targetList.clear();
    status.value = "0.0L/(0.0)L";
    if(DataInfo.desCat.value == "L1") {

       await Api().fetchApi(
            data:json.encode(
              {
                "UID": DataInfo.userId.value,
                "PID": DataInfo.pid.value,
                "UNAME": DataInfo.username.value
              },
            ),
            action: "ACHIVEDTARGET").then((value) async{


          if (value!.success) {

            if (value.data.toString().contains("Please Update Your App") == false) {
              var data = value.data;
              var targetData = data['ROOT'][0]['DETAILS'][0];

              var data1 = {
                "type": "Today",
                "meTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['DAILYUSER']['USERACHIVD']) /
                        int.parse(targetData['DAILYUSER']['USERTGT'])) *
                        100),
                "teamTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['DAILYTEAM']['TEAMACHIVD']) /
                        int.parse(targetData['DAILYTEAM']['TEAMTGT'])) *
                        100),
                "floorTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['DAILYFLOAR']['FLOARACHIVD']) /
                        int.parse(targetData['DAILYFLOAR']['FLOARTGT'])) *
                        100),
                "USERACHIVD":targetData['DAILYUSER']['USERACHIVD'],
                "USERTGT":targetData['DAILYUSER']['USERTGT'],
                "TEAMACHIVD":targetData['DAILYTEAM']['TEAMACHIVD'],
                "TEAMTGT":targetData['DAILYTEAM']['TEAMTGT'],
                "FLOARACHIVD":targetData['DAILYFLOAR']['FLOARACHIVD'],
                "FLOARTGT":targetData['DAILYFLOAR']['FLOARTGT'],
                "percentage": status.value,
              };
              targetList.add(data1);

              chartData = [ChartData("Me",double.parse(data1['meTarget']),const Color(0xff16BFD6)),ChartData("Team",double.parse(data1['teamTarget']),const Color(0xffF7BD65)),
                ChartData("Floor",double.parse(data1['floorTarget']),const Color(0xffA155B9)),];

              var data2 = {
                "type": DateFormat.MMMM().format(DateTime.now()),
                "meTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['MONTHUSER']['USERACHIVD']) /
                        int.parse(targetData['MONTHUSER']['USERTGT'])) *
                        100)
                    .toString(),
                "teamTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['MONTHTEAM']['TEAMACHIVD']) /
                        int.parse(targetData['MONTHTEAM']['TEAMTGT'])) *
                        100)
                    .toString(),
                "floorTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['MONTHFLOAR']['FLOARACHIVD']) /
                        int.parse(targetData['MONTHFLOAR']['FLOARTGT'])) *
                        100)
                    .toString(),
                "USERACHIVD":targetData['MONTHUSER']['USERACHIVD'],
                "USERTGT":targetData['MONTHUSER']['USERTGT'],
                "TEAMACHIVD":targetData['MONTHTEAM']['TEAMACHIVD'],
                "TEAMTGT":targetData['MONTHTEAM']['TEAMTGT'],
                "FLOARACHIVD":targetData['MONTHFLOAR']['FLOARACHIVD'],
                "FLOARTGT":targetData['MONTHFLOAR']['FLOARTGT'],
                "percentage": status.value,
              };
              targetList.add(data2);
              var data3 = {
                "type": "Quarterly",
                "meTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['QRTUSER']['USERACHIVD']) /
                        int.parse(targetData['QRTUSER']['USERTGT'])) *
                        100)
                    .toString(),
                "teamTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['QRTTEAM']['TEAMACHIVD']) /
                        int.parse(targetData['QRTTEAM']['TEAMTGT'])) *
                        100)
                    .toString(),
                "floorTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['QRTFLOAR']['FLOARACHIVD']) /
                        int.parse(targetData['QRTFLOAR']['FLOARTGT'])) *
                        100)
                    .toString(),
                "USERACHIVD":targetData['QRTUSER']['USERACHIVD'],
                "USERTGT":targetData['QRTUSER']['USERTGT'],
                "TEAMACHIVD":targetData['QRTTEAM']['TEAMACHIVD'],
                "TEAMTGT":targetData['QRTTEAM']['TEAMTGT'],
                "FLOARACHIVD":targetData['QRTFLOAR']['FLOARACHIVD'],
                "FLOARTGT":targetData['QRTFLOAR']['FLOARTGT'],
                "percentage": status.value,
              };
              targetList.add(data3);

              dataPoint.value = targetData['DATAPOINT'];
              epicData.value = targetData['EPICENTRE'];
              zoneData.value = targetData['ZONEMIS'];
              outstandingData.value = targetData['OUTSTANDING'];
              callBookingData.value = targetData['CALLBOOK'];

              businessData.value = targetData['RPTBUSINESS'];
              await getOpportunity();
              await getLeadData();
              if(DataInfo.isSelectUser.value){
                await getUserData();
              }

              await getDataL2();
              isLoading.value = false;
            } else {
              isLoading.value = false;
              CustomWidgets.snackBar(title: value.data.toString());
            }
          }
        });

    }
    else
      {

       await Api().fetchApi(
            data:json.encode(
              {
                "UID": DataInfo.userId.value,
                "PID": DataInfo.pid.value,
                "UNAME": DataInfo.username.value
              },
            ),
            action: "ACHIVEDTARGET").then((value) {


          if (value!.success) {
            if (value.data.toString().contains("Please Update Your App") == false) {
              var data = value.data;
              var targetData = data['ROOT'][0]['DETAILS'][0];

              var data1 = {
                "type": "Today",
                "meTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['DAILYUSER']['USERACHIVD']) /
                        int.parse(targetData['DAILYUSER']['USERTGT'])) *
                        100),
                "teamTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['DAILYTEAM']['TEAMACHIVD']) /
                        int.parse(targetData['DAILYTEAM']['TEAMTGT'])) *
                        100),
                "floorTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['DAILYFLOAR']['FLOARACHIVD']) /
                        int.parse(targetData['DAILYFLOAR']['FLOARTGT'])) *
                        100),
                "USERACHIVD":targetData['DAILYUSER']['USERACHIVD'],
                "USERTGT":targetData['DAILYUSER']['USERTGT'],
                "TEAMACHIVD":targetData['DAILYTEAM']['TEAMACHIVD'],
                "TEAMTGT":targetData['DAILYTEAM']['TEAMTGT'],
                "FLOARACHIVD":targetData['DAILYFLOAR']['FLOARACHIVD'],
                "FLOARTGT":targetData['DAILYFLOAR']['FLOARTGT'],
                "percentage": status.value,
              };
              targetList.add(data1);
              chartData = [ChartData("Me",double.parse(data1['meTarget']),const Color(0xff16BFD6)),ChartData("Team",double.parse(data1['teamTarget']),const Color(0xffF7BD65)),
                ChartData("Floor",double.parse(data1['floorTarget']),const Color(0xffA155B9)),];
              var data2 = {
                "type": "Monthly",
                "meTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['MONTHUSER']['USERACHIVD']) /
                        int.parse(targetData['MONTHUSER']['USERTGT'])) *
                        100)
                    .toString(),
                "teamTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['MONTHTEAM']['TEAMACHIVD']) /
                        int.parse(targetData['MONTHTEAM']['TEAMTGT'])) *
                        100)
                    .toString(),
                "floorTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['MONTHFLOAR']['FLOARACHIVD']) /
                        int.parse(targetData['MONTHFLOAR']['FLOARTGT'])) *
                        100)
                    .toString(),
                "USERACHIVD":targetData['MONTHUSER']['USERACHIVD'],
                "USERTGT":targetData['MONTHUSER']['USERTGT'],
                "TEAMACHIVD":targetData['MONTHTEAM']['TEAMACHIVD'],
                "TEAMTGT":targetData['MONTHTEAM']['TEAMTGT'],
                "FLOARACHIVD":targetData['MONTHFLOAR']['FLOARACHIVD'],
                "FLOARTGT":targetData['MONTHFLOAR']['FLOARTGT'],
                "percentage": status.value,
              };
              targetList.add(data2);
              var data3 = {
                "type": "Quarterly",
                "meTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['QRTUSER']['USERACHIVD']) /
                        int.parse(targetData['QRTUSER']['USERTGT'])) *
                        100)
                    .toString(),
                "teamTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['QRTTEAM']['TEAMACHIVD']) /
                        int.parse(targetData['QRTTEAM']['TEAMTGT'])) *
                        100)
                    .toString(),
                "floorTarget": CustomWidgets.showNumber(
                    (int.parse(targetData['QRTFLOAR']['FLOARACHIVD']) /
                        int.parse(targetData['QRTFLOAR']['FLOARTGT'])) *
                        100)
                    .toString(),
                "USERACHIVD":targetData['QRTUSER']['USERACHIVD'],
                "USERTGT":targetData['QRTUSER']['USERTGT'],
                "TEAMACHIVD":targetData['QRTTEAM']['TEAMACHIVD'],
                "TEAMTGT":targetData['QRTTEAM']['TEAMTGT'],
                "FLOARACHIVD":targetData['QRTFLOAR']['FLOARACHIVD'],
                "FLOARTGT":targetData['QRTFLOAR']['FLOARTGT'],
                "percentage": status.value,
              };
              targetList.add(data3);


            } else {
              isLoading.value = false;
              CustomWidgets.snackBar(title: value.data.toString());
            }



          }
        });





      await  Api().fetchApi(
            data: json.encode(
              {
                "UID": DataInfo.userId.value,
                "PID": DataInfo.pid.value,
                "UNAME":DataInfo.username.value,
                "ENROLLID":DataInfo.enrollId.value,
                "REQTYPE":"MONTH"
              },
            ),
            action: "SUPDASHBOARD").then((value) async{


          if (value!.success) {

            if (value.data.toString().contains("Please Update Your App") == false) {

              var responseDataL2 = value.data;
              var dataL2 = responseDataL2['ROOT'][0]['DETAILS'][0];
              mapDataL2['pprc'] = dataL2['TCKDTLS']['PPRC'];
              mapDataL2['ticket'] = dataL2['TCKDTLS']['RESTCK'];

              selectData.value = {
                "caseCreated":dataL2['CASEDTLS']['USERCREATECASE'],
                "caseResolved":dataL2['CASEDTLS']['USERAPRCASE'],
                "tallyTips":dataL2['TALLYTIPS']['USERTIPS'],
                "testmoinels":dataL2['TESTIMONIAL']['USERTESTIMONIAL'],
                "feedbacks":dataL2['FEEDBACK']['USERMONTHFEEDBACK'],
                "ratings":dataL2['RATING']['USER'],

              };
              monthlyL2Data.value = {
                "caseCreated":dataL2['CASEDTLS']['USERCREATECASE'],
                "caseResolved":dataL2['CASEDTLS']['USERAPRCASE'],
                "tallyTips":dataL2['TALLYTIPS']['USERTIPS'],
                "testmoinels":dataL2['TESTIMONIAL']['USERTESTIMONIAL'],
                "feedbacks":dataL2['FEEDBACK']['USERMONTHFEEDBACK'],
                "ratings":dataL2['RATING']['USER'],

              };
              quarterlyL2Data.value = {
                "caseCreated":dataL2['CASEDTLS']['QRTUSERCREATECASE'],
                "caseResolved":dataL2['CASEDTLS']['QRTAPRCASE'],
                "tallyTips":dataL2['TALLYTIPS']['QRTTIPS'],
                "testmoinels":dataL2['TESTIMONIAL']['QRTTESTIMONIAL'],
                "feedbacks":dataL2['FEEDBACK']['QRTFEEDBACK'],
                "ratings":dataL2['RATING']['QRT'],

              };
              allL2Data.value = {
                "caseCreated":dataL2['CASEDTLS']['ALLUSERCREATECASE'],
                "caseResolved":dataL2['CASEDTLS']['ALLRAPRCASE'],
                "tallyTips":dataL2['TALLYTIPS']['ALLTIPS'],
                "testmoinels":dataL2['TESTIMONIAL']['ALLTESTIMONIAL'],
                "feedbacks":dataL2['FEEDBACK']['ALLFEEDBACK'],
                "ratings":dataL2['RATING']['ALL'],

              };
              avgRating.value = dataL2['RATINGAVG']['ALLRATING'];
              await getRating();
              await getDataL2();
              isLoading.value = false;
            } else {
              isLoading.value = false;
              CustomWidgets.snackBar(title: value.data.toString());
            }
          }
        });
       await  Api().fetchApi(data:json.encode(
         {

           "UID": DataInfo.userId.value,
           "LEADTYPE":"GIVEN"
         },
       ),action: "LEADDASHBOARD").then((value) {


         if (value!.success) {

           if (value.data.toString().contains("Please Update Your App") == false) {

             var responseDataL2 = value.data;

             var data = responseDataL2['ROOT'][0]['DETAILS'][0];
             mapDataL2['lead'] = data['ACCEPTED'];




           } else {
             isLoading.value = false;
             CustomWidgets.snackBar(title: value.data.toString());
           }
         }
       });
       if(DataInfo.isSelectUser.value){
         getUserData();
       }


      }
    if(DataInfo.box.hasData("status"))
    {

      if(DataInfo.box.read("status") == 1)
      {
        await Future.delayed(const Duration(seconds: 1));
        CustomWidgets.showProfileDialog();
        DataInfo.box.write("status", 2);
      }


    }
  }
  // updateStatus(int index,String type){
  //   String p1,p2,p3;
  //
  //   if(index == 0)
  //     {
  //       if(type == "M")
  //         {
  //           p1 = "DAILYUSER";
  //           p2 = "USERACHIVD";
  //           p3 = "USERTGT";
  //
  //           status.value = double.parse("${((int.parse(targetList[index][p2].toString())/100000) / (int.parse(targetList[index][p3].toString())/100000)) * 100}").toStringAsFixed(2);
  //           targetList[index]['percentage'] = status.value;
  //           update();
  //         }
  //       else if(type == "T")
  //         {
  //           p1 = "DAILYTEAM";
  //           p2 = "TEAMACHIVD";
  //           p3 = "TEAMTGT";
  //           status.value = double.parse("${((int.parse(targetList[index][p2].toString())/100000) / (int.parse(targetList[index][p3].toString())/100000)) * 100}").toStringAsFixed(2);
  //          // status.value = "${(int.parse(targetList[index][p2].toString())/100000).toDoubleStringAsFixed(digit: 2)}L / (${(int.parse(targetList[index][p3].toString())/100000).toDoubleStringAsFixed(digit: 2)}L)";
  //           targetList[index]['percentage'] = status.value;
  //           update();
  //         }
  //       else
  //         {
  //           p1 = "DAILYFLOAR";
  //           p2 = "FLOARACHIVD";
  //           p3 = "FLOARTGT";
  //           status.value = double.parse("${((int.parse(targetList[index][p2].toString())/100000) / (int.parse(targetList[index][p3].toString())/100000)) * 100}").toStringAsFixed(2);
  //           //status.value = "${(int.parse(targetList[index][p2].toString())/100000).toDoubleStringAsFixed(digit: 2)}L / (${(int.parse(targetList[index][p3].toString())/100000).toDoubleStringAsFixed(digit: 2)}L)";
  //           targetList[index]['percentage'] = status.value;
  //           update();
  //         }
  //     }
  //   else if(index == 1)
  //     {
  //       if(type == "M")
  //       {
  //         p1 = "MONTHUSER";
  //         p2 = "USERACHIVD";
  //         p3 = "USERTGT";
  //         status.value = double.parse("${((int.parse(targetList[index][p2].toString())/100000) / (int.parse(targetList[index][p3].toString())/100000)) * 100}").toStringAsFixed(2);
  //        // status.value = "${(int.parse(targetList[index][p2].toString())/100000).toDoubleStringAsFixed(digit: 2)}L / (${(int.parse(targetList[index][p3].toString())/100000).toDoubleStringAsFixed(digit: 2)}L)";
  //         targetList[index]['percentage'] = status.value;
  //         update();
  //       }
  //       else if(type == "T")
  //       {
  //         p1 = "MONTHTEAM";
  //         p2 = "TEAMACHIVD";
  //         p3 = "TEAMTGT";
  //         status.value = double.parse("${((int.parse(targetList[index][p2].toString())/100000) / (int.parse(targetList[index][p3].toString())/100000)) * 100}").toStringAsFixed(2);
  //         targetList[index]['percentage'] = status.value;
  //         update();
  //       }
  //       else
  //       {
  //         p1 = "MONTHFLOAR";
  //         p2 = "FLOARACHIVD";
  //         p3 = "FLOARTGT";
  //         status.value = double.parse("${((int.parse(targetList[index][p2].toString())/100000) / (int.parse(targetList[index][p3].toString())/100000)) * 100}").toStringAsFixed(2);
  //        // status.value = "${(int.parse(targetList[index][p2].toString())/100000).toDoubleStringAsFixed(digit: 2)}L / (${(int.parse(targetList[index][p3].toString())/100000).toDoubleStringAsFixed(digit: 2)}L)";
  //         targetList[index]['percentage'] = status.value;
  //         update();
  //       }
  //     }
  //   else
  //     {
  //       if(type == "M")
  //       {
  //         p1 = "QRTUSER";
  //         p2 = "USERACHIVD";
  //         p3 = "USERTGT";
  //         status.value = double.parse("${((int.parse(targetList[index][p2].toString())/100000) / (int.parse(targetList[index][p3].toString())/100000)) * 100}").toStringAsFixed(2);
  //        // status.value = "${(int.parse(targetList[index][p2].toString())/100000).toDoubleStringAsFixed(digit: 2)}L / (${(int.parse(targetList[index][p3].toString())/100000).toDoubleStringAsFixed(digit: 2)}L)";
  //         targetList[index]['percentage'] = status.value;
  //         update();targetList[index]['percentage'] = status.value;
  //         update();
  //       }
  //       else if(type == "T")
  //       {
  //         p1 = "QRTTEAM";
  //         p2 = "TEAMACHIVD";
  //         p3 = "TEAMTGT";
  //         status.value = double.parse("${((int.parse(targetList[index][p2].toString())/100000) / (int.parse(targetList[index][p3].toString())/100000)) * 100}").toStringAsFixed(2);
  //         //status.value = "${(int.parse(targetList[index][p2].toString())/100000).toDoubleStringAsFixed(digit: 2)}L / (${(int.parse(targetList[index][p3].toString())/100000).toDoubleStringAsFixed(digit: 2)}L)";
  //         targetList[index]['percentage'] = status.value;
  //         update();
  //       }
  //       else
  //       {
  //         p1 = "QRTFLOAR";
  //         p2 = "FLOARACHIVD";
  //         p3 = "FLOARTGT";
  //         status.value = double.parse("${((int.parse(targetList[index][p2].toString())/100000) / (int.parse(targetList[index][p3].toString())/100000)) * 100}").toStringAsFixed(2);
  //        // status.value = "${(int.parse(targetList[index][p2].toString())/100000).toDoubleStringAsFixed(digit: 2)}L / (${(int.parse(targetList[index][p3].toString())/100000).toDoubleStringAsFixed(digit: 2)}L)";
  //         targetList[index]['percentage'] = status.value;
  //         update();
  //       }
  //     }
  // }
  updateStatus(int index,String type){
    String p1,p2,p3;

    if(index == 0)
    {
      if(type == "M")
      {
        p1 = "DAILYUSER";
        p2 = "USERACHIVD";
        p3 = "USERTGT";

        status.value = "${(int.parse(targetList[index][p2].toString())/100000).toDoubleStringAsFixed(digit: 2)}L / (${(int.parse(targetList[index][p3].toString())/100000).toDoubleStringAsFixed(digit: 2)}L)";
        targetList[index]['percentage'] = status.value;

        update();
      }
      else if(type == "T")
      {
        p1 = "DAILYTEAM";
        p2 = "TEAMACHIVD";
        p3 = "TEAMTGT";
        status.value = "${(int.parse(targetList[index][p2].toString())/100000).toDoubleStringAsFixed(digit: 2)}L / (${(int.parse(targetList[index][p3].toString())/100000).toDoubleStringAsFixed(digit: 2)}L)";
        targetList[index]['percentage'] = status.value;

        update();
      }
      else
      {
        p1 = "DAILYFLOAR";
        p2 = "FLOARACHIVD";
        p3 = "FLOARTGT";
        status.value = "${(int.parse(targetList[index][p2].toString())/100000).toDoubleStringAsFixed(digit: 2)}L / (${(int.parse(targetList[index][p3].toString())/100000).toDoubleStringAsFixed(digit: 2)}L)";
        targetList[index]['percentage'] = status.value;

        update();
      }
    }
    else if(index == 1)
    {
      if(type == "M")
      {
        p1 = "MONTHUSER";
        p2 = "USERACHIVD";
        p3 = "USERTGT";
        status.value = "${(int.parse(targetList[index][p2].toString())/100000).toDoubleStringAsFixed(digit: 2)}L / (${(int.parse(targetList[index][p3].toString())/100000).toDoubleStringAsFixed(digit: 2)}L)";
        targetList[index]['percentage'] = status.value;

        update();
      }
      else if(type == "T")
      {
        p1 = "MONTHTEAM";
        p2 = "TEAMACHIVD";
        p3 = "TEAMTGT";
        status.value = "${(int.parse(targetList[index][p2].toString())/100000).toDoubleStringAsFixed(digit: 2)}L / (${(int.parse(targetList[index][p3].toString())/100000).toDoubleStringAsFixed(digit: 2)}L)";
        targetList[index]['percentage'] = status.value;

        update();
      }
      else
      {
        p1 = "MONTHFLOAR";
        p2 = "FLOARACHIVD";
        p3 = "FLOARTGT";
        status.value = "${(int.parse(targetList[index][p2].toString())/100000).toDoubleStringAsFixed(digit: 2)}L / (${(int.parse(targetList[index][p3].toString())/100000).toDoubleStringAsFixed(digit: 2)}L)";
        targetList[index]['percentage'] = status.value;

        update();
      }
    }
    else
    {
      if(type == "M")
      {
        p1 = "QRTUSER";
        p2 = "USERACHIVD";
        p3 = "USERTGT";
        status.value = "${(int.parse(targetList[index][p2].toString())/100000).toDoubleStringAsFixed(digit: 2)}L / (${(int.parse(targetList[index][p3].toString())/100000).toDoubleStringAsFixed(digit: 2)}L)";
        targetList[index]['percentage'] = status.value;
        update();targetList[index]['percentage'] = status.value;

        update();
      }
      else if(type == "T")
      {
        p1 = "QRTTEAM";
        p2 = "TEAMACHIVD";
        p3 = "TEAMTGT";
        status.value = "${(int.parse(targetList[index][p2].toString())/100000).toDoubleStringAsFixed(digit: 2)}L / (${(int.parse(targetList[index][p3].toString())/100000).toDoubleStringAsFixed(digit: 2)}L)";
        targetList[index]['percentage'] = status.value;

        update();
      }
      else
      {
        p1 = "QRTFLOAR";
        p2 = "FLOARACHIVD";
        p3 = "FLOARTGT";
        status.value = "${(int.parse(targetList[index][p2].toString())/100000).toDoubleStringAsFixed(digit: 2)}L / (${(int.parse(targetList[index][p3].toString())/100000).toDoubleStringAsFixed(digit: 2)}L)";
        targetList[index]['percentage'] = status.value;

        update();
      }
    }
  }
  updateChartData(int index){
    chartData = [ChartData("Me",double.parse(targetList[index]['meTarget']),const Color(0xff16BFD6)),ChartData("Team",double.parse(targetList[index]['teamTarget']),const Color(0xffF7BD65)),
      ChartData("Floor",double.parse(targetList[index]['floorTarget']),const Color(0xffA155B9)),];
    update();
  }
  getOpportunity() async {
    Api().fetchApi(data:json.encode(
      {
        "UID": DataInfo.userId.value,
        "DPID": "",
      },
    ),action: "GETOPP").then((value) {

      if(value!.success){
        var data = value.data;
        opportunityList.value = data['ROOT'][0]['OPPORTUNITY'];
      }
    });

  }

  getLeadData() async {
    Api().fetchApi(data:json.encode(
      {
        "UID": DataInfo.userId.value,
        'LEADTYPE': 'RECEIVED',
      },
    ),action: "LEADDASHBOARD").then((value) {
      if(value!.success){

        var data = value.data;
        var targetData = data['ROOT'][0]['DETAILS'][0];
        leadData.value = targetData;
      }
    });

  }

  getUserData() async {
    Api().fetchApi(data:DataInfo.userId.value,
    action: "TEAMMEMBER").then((value) {
      if(value!.success){

        var userdata = value.data;
        userList.value = userdata;
        filterUserList.value = userdata;
      }
    });

  }

  getRating() async{
    Api().fetchApi(data:json.encode(
        {"UNAME":DataInfo.username.value,"REQTYPE":"MONTH"}
    ),action: "GETSUPRANK").then((value) {


      if (value!.success) {

        if (value.data.toString().contains("Please Update Your App") == false) {


          var responseDataL2 = value.data;

          for(int i = 0;i<responseDataL2.length;i++)
          {
            if(responseDataL2[i]['TYPE']== "Floor")
            {
              overAllRating.value = responseDataL2[i]['RANK'];
            }
          }




        } else {
          isLoading.value = false;
          CustomWidgets.snackBar(title: value.data.toString());
        }
      }
    });

  }

  getDataL2() async{
    Api().fetchApi(data:DataInfo.username.value,action: "CALLBOOK").then((value) {


      if (value!.success) {

        if (value.data.toString().contains("Please Update Your App") == false) {

          var responseDataL2 = value.data;

          if(responseDataL2['ROOT'][0].containsKey("DETAILS"))
          {
            var data = responseDataL2['ROOT'][0]['DETAILS'];

            mapDataL2['onsitevisits'] = data.length.toString();
            callBooking.value =  data.where((element)=>int.parse(element['DTFLT'].toString()) == 0  || int.parse(element['DTFLT'].toString()) == 1).toList().length.toString();

          }




        } else {
          isLoading.value = false;
          CustomWidgets.snackBar(title: value.data.toString());
        }
      }
    });

  await  Api().fetchApi(data:json.encode(
      {

        "UID": DataInfo.userId.value,
        "LEADTYPE":"GIVEN"
      },
    ),action: "LEADDASHBOARD").then((value) {


      if (value!.success) {

        if (value.data.toString().contains("Please Update Your App") == false) {

          var responseDataL2 = value.data;

          var data = responseDataL2['ROOT'][0]['DETAILS'][0];
          mapDataL2['lead'] = data['ACCEPTED'];




        } else {
          isLoading.value = false;
          CustomWidgets.snackBar(title: value.data.toString());
        }
      }
    });



  }


  searchUser() {
    filterUserList.value = userList
        .where((element) => element['NAME']
            .toString()
            .trim()
            .toLowerCase()
            .contains(search.trim().toLowerCase()))
        .toList();
    update();
  }

  updateData() {
    searchController.text = "";
    search.value = "";
    filterUserList.value = userList;
    update();
  }

  showProduct(int index)
  {
    if(selectPrdId.value != opportunityList[index]['ID'])
      {
        selectPrdId.value = opportunityList[index]['ID'];
      }
    else
      {
        selectPrdId.value = "";
      }
    update();


  }

  dataPointSearch(String? value) async{
    if(value!.trim().isNotEmpty)
      {
        var responseData = await Apis.sendData(
            json.encode(
              {
                "TALLYSRNO":"",
                "SRCHWORD":value,
                "UID": DataInfo.userId.value,

              },
            ),
            "SEARCHDATAPOINT&ENCKEY=${DataInfo.encKey.value}&SRC=KARMA");

        if(responseData != null)
        {
          var data = json.decode(responseData.body);
          listData.value = data;
          update();
        }
      }
    else
      {
        listData.value = [];
      }
    update();
  }

  void onRefresh() async {
    // monitor network fetch
     getData();
    //getDashboardData();
    await Future.delayed(const Duration(milliseconds: 1000));

    refreshController.refreshCompleted();
  }

  void onLoading() async {
    // monitor network fetch
    await Future.delayed(const Duration(milliseconds: 1000));


    refreshController.loadComplete();
  }

  uploadData() async{
    try{
      // Loader();
      // DatabaseReference ref = FirebaseDatabase.instance.ref("tipOffBox/");
      //
      // await ref.push().set({
      //   "USERID": DataInfo.userId.value,
      //   "USERNAME": DataInfo.username.value,
      //   "USERTEAM": DataInfo.fullName.value,
      //   "DESIGNATION": DataInfo.designation.value,
      //   "DATE": DateFormat('EEE MMM dd yyyy').format(DateTime.now()),
      //   "TIME": "${TimeOfDay.now().hour} : ${TimeOfDay.now().minute}",
      //   "DESCRIPTION": content.text.trim(),
      // });
      //
      // Loader().hide();
      content.clear();
      CustomWidgets.showDialog(title: "Thanks for being awesome!",
          content: "We’re thrilled to hear from you.Your ideas and suggestions are very important to us and we read every message that we receive.");
    }catch(e){
      Loader().hide();
    }
  }

  updateRemindMeData(){


      remindMeList.add(
        {
          "ID": remindMeList.length + 1,
          "DATE": selectRemindMeDate.value,
          "TIME": selectTime.value,
          "DESC": content1.text.trim()
        }
      );
      selectTime.value = "";
      content1.clear();
      DataInfo.box.write("remindMe", remindMeList);
      Get.back();
  }
  getHistory(){
    Get.dialog(Center(
        child: Obx(()=>Card(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextWidget("History",fontSize: 18,fontWeight: FontWeight.w700,
                textAlign: TextAlign.center,).centered().p8(),
              Container(
                width: Get.width,
                height: 1.0,
                color: Colors.grey[400],
              ),
              10.heightBox,

              SizedBox(
                height: 200,
                child: ListView.builder(
                    itemCount: remindMeList.length,
                    itemBuilder: (context,index){
                      return Card(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TextWidget(remindMeList[index]['DESC'].toString(),fontSize: 16,fontWeight: FontWeight.w600,),
                            5.heightBox,
                            Row(
                              children: [
                                TextWidget(remindMeList[index]['DATE'],fontSize: 14,fontWeight: FontWeight.w400,),
                                5.widthBox,
                                TextWidget(remindMeList[index]['TIME'],fontSize: 14,fontWeight: FontWeight.w400,),
                              ],
                            ),
                          ],
                        ).p8(),
                      );
                    }),
              ),

              CustomButton(text: "OK",onPressed: (){
                Get.back();
              },  width: 120,
                height: 40,).centered()

            ],
          ).p8(),
        ).pSymmetric(h: 20.0,v: 8.0),)
    ));
  }

  updateTheme(int index){
    final themeController = Provider.of<AppThemeController>(Get.context!,listen: false);
    DataInfo.box.write("theme", index+1);
    DataInfo.selectTheme.value  = index + 1;
    appGradientColor.value = appTheme[index];
    appColor.value = appColorList[index];
    var theme = Get.put(AppTheme());
    theme.appGradientColor.value = appTheme[index];
    theme.appColor.value = appColorList[index];
    theme.changeTheme(appTheme[index]);
    themeController.changeTheme(appTheme[index]);
    update();
    Get.back();
  }
}

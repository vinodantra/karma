
import 'package:karma/Constants/Library.dart';
import 'package:intl/intl.dart';

class CallBookingController extends GetxController {
  RxString callDate = "".obs;
  RxMap data = {}.obs;
  RxString currentDate = DateFormat('dd-MM-yyyy').format(DateTime.now()).obs;
  RxString currentTime = TimeOfDay.now().format(Get.context!).obs;
  RxString selectDate = DateTime.now().toString().obs;
  RxString selectTime = TimeOfDay.now().format(Get.context!).obs;
  RxBool isLoading = false.obs;
  RxList<dynamic> callTypeList = [].obs;
  RxList<dynamic> fCallTypeList = [].obs;
  RxList<dynamic> natureOfCall = [].obs;
  RxList<dynamic> fNatureOfCall = [].obs;
  RxList<dynamic> teamList = [].obs;
  RxList<dynamic> fTeamList = [].obs;
  RxList<dynamic> supTypeList = [].obs;
  RxList<dynamic> fSupTypeList = [].obs;
  RxList<dynamic> addressList = [].obs;
  RxList<dynamic> fAddressList = [].obs;
  RxList<dynamic> tallySrNo = [].obs;
  RxList<dynamic> fTallySrNo = [].obs;
  RxList<dynamic> contactList = [].obs;
  RxList<dynamic> fContactList = [].obs;
  RxList<dynamic> allocationManagerList = [].obs;
  RxList<dynamic> lUsersList = [].obs;
  RxList<dynamic> flUsersList = [].obs;
  RxString selectCallType = "Select".obs;
  RxString selectNoc = "Select".obs;
  RxString selectNocId = "".obs;
  RxString selectSupType = "Select".obs;
  RxString selectSupTypeId = "".obs;
  RxString selectManager = "Select".obs;
  RxString selectManagerId = "".obs;
  RxString selectUser = "Select".obs;

  RxString selectAddress = "Select".obs;
  RxString selectPhone = "".obs;
  RxString addressDetails = "".obs;
  RxString selectRegion = "".obs;
  RxString selectTallySrNo = "Select".obs;
  RxString selectContact = "Select".obs;
  RxString selectContactEmail = "".obs;
  RxString selectContactMobile = "".obs;
  RxString selectContactId = "".obs;
  RxInt selectCheckCollection = 2.obs;
  RxString selectTeamId = "".obs;
  RxString search = "".obs;
  RxString selectCallTypeId = "".obs;

  TextEditingController searchController = TextEditingController();
  TextEditingController remarkController = TextEditingController();

  String callBookingData = "";

  @override
  void onInit() {
    data.value = Get.arguments;

    getData();
    getUserData();
    super.onInit();
  }

  void getData() async {
    isLoading.value = true;

    Api().fetchApi(
        data:data['DPID'],
        action: "GETCALLENTRYDATA").then((value) {
      try {


        if (value!.success) {
          var jsonResponse = value.data;

          var jsonData = jsonResponse['ROOT'][0];
          callTypeList.value = jsonData['CALLTYPE'];
          fCallTypeList.value = jsonData['CALLTYPE'];
          natureOfCall.value = jsonData['NATUREOFCALL'];
          fNatureOfCall.value = jsonData['NATUREOFCALL'];
          teamList.value = jsonData['TEAM'];
          fTeamList.value = jsonData['TEAM'];

          supTypeList.value = jsonData['SUPTYPE'];
          fSupTypeList.value = jsonData['SUPTYPE'];
          addressList.value = jsonData['ADDRESS'];
          fAddressList.value = jsonData['ADDRESS'];
          tallySrNo.value = jsonData['TALLYSRNO'];
          fTallySrNo.value = jsonData['TALLYSRNO'];
          contactList.value = jsonData['CONTACT'];
          fContactList.value = jsonData['CONTACT'];
          allocationManagerList.value = jsonData['TEAM'];

          selectSupType.value =
          supTypeList.isNotEmpty ? supTypeList[1]['NAME'] : 'Select';
          selectAddress.value =
          addressList.isNotEmpty ? addressList.first['NAME'] : 'Select';
          selectAddress.value =
          addressList.isNotEmpty ? addressList.first['NAME'] : "";
          addressDetails.value =
          addressList.isNotEmpty ? addressList.first['ADD'] : "";
          selectPhone.value =
          addressList.isNotEmpty ? addressList.first['PHONE'] : "";
          selectRegion.value =
          addressList.isNotEmpty ? addressList.first['CITY'] : "";
          selectTallySrNo.value =
          tallySrNo.isNotEmpty ? tallySrNo.first['NAME'] : "Select";

          isLoading.value = false;
        } else {
          isLoading.value = false;
        }
      } catch (e) {
        isLoading.value = false;
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });

  }

  void getUserData() async {

    Api().fetchApi(action: "L1USER").then((value) {
      try {


        if (value!.success) {
          var jsonData = value.data;



          lUsersList.value = jsonData;
          flUsersList.value = jsonData;

          isLoading.value = false;
        } else {
          isLoading.value = false;
        }
      } catch (e) {
        isLoading.value = false;
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });

  }

  searchUser(int type) {
    if (type == 1) {
      fNatureOfCall.value = natureOfCall
          .where((element) => element['NAME']
              .toString()
              .trim()
              .toLowerCase()
              .contains(search.trim().toLowerCase()))
          .toList();
    } else {
      flUsersList.value = flUsersList
          .where((element) => element['NAME']
              .toString()
              .trim()
              .toLowerCase()
              .contains(search.trim().toLowerCase()))
          .toList();
    }
    update();
  }

  updateData() {
    searchController.text = "";
    search.value = "";
    fNatureOfCall.value = natureOfCall;
    flUsersList.value = lUsersList;
    update();
  }

  checkData() {
    String? status;
    if (selectCallType.value == "Select") {
      status = "Type of Call";
    } else if (selectNoc.value == "Select") {
      status = "Nature of Call";
    } else if (selectManager.value == "Select") {
      status = "Allocation Manager";
    } else if (selectManager.value == "Sales" && selectUser.value == "Select") {
      status = "User";
    } else if (selectContact.value == "Select") {
      status = "Contact Person";
    } else {
      sendData();
    }
    // else if(selectCheckCollection.value == 2)
    //   {
    //     status = "Cheque Collection";
    //   }
    // else if(remarkController.text.trim().isEmpty)
    //   {
    //     CustomWidgets.snackBar(title: "Please enter remark for customer");
    //     return false;
    //   }
    if (Utilities.checkString(status.toString())) {
      CustomWidgets.snackBar(title: "Please select $status");
    }
  }

  sendData() async {
    /*
    https://gateway.tallyhelp.com/crm/UpdateData.aspx?DATA="Abc solution india|Andheri-E|vinod1@antraweb.co.in|
    chandresh||Abc solution india|Shanti Estate M.G. Road Andheri 400093 Andheri-E Maharashtra|000000009 (MUM)|0221234567980|
    9172691115||2||20-04-2023 12:15 PM|2||High|
    vinod|31999|2|43930|I|Mr.|Andheri-E|Yes"&ACTION=CALLENTRY&ENCKEY=a9301158-4764-45ee-a6ec-9a8120c2a153&SRC=KARMA
     */
    /*
    https://gateway.tallyhelp.com/crm/UpdateData.aspx?DATA=Abc%20solution%20india||vinod1%40antraweb.co.in|
    chandresh|Onsite|Shanti%20Estate%20M.G.%20Road%20Andheri%20400093%20Andheri-E%20Maharashtra||0221234567980|
    9172691115|2|2|2023-04-20%2012:18%20pm|
    29||High||vinod|31999|2|39|III|Mr.|No&ACTION=CALLENTRY&ENCKEY=a989f07d-d9ce-4419-8b2c-148decc3183b&SRC=KARMA

     */
    isLoading.value = true;
    callBookingData = data['DPNAME'];
    callBookingData += "|";
    callBookingData += "|${selectContactEmail.value}";
    callBookingData += "|${selectContact.value}";
    callBookingData += "|${selectSupType.value}";
    callBookingData += "|${addressDetails.value}";
    callBookingData += "|${selectTallySrNo.value}";
    callBookingData += "|${selectPhone.value}";
    callBookingData += "|${selectContactMobile.value.trim()}";
    callBookingData += "|2";
    callBookingData += "|2";
    callBookingData +=
        "|${DateFormat('yyyy-MM-dd').format(DateTime.parse(selectDate.value.toString()))} ${selectTime.value}";
    callBookingData += "|${selectNocId.value}";
    callBookingData += "|${remarkController.text.trim()}";
    callBookingData += "|High";
    callBookingData += "|";
    callBookingData += "|${DataInfo.username.value}";
    callBookingData += "|${data['DPID']}";
    callBookingData += "|${selectCallTypeId.value}";
    callBookingData += "|${DataInfo.userId.value}";
    callBookingData += "|I";

    callBookingData += "|Mr.";

    callBookingData += "|${selectCheckCollection.value == 1 ? "Yes" : "No"}";

    Api().fetchApi(
        data:  DataInfo.desCat.value == "L1" ?  Uri.encodeComponent(callBookingData):callBookingData,
        action: "CALLENTRY").then((value) {
      try {


        if (value!.success) {
          if (value.data == "YES") {
            Get.dialog(
              Center(
                child: Card(
                  color: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.check,
                        color: Colors.lightGreen,
                        size: 50,
                      ),
                      20.heightBox,
                      TextWidget(
                        "Well Done!",
                        fontSize: 18,
                        color: Colors.black,
                      ),
                      15.heightBox,
                      TextWidget(
                        "You call has been Successfully Booked.",
                        fontSize: 16,
                        color: Colors.grey[500],
                      ),
                      20.heightBox,
                      CustomButton(
                        text: "Ok",
                        onPressed: () {
                          // Get.offAll(() => DataPointInfo(), arguments: data);
                          Get.back();
                        },
                      ),
                      10.heightBox,
                    ],
                  ).p24(),
                ),
              ),
              barrierDismissible: false,
            ).then((value) {
              Get.back();
              //Get.offAll(() => DataPointInfo(), arguments: data);
            });
          }

          isLoading.value = false;
        } else {
          isLoading.value = false;
        }
      } catch (e) {
        isLoading.value = false;
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });

  }
}

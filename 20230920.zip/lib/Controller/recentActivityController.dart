import 'dart:developer';

import 'package:karma/Constants/Library.dart';
import "package:collection/collection.dart";
import 'package:intl/intl.dart';
class RecentActivityController extends GetxController{
  RxMap data  = {}.obs;
  RxString selectType = "1".obs;
  RxList<dynamic> activityList = [].obs;
  RxList<dynamic> proposalList = [].obs;
  RxString proformaData = "".obs;
  RxBool isLoading  = false.obs;




  var currentDate = DateFormat('yyyy-MM-dd').format(DateTime.now());
  @override
  void onInit() {
    data.value = Get.arguments;
    getActivityData();
    super.onInit();
  }
  getActivityData()async{
    isLoading.value = true;

    Api().fetchApi(
        data: json.encode({"OPPID":"0","DPID":"${data['DPID']}"}),
        action: "OPPRECENTACTIVITY").then((value) {
      try{

        if(value!.success)
        {
          var jsonResponse =
          value.data;
          activityList.value = jsonResponse;
         // print(activityList.sort((a,b)=>a['FLWDATE'].toString().compareTo(b['FLWDATE'].toString())).toString());

         // sortList();
          //var de = sortList();
          //print(de.toString());

          isLoading.value = false;
        }

      }catch(e){
        isLoading.value = false;
        if (kDebugMode) {
          print("error:$e");
        }
      }
    });


  }

   sortList() {

    return activityList..sort((a,b)=>b['DATE'].toString().compareTo(a['DATE'].toString()));
  }
}
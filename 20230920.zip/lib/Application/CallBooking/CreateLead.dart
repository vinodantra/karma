import 'package:karma/Constants/Library.dart';


class CreateLead extends GetView<CreateLeadController> {
  const CreateLead({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(CreateLeadController());
    return Scaffold(
      appBar: AppBarWidget(
        title: "New Lead",
        onSubmit: (){
          controller.checkData();
        },
      ),
      body: SizedBox(
          width: Get.width,
          height: Get.height,
          child: Obx(()=>ListView(
            children: [

              tile(title: "Interested In",list: controller.list,type: "3",selectData: controller.selectData.value,
                  pa: "SOURCE",
                  updateData: (data){

                controller.selectId.value = data['ID'];
                    controller.selectData.value = data['SOURCE'];

                  }),
              tile(title: "Lead Source",data: "Cust. Reference"),
              tile(title: "Item",list: controller.itemList,type: "3",selectData: controller.selectItem.value,
                  pa: "NAME",
                  updateData: (data){

                    controller.selectItemId.value = data['ID'];
                    controller.selectItem.value = data['NAME'];

                  }),
              tile(title: "Company Name",data: controller.data['CMP']),
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      TextWidget(
                        "Contact Name",
                        color: const Color(0xff344053),
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                      SizedBox(
                          width: Get.width / 2,
                          height: 50,
                          child: TextField(

                            controller: controller.contactName,
                            keyboardType: TextInputType.name,
                            textAlign: TextAlign.right,

                          )
                      ),
                    ],
                  ).pSymmetric(h: 15.0, v: 5.0),
                  5.heightBox,
                  Container(
                    width: Get.width,
                    height: 1.0,
                    color: Colors.grey[400],
                  ),
                ],
              ),
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      TextWidget(
                        "Contact Number",
                        color: const Color(0xff344053),
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                      SizedBox(
                          width: Get.width / 2,
                          height: 50,
                          child: TextField(

                            controller: controller.contactNumber,
                            keyboardType: TextInputType.name,
                            textAlign: TextAlign.right,

                          )
                      ),
                    ],
                  ).pSymmetric(h: 15.0, v: 5.0),
                  5.heightBox,
                  Container(
                    width: Get.width,
                    height: 1.0,
                    color: Colors.grey[400],
                  ),
                ],
              ),
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      TextWidget(
                        "Email",
                        color: const Color(0xff344053),
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                      SizedBox(
                          width: Get.width / 2,
                          height: 50,
                          child: TextField(

                            controller: controller.email,
                            keyboardType: TextInputType.name,
                            textAlign: TextAlign.right,

                          )
                      ),
                    ],
                  ).pSymmetric(h: 15.0, v: 5.0),
                  5.heightBox,
                  Container(
                    width: Get.width,
                    height: 1.0,
                    color: Colors.grey[400],
                  ),
                ],
              ),
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      TextWidget(
                        "City",
                        color: const Color(0xff344053),
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                      SizedBox(
                          width: Get.width / 2,
                          height: 50,
                          child: TextField(

                            controller: controller.city,
                            keyboardType: TextInputType.name,
                            textAlign: TextAlign.right,

                          )
                      ),
                    ],
                  ).pSymmetric(h: 15.0, v: 5.0),
                  5.heightBox,
                  Container(
                    width: Get.width,
                    height: 1.0,
                    color: Colors.grey[400],
                  ),
                ],
              ),
              tile(title: "Tally Serial Number",data: controller.data['TALLYSRLNO']),
              TextWidget(
                "Comment",
                color: const Color(0xff344053),
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ).pSymmetric(h: 15.0,v: 10.0),
              TextField(

                controller: controller.remark,
                keyboardType: TextInputType.multiline,
                decoration: const InputDecoration(
                  hintText: "Write Additional detail/Comment here"
                ),
                minLines: 10,
                maxLines: 10,

              ).pSymmetric(h: 15.0,v: 10.0)
              // tile(title: "Contact Name",data: controller.data['CONPER']),
              // tile(title: "Contact Number",data: controller.data['MOB']),
              // tile(title: "Email",data: controller.data['CMPEMAIL']),
              // tile(title: "City",data: controller.data['CITY']),

            ],
          ),)),
    );
  }

  Widget tile(
      {String? title,
      String? data,
      String type = "1",
      List<dynamic>? list,
      String pa = "",
      String selectData = "",ValueChanged<Map<String,dynamic>>? updateData}) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextWidget(
              title,
              color: const Color(0xff344053),
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
            type == "1"
                ? SizedBox(
                    width: Get.width / 2,
                    child: TextWidget(
                      data,
                      color: const Color(0xff667084),
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      textAlign: TextAlign.right,
                      maxLines: 10,
                    ),
                  )
                : type == "2"
                    ? InkWell(
                        onTap: () {
                          Utilities.onClickMobile(data!);
                        },
                        child: TextWidget(
                          data,
                          color: Colors.lightBlueAccent,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          textDecoration: TextDecoration.underline,
                        ),
                      )
                    : InkWell(
                        onTap: () {
                          CustomWidgets.customBottomSheet(
                              list, pa, false, (data) {
                            updateData!(data);
                            Get.back();
                          });
                        },
                        child: Row(
                          children: [
                            TextWidget(
                              selectData,
                              fontSize: 14,
                              color: Color(0xff2f3237),
                            ),
                            5.widthBox,
                            const Icon(
                              Icons.keyboard_arrow_down_outlined,
                              color: Color(0xff7E8494),
                            )
                          ],
                        ),
                      ),
          ],
        ).pSymmetric(h: 15.0, v: 10.0),
        5.heightBox,
        Container(
          width: Get.width,
          height: 1.0,
          color: Colors.grey[400],
        ),
      ],
    );
  }
}

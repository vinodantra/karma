import 'package:karma/Constants/Library.dart';

import 'package:intl/intl.dart';
class ConveyanceEntry extends GetView<ConveyanceEntryController> {
  const ConveyanceEntry({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(ConveyanceEntryController());
    return Scaffold(
      appBar: AppBarWidget(
        title: "Add Conveyance",
        onSubmit: (){
           controller.checkData();
        },
      ),
      body: SizedBox(
          width: Get.width,
          height: Get.height,
          child: Obx(()=>ListView(
            children: [
              tile(title: "Company Name",data: controller.data['CMP']),
              tile(title: "Date",data: controller.data['CALLDATE']),
              tile(title: "Travel By",selectData: controller.selectTravelByData.value,list: controller.travelByList,
                  type: "3",
                  pa: "SOURCE",
                  updateData: (data){
                    controller.selectTravelByData.value = data['SOURCE'];
                    if(controller.selectTravelByData.value == "Bike")
                      {
                        controller.getPrice();
                      }
                  }),
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      TextWidget(
                        "From",
                        color: const Color(0xff344053),
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                      SizedBox(
                          width: Get.width / 2,
                          height: 50,
                          child: TextField(

                            controller: controller.from,
                            keyboardType: TextInputType.name,
                            textAlign: TextAlign.right,

                          )
                      ),
                    ],
                  ).pSymmetric(h: 15.0, v: 5.0),
                  5.heightBox,
                  Container(
                    width: Get.width,
                    height: 1.0,
                    color: Colors.grey[400],
                  ),
                ],
              ),
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      TextWidget(
                        "To",
                        color: const Color(0xff344053),
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                      SizedBox(
                          width: Get.width / 2,
                          height: 50,
                          child: TextField(

                            controller: controller.to,
                            keyboardType: TextInputType.name,
                            textAlign: TextAlign.right,

                          )
                      ),
                    ],
                  ).pSymmetric(h: 15.0, v: 5.0),
                  5.heightBox,
                  Container(
                    width: Get.width,
                    height: 1.0,
                    color: Colors.grey[400],
                  ),
                ],
              ),
             controller.showPassData.value ?  Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      TextWidget(
                        "Distance(Rs. 3/Km.)",
                        color: const Color(0xff344053),
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                      SizedBox(
                          width: Get.width / 2,
                          height: 50,
                          child: TextField(
                            onChanged: (value){
                              controller.amount.text = (double.parse(controller.petrolPrice.value) * double.parse(value)).toString();
                            },
                            controller: controller.distanceController,
                            keyboardType: TextInputType.number,
                            textAlign: TextAlign.right,

                          )
                      ),
                    ],
                  ).pSymmetric(h: 15.0, v: 5.0),
                  5.heightBox,
                  Container(
                    width: Get.width,
                    height: 1.0,
                    color: Colors.grey[400],
                  ),
                ],
              ) : const SizedBox(),
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      TextWidget(
                        "Amount",
                        color: const Color(0xff344053),
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                      SizedBox(
                          width: Get.width / 2,
                          height: 50,
                          child: TextField(

                            controller: controller.amount,
                            readOnly:  controller.selectTravelByData.value == "Bike" ? true  : false,
                            keyboardType: TextInputType.number,
                            textAlign: TextAlign.right,

                          )
                      ),
                    ],
                  ).pSymmetric(h: 15.0, v: 5.0),
                  5.heightBox,
                  Container(
                    width: Get.width,
                    height: 1.0,
                    color: Colors.grey[400],
                  ),
                ],
              ),
              TextField(

                controller: controller.comment,
                keyboardType: TextInputType.multiline,

                decoration: const InputDecoration(
                    hintText: "Comment"
                ),
                minLines: 10,
                maxLines: 10,

              ).pSymmetric(h: 15.0,v: 10.0),
              Row(

                mainAxisAlignment: MainAxisAlignment.start,

                children: [
                  CustomButton(text: "Add Pass",
                    onPressed: (){
                      Get.dialog(Center(
                        child: Obx(()=>Card(
                          color: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              TextWidget("Pass Details",fontSize: 18,
                                fontWeight: FontWeight.w500,),
                              10.heightBox,
                              Container(
                                height: 1.0,
                                width: Get.width,
                                color: Colors.grey[400],
                              ),
                              10.heightBox,
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  TextWidget("Pass Type",fontSize: 16,
                                    color: appColor.value,),
                                  InkWell(
                                    onTap:(){
                                      CustomWidgets.customBottomSheet(controller.passTypeList, "NAME",false, (data){

                                        controller.selectPassType.value = data['NAME'];

                                        Get.back();
                                      });

                                    },
                                    child: Row(

                                      children: [
                                        TextWidget(controller.selectPassType.value,fontSize: 14,color: Color(0xff2f3237),),
                                        5.widthBox,
                                        const Icon(Icons.keyboard_arrow_down_outlined,color: Color(0xff7E8494),)
                                      ],),
                                  ),

                                ],
                              ).pSymmetric(h: 10.0,v: 5.0),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  TextWidget("From Date",fontSize: 16,
                                    color: appColor.value,),
                                  InkWell(
                                    onTap:()async{
                                      var de = await  CustomWidgets.pickDate(context);

                                      if(de != null) {

                                        controller.selectFromDate.value = DateFormat('dd-MMM-yyyy')
                                            .format(de);


                                      }

                                    },
                                    child: Row(

                                      children: [
                                        TextWidget(controller.selectFromDate.value,fontSize: 14,color: Color(0xff2f3237),),
                                        5.widthBox,
                                        const Icon(Icons.calendar_today_outlined,color: Color(0xff7E8494),)
                                      ],),
                                  ),

                                ],
                              ).pSymmetric(h: 10.0,v: 5.0),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  TextWidget("To Date",fontSize: 16,
                                    color: appColor.value,),
                                  InkWell(
                                    onTap:()async{
                                      var de = await  CustomWidgets.pickDate(context);

                                      if(de != null) {

                                        controller.selectToDate.value = DateFormat('dd-MMM-yyyy')
                                            .format(de);


                                      }

                                    },
                                    child: Row(

                                      children: [
                                        TextWidget(controller.selectToDate.value,fontSize: 14,color: Color(0xff2f3237),),
                                        5.widthBox,
                                        const Icon(Icons.calendar_today_outlined,color: Color(0xff7E8494),)
                                      ],),
                                  ),

                                ],
                              ).pSymmetric(h: 10.0,v: 5.0),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  TextWidget(
                                    "From Location",

                                    color: appColor.value,
                                    fontSize: 16,

                                    fontWeight: FontWeight.w500,

                                  ),

                                  SizedBox(
                                      width: Get.width / 3,
                                      height: 50,
                                      child:  TextField(

                                        controller: controller.fromLocationController,

                                      )
                                  ),
                                ],
                              ).pSymmetric(h: 10.0,v: 5.0),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  TextWidget(
                                    "To Location",

                                    color: appColor.value,
                                    fontSize: 16,

                                    fontWeight: FontWeight.w500,

                                  ),

                                  SizedBox(
                                      width: Get.width / 3,
                                      height: 50,
                                      child:  TextField(

                                        controller: controller.toLocationController,

                                      )
                                  ),
                                ],
                              ).pSymmetric(h: 10.0,v: 5.0),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  TextWidget(
                                    "Pass Amount",

                                    color: appColor.value,
                                    fontSize: 16,

                                    fontWeight: FontWeight.w500,

                                  ),

                                  SizedBox(
                                      width: Get.width / 3,
                                      height: 50,
                                      child:  TextField(

                                        controller: controller.passAmount,

                                      )
                                  ),
                                ],
                              ).pSymmetric(h: 10.0,v: 5.0),
                              10.heightBox,
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  TextButton(onPressed: (){
                                    Get.back();
                                  }, child: TextWidget("Cancel",fontSize: 16,
                                    color: Colors.black,)),
                                  CustomButton(text: "OK",onPressed: (){
                                    if(controller.selectPassType.value == "Select")
                                      {
                                        CustomWidgets.snackBar(title: "Please select pass type");
                                      }
                                    else if(controller.selectFromDate.value.isEmpty)
                                      {
                                        CustomWidgets.snackBar(title: "Please select from date");
                                      }
                                    else if(controller.selectToDate.value.isEmpty)
                                    {
                                      CustomWidgets.snackBar(title: "Please select to date");
                                    }
                                    else if(controller.fromLocationController.value.text.isEmpty)
                                    {
                                      CustomWidgets.snackBar(title: "Please enter from location");
                                    }
                                    else if(controller.toLocationController.text.isEmpty)
                                    {
                                      CustomWidgets.snackBar(title: "Please enter to location");
                                    }
                                    else if(controller.passAmount.text.isEmpty)
                                    {
                                      CustomWidgets.snackBar(title: "Please enter pass amount");
                                    }
                                    else
                                      {
                                        controller.createPass();
                                        Get.back();
                                      }
                                    // if(controller.selectTicketTypeId.value != "" && controller.tallyNoController.text != "")
                                    // {
                                    //   controller.tallyNumberController.text = "${controller.selectTicketType.value}-${controller.tallyDate.value.toUpperCase()}-${controller.tallyNoController.text}";
                                    //   log("show data:${controller.tallyNumberController.text}");
                                    //   Get.back();
                                    // }
                                    // else
                                    // {
                                    //   CustomWidgets.snackBar(title: "Please enter all fields.");
                                    // }
                                  },  width: 120,
                                    height: 40,),
                                ],
                              ),
                            ],
                          ).p24(),
                        ),)

                      ),
                        barrierDismissible: false,
                      ).then((value) {


                      });
                    },
                    width: 100,
                    height: 50,),
                ],
              ).p8(),
              TextWidget("Conveyance List",fontSize: 18,fontWeight: FontWeight.w500,
              textAlign: TextAlign.center,).p8(),
              Column(
                children: List.generate(controller.conveyanceList.length, (index) => ListTile(
                  title: TextWidget("${controller.conveyanceList[index]['FROM'].toString()} To ${controller.conveyanceList[index]['TO'].toString()} By ${controller.conveyanceList[index]['SOURCE'].toString()}",
                  fontSize: 18,fontWeight: FontWeight.w500,),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextWidget("Amount ${controller.conveyanceList[index]['AMOUNT'].toString()}"),
                      TextWidget("Remark ${controller.conveyanceList[index]['REMARK'].toString()}"),


                    ],
                  ),
                  trailing: IconButton(
                    onPressed: (){
                      CustomWidgets.showAlertDialog(title: "Confirm",
                      content: "Are you sure to delete?",
                      onCancel: (){

                        Get.back();
                      },
                      onClick: (){
                        controller.deleteConveyanceData(controller.conveyanceList[index]['ID']);
                        Get.back();
                      });
                    },
                    icon: const Icon(Icons.close),
                  ),

                )),
              ),
              20.heightBox,
            ],
          ),)
      ),
    );
  }

  Widget tile(
      {String? title,
        String? data,
        String type = "1",
        List<dynamic>? list,
        String pa = "",
        String selectData = "",ValueChanged<Map<String,dynamic>>? updateData}) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextWidget(
              title.toString(),
              color: const Color(0xff344053),
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
            type == "1"
                ? SizedBox(
              width: Get.width / 2,
              child: TextWidget(
                data.toString(),
                color: const Color(0xff667084),
                fontSize: 16,
                fontWeight: FontWeight.w500,
                textAlign: TextAlign.right,
                maxLines: 10,
              ),
            )
                : type == "2"
                ? InkWell(
              onTap: () {
                Utilities.onClickMobile(data!);
              },
              child: TextWidget(
                data,
                color: Colors.lightBlueAccent,
                fontSize: 16,
                fontWeight: FontWeight.w500,
                textDecoration: TextDecoration.underline,
              ),
            )
                : InkWell(
              onTap: () {
                CustomWidgets.customBottomSheet(
                    list, pa, false, (data) {
                  updateData!(data);
                  Get.back();
                });
              },
              child: Row(
                children: [
                  TextWidget(
                    selectData,
                    fontSize: 14,
                    color: Color(0xff2f3237),
                  ),
                  5.widthBox,
                  const Icon(
                    Icons.keyboard_arrow_down_outlined,
                    color: Color(0xff7E8494),
                  )
                ],
              ),
            ),
          ],
        ).pSymmetric(h: 15.0, v: 10.0),
        5.heightBox,
        Container(
          width: Get.width,
          height: 1.0,
          color: Colors.grey[400],
        ),
      ],
    );
  }
}

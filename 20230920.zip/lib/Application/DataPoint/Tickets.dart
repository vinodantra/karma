// ignore_for_file: file_names

import 'package:karma/Application/TicketStatus/TickerDetails.dart';
import 'package:karma/Constants/Library.dart';

class Tickets extends GetView<TicketController> {
  const Tickets({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(TicketController());
    return Scaffold(
      appBar: AppBarWidget(
        title: "Tickets",
      ),
      body: Obx(()=>Stack(
        children: [

          SizedBox(
              width: Get.width,
              height: Get.height,
              child:Column(
                children: [
                  SearchWidget(
                    controller: controller.searchController,
                    hintText: "Search",
                    onChanged: (value){

                      controller.search.value = value!;

                      controller.filterDataList();

                    },
                    onClose: (){
                      FocusManager.instance.primaryFocus?.unfocus();
                      controller.searchController.clear();
                      controller.search.value = "";

                      controller.onInit();
                    },),
                  10.heightBox,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Container(

                        decoration: controller.selectData.value == "All" ?
                        decoration(context,borderRadius:   BorderRadius.circular(100)) : shapeDecoration(borderRadius: BorderRadius.circular(100)),
                        child: controller.selectData.value == "All" ?
                        GradientTextWidget("All",
                          fontSize: 14,

                          fontWeight: FontWeight.w500,
                          ).centered().w(Get.width / 4).pSymmetric(v: 10.0) : TextWidget("All",
                          color: const Color(0xFF7D8493),
                          fontSize: 14,

                          fontWeight: FontWeight.w400,).centered().w(Get.width / 4).pSymmetric(v: 10.0),
                      ).onInkTap(() {

                        controller.selectData.value = "All";
                        controller.filterDataList();
                      }),
                      Container(

                        decoration: controller.selectData.value == "Pending" ?
                        decoration(context,borderRadius:   BorderRadius.circular(100)) : shapeDecoration(borderRadius: BorderRadius.circular(100)),
                        child: controller.selectData.value == "Pending" ?
                        GradientTextWidget("Pending",
                          fontSize: 14,

                          fontWeight: FontWeight.w500,
                        ).centered().w(Get.width / 4).pSymmetric(v: 10.0) : TextWidget("Pending",
                          color: const Color(0xFF7D8493),
                          fontSize: 14,

                          fontWeight: FontWeight.w400,).centered().w(Get.width /4).pSymmetric(v: 10.0),
                      ).onInkTap(() {

                        controller.selectData.value = "Pending";
                        controller.filterDataList();
                      }),
                      Container(

                        decoration: controller.selectData.value == "Resolved" ?
                        decoration(context,borderRadius:   BorderRadius.circular(100)) : shapeDecoration(borderRadius: BorderRadius.circular(100)),
                        child: controller.selectData.value == "Resolved" ?
                        GradientTextWidget("Resolved",
                          fontSize: 14,

                          fontWeight: FontWeight.w500,
                        ).centered().w(Get.width / 4).pSymmetric(v: 10.0) : TextWidget("Resolved",
                          color: const Color(0xFF7D8493),
                          fontSize: 14,

                          fontWeight: FontWeight.w400,).centered().w(Get.width /4).pSymmetric(v: 10.0),
                      ).onInkTap(() {

                        controller.selectData.value = "Resolved";
                        controller.filterDataList();
                      }),
                    ],
                  ),
                  controller.list.isNotEmpty ?
                  Expanded(
                    child: ListView.builder(
                        itemCount: controller.list.length,
                        itemBuilder: (context,index ){return tile(controller.list[index],index);}).p8(),
                  ) : controller.isLoading.value == false ?
                  Center(child: TextWidget("No data found",fontSize: 20,fontWeight: FontWeight.w500,)) : const SizedBox()
                ],
              ),
          ),
          controller.isLoading.value ? const LoadingScreen() : const SizedBox(),
        ],
      )),
    );
  }

  Widget tile(var data,int i,){
    return GetBuilder<TicketController>(builder: (dashboardController){
      return InkWell(
        onTap:(){

         Get.to(()=> const TicketDetails(),arguments:controller.list[i]['TICKET']);
        },
        child: Container(
          width:Get.width,


          decoration: shapeDecoration(
            
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(
                  gradient: bGradient,
                  borderRadius: const BorderRadius.only(topLeft: Radius.circular(8.0),topRight: Radius.circular(8.0))

                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextWidget(
                      data['TICKET'],

                      color: appColor.value,
                      fontSize: 18,

                      fontWeight: FontWeight.w500,

                    ),
                    Container(

                      decoration: ShapeDecoration(
                        color: data['STATUS']  == "Resolved" ?   const Color(0xFF33BE52) : const Color(0xFFDF8E16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(56),
                        ),
                      ),
                      child: TextWidget(
                        data['STATUS'],

                        color: Colors.white,
                        fontSize: 14,

                        fontWeight: FontWeight.w500,

                      ).pSymmetric(h: 15.0,v: 8.0),
                    ),

                  ],
                ).pSymmetric(h: 16.0,v: 10.0),
              ),

              Container(
                width: Get.width,
                height: 1.0,
                color: Colors.grey[300],
              ),
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextWidget(
                        "Date",

                        color: const Color(0xFF282828),
                        fontSize: 12,
                        fontWeight: FontWeight.w400,

                      ),
                      TextWidget(
                        data['DATE'],
                        color: const Color(0xFF7D8493),
                        fontSize: 14,
                        fontWeight: FontWeight.w400,

                      ),
                    ],
                  ),
                  10.heightBox,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,


                    children: [
                      TextWidget(
                        "Contact Person",
                        color: const Color(0xFF282828),
                        fontSize: 12,
                        fontWeight: FontWeight.w400,

                      ),
                      TextWidget(
                        data['CNTPER'],
                        color: const Color(0xFF7D8493),
                        fontSize: 14,
                        fontWeight: FontWeight.w400,

                      ),
                    ],
                  ),
                  10.heightBox,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextWidget(
                        "Category",
                        color: const Color(0xFF282828),
                        fontSize: 12,
                        fontWeight: FontWeight.w400,

                      ),
                      TextWidget(
                        data['CAT'],
                        color: const Color(0xFF7D8493),
                        fontSize: 14,
                        fontWeight: FontWeight.w400,

                      ),
                    ],
                  ),
                  10.heightBox,
                  Row(

                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextWidget(
                        "Supported By",
                        color: const Color(0xFF282828),
                        fontSize: 12,
                        fontWeight: FontWeight.w400,

                      ),
                      TextWidget(
                        data['CREATEDBY'],
                        maxLines: 5,
                        color: const Color(0xFF7D8493),
                        fontSize: 14,
                        fontWeight: FontWeight.w400,

                      ),
                    ],
                  ),
                ],
              ).p16(),

              10.heightBox,



            ],
          )
        ).p8(),
      );
    });
  }
}

import 'package:gradient_borders/box_borders/gradient_box_border.dart';
import 'package:karma/Application/Lead/LeadReceived.dart';
import 'package:karma/Constants/Library.dart';
import 'package:karma/Controller/appThemeController.dart';
import 'package:provider/provider.dart';

class Lead extends GetView<LeadController> {
  const Lead({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(LeadController());
    return Scaffold(
      appBar: AppBarWidget(
        title: "Lead",
        onPressAdd: () {
          Get.to(() => const CreateLead1());
        },
      ),
      body: SizedBox(
        width: Get.width,
        height: Get.height,
        child: Obx(() => Stack(
              children: [
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        InkWell(
                          onTap: (){
                            controller.selectFilterData.value = "Given";

                            Get.find<LeadController>().onInit();
                          },
                          child: Container(
                            width: 100,
                            height: 35,
                            decoration: controller.selectFilterData.value == "Given"
                                ? BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              gradient: LinearGradient(
                                  begin: Alignment.centerLeft,
                                  end: Alignment.centerRight,
                                  colors:
                                  Provider.of<AppThemeController>(context)
                                      .appGradientColor),
                            )
                                : BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              border: GradientBoxBorder(
                                gradient: LinearGradient(
                                    colors:
                                    Provider.of<AppThemeController>(context)
                                        .appGradientColor),
                                width: 1.5,
                              ),
                            ),
                            alignment: Alignment.center,
                            child: controller.selectFilterData.value == "Given"
                                ? TextWidget(
                              "Given",
                              textAlign: TextAlign.center,
                              color: Colors.white,
                              fontSize: 12,
                              //fontFamily: "Inter",
                              fontWeight: FontWeight.w500,
                            )
                                : GradientText(
                              "Received",
                              gradient: LinearGradient(
                                  colors:
                                  Provider.of<AppThemeController>(context)
                                      .appGradientColor),
                              style: const TextStyle(
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ),
                        20.widthBox,
                        InkWell(
                          onTap:(){
                            controller.selectFilterData.value = "Received";

                            Get.find<LeadController>().onInit();
                          },
                          child: Container(
                            width: 100,
                            height: 35,
                            decoration: controller.selectFilterData.value == "Received"
                                ? BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              gradient: LinearGradient(
                                  begin: Alignment.centerLeft,
                                  end: Alignment.centerRight,
                                  colors:
                                  Provider.of<AppThemeController>(context)
                                      .appGradientColor),
                            )
                                : BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              border: GradientBoxBorder(
                                gradient: LinearGradient(
                                    colors:
                                    Provider.of<AppThemeController>(context)
                                        .appGradientColor),
                                width: 1.5,
                              ),
                            ),
                            alignment: Alignment.center,
                            child: controller.selectFilterData.value == "Received"
                                ? TextWidget(
                              "Received",
                              textAlign: TextAlign.center,
                              color: Colors.white,
                              fontSize: 12,
                              //fontFamily: "Inter",
                              fontWeight: FontWeight.w500,
                            )
                                : GradientText(
                              "Received",
                              gradient: LinearGradient(
                                  colors:
                                  Provider.of<AppThemeController>(context)
                                      .appGradientColor),
                              style: const TextStyle(
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    // Row(
                    //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //   children: [
                    //     TextWidget(
                    //       "Select Lead",
                    //       fontSize: 18,
                    //     ),
                    //     InkWell(
                    //       onTap: () {
                    //         CustomWidgets.customBottomSheet(
                    //             controller.filterData, "NAME", false, (data) {
                    //           controller.selectFilterData.value = data['NAME'];
                    //
                    //           Get.find<LeadController>().onInit();
                    //           Get.back();
                    //         });
                    //       },
                    //       child: ColoredBox(
                    //         color: Colors.transparent,
                    //         child: Row(
                    //           children: [
                    //             TextWidget(
                    //               controller.selectFilterData.value,
                    //               fontSize: 16,
                    //             ),
                    //             const Icon(Icons.keyboard_arrow_down_outlined)
                    //           ],
                    //         ),
                    //       ),
                    //     ),
                    //   ],
                    // ).p8(),
                    10.heightBox,
                    Check.data(controller.leadData) ?
                    Wrap(
                      runAlignment: WrapAlignment.spaceBetween,
                      spacing: 5.0,
                      runSpacing: 10.0,
                      children: [
                        tile("Accepted",controller.leadData['ACCEPTED'].toString(),acceptLead, const Color(0xFFEEFFF5),),
                        tile("Rejected",controller.leadData['REJECT'].toString() , rejectLead, const Color(0xFFFFEEEE),),
                        tile("In progress",controller.leadData['INPROCESS'].toString(),inProgressLead, const Color(0xFFFEFBEF),),
                        tile("Untouched",controller.leadData['UNTOUCHED'].toString(),untouchedLead, const Color(0xFFECF8FC),),
                     
                      

                    ],) : const SizedBox(),

                  ],
                ).p16(),
                controller.isLoading.value
                    ? const LoadingScreen()
                    : const SizedBox(),
              ],
            )),
      ),
    );
  }

  Widget tile1(String title, String value, String url) {
    return InkWell(
      onTap: () {
        Get.to(() => const LeadReceived(), arguments: {
          "lead": controller.selectFilterData.value,
          "leadtype": title
        })!
            .then((value) => Get.find<LeadController>().onInit());
      },
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          boxShadow: const [
            BoxShadow(
              color: Color(0x3f919191),
              blurRadius: 8,
              offset: Offset(0, 2),
            ),
          ],
          color: Colors.white,
        ),
        child: Row(
          children: [
            SizedBox(
              width: 80,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(50.0),
                child:
                    Image.network("${WebApis.rootUrl}/CRM/Karma/www/img/$url"),
              ),
            ),
            10.widthBox,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextWidget(
                  title,
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey[400],
                ),
                10.heightBox,
                TextWidget(
                  value,
                  fontSize: 30,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ],
            )
          ],
        ).p8(),
      ).pSymmetric(v: 4.0),
    );
  }
  Widget tile(String title,String value,String path,Color color,){
    return InkWell(
      onTap:(){
        Get.to(() => const LeadReceived(), arguments: {
          "lead": controller.selectFilterData.value,
          "leadtype": title
        })!
            .then((value) => Get.find<LeadController>().onInit());
      },
      child: Container(
        width: Get.width * 0.45,
        height: 100,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(8),
          border: const Border(
            left: BorderSide(color: Color(0xFFDFDFDF)),
            top: BorderSide(color: Color(0xFFDFDFDF)),
            right: BorderSide(color: Color(0xFFDFDFDF)),
            bottom: BorderSide(width: 1, color: Color(0xFFDFDFDF)),
          ),
          boxShadow: const [
            BoxShadow(
              color: Color(0x1E919191),
              blurRadius: 16,
              offset: Offset(0, 2),
              spreadRadius: 0,
            )
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,

          children: [
            TextWidget(value,
              color: const Color(0xFF282828),
              fontSize: 14,

              fontWeight: FontWeight.w700,
              ),
            10.heightBox,
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomWidgets.showAssetImage(path: path),
                5.widthBox,
                TextWidget(title,
                  color: const Color(0xFF282828),
                  fontSize: 14,

                  fontWeight: FontWeight.w400,
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:karma/Constants/Library.dart';

class CreateLead1 extends GetView<CreateLeadController1> {
  const CreateLead1({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Get.put(CreateLeadController1());
    return Scaffold(
      appBar: AppBarWidget(
        title: "New Lead",
        onSubmit: (){
          controller.checkData();
        },
      ),
      body: SizedBox(
        width: Get.width,
        height: Get.height,
        child: Obx(()=>Stack(
          children: [
            ListView(
              children: [

                selectItem(title: Utilities.checkString(controller.selectLeadSourceId.value) ? controller.selectLeadSourceData.value : "Lead Source",onPressed: (){
                  CustomWidgets.customBottomSheet(
                      controller.leadSourceList, "SOURCE", true, (data) {

                    controller.selectLeadSourceId.value  = data['ID'];
                    controller.selectLeadSourceData.value = data['SOURCE'];

                    Get.back();
                  });
                }),
                selectItem(title: Utilities.checkString(controller.selectInterestedId.value) ? controller.selectInterestedData.value  : "Interested In",onPressed: (){
                  CustomWidgets.customBottomSheet(
                      controller.interestedDataList, "SOURCE", true, (data) {
                    controller.selectInterestedId.value = data['ID'];
                    controller.selectInterestedData.value = data['SOURCE'];

                    Get.back();
                  });
                }),

                selectItem(title: Utilities.checkString(controller.selectItemId.value) ? controller.selectItemData.value : "Item",onPressed: (){
                  CustomWidgets.customBottomSheet(
                      controller.itemList, "NAME", true, (data) {
                    controller.selectItemId.value = data['ID'];
                    controller.selectItemData.value = data['NAME'];
                    Get.back();
                  });
                }),


                textField(controller:controller.companyName,hintText: "Company Name",keyboardType: TextInputType.name,
                  textInputAction: TextInputAction.next,),
                textField(controller:controller.contactName,hintText: "Contact Name",keyboardType: TextInputType.name,
                  textInputAction: TextInputAction.next,),
                textField(controller:controller.contactNumber,hintText: "Contact Number",keyboardType: TextInputType.number,
                  textInputAction: TextInputAction.next,),
                textField(controller:controller.email,hintText: "Email",keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,),
                textField(controller:controller.city,hintText: "City",keyboardType: TextInputType.name,
                  textInputAction: TextInputAction.next,),
                textField(controller:controller.tallySerialNumber,hintText: "Tally Serial Number",keyboardType: TextInputType.number,
                  textInputAction: TextInputAction.next,),
                commentField(controller:controller.comment,hintText: "Comment",keyboardType: TextInputType.multiline,
                  textInputAction: TextInputAction.done,),





                CustomButton(text: "Add",onPressed: (){
                  controller.checkData();
                },)

              ],
            ).p16(),
            controller.isLoading.value ?  const LoadingScreen() : const SizedBox(),
          ],
        )),
      ),
    );
  }

  Widget tile(
      {String? title,
        String? data,
        String type = "1",
        List<dynamic>? list,
        String pa = "",
        String selectData = "",ValueChanged<Map<String,dynamic>>? updateData,}) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextWidget(
              title,
              color: const Color(0xff344053),
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
            type == "1"
                ? SizedBox(
              width: Get.width / 2,
              child: TextWidget(
                data,
                color: const Color(0xff667084),
                fontSize: 16,
                fontWeight: FontWeight.w500,
                textAlign: TextAlign.right,
                maxLines: 10,
              ),
            )
                : type == "2"
                ? InkWell(
              onTap: () {
                Utilities.onClickMobile(data!);
              },
              child: TextWidget(
                data,
                color: Colors.lightBlueAccent,
                fontSize: 16,
                fontWeight: FontWeight.w500,
                textDecoration: TextDecoration.underline,
              ),
            )
                : InkWell(
              onTap: () {
                CustomWidgets.customBottomSheet(
                    list, pa, false, (data) {
                  updateData!(data);
                  Get.back();
                });
              },
              child: Row(
                children: [
                  TextWidget(
                    selectData,
                    fontSize: 14,
                    color: Color(0xff2f3237),
                  ),
                  5.widthBox,
                  const Icon(
                    Icons.keyboard_arrow_down_outlined,
                    color: Color(0xff7E8494),
                  )
                ],
              ),
            ),
          ],
        ).pSymmetric(h: 15.0, v: 10.0),
        5.heightBox,
        Container(
          width: Get.width,
          height: 1.0,
          color: Colors.grey[400],
        ),
      ],
    );
  }


}

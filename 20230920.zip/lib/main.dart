


import 'dart:developer';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/services.dart';

import 'package:karma/Route/AppRoutes.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:month_year_picker/month_year_picker.dart';
import 'package:provider/provider.dart';
import '../../Constants/Library.dart';
import 'Controller/notificationService.dart';
import 'Services/FirebaseOption.dart';
@pragma('vm:entry-point')
Future<void> backgroundHandler(RemoteMessage message) async {
  log("fcm notification");
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );


  NotificationServices.showNotification(
    id: 1,
    title: message.notification!.title!,
    body: message.notification!.body!,

    payload: "",
  );

  FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
    if (kDebugMode) {
      log("FirebaseMessaging.onMessageOpenedApp ${message.toString()}");
    }
  });
}
void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  /*
  options: const FirebaseOptions(apiKey: "AIzaSyBs5ey-pyxz-SzS1OtdPBV4XsUxguJ5koA",
      appId: "1:760938335592:android:f7ac8acdea0d6214a81add", messagingSenderId: "760938335592", projectId: "karma-tracking")
  */

  // Firebase.initializeApp(options: const FirebaseOptions(apiKey: "AIzaSyBs5ey-pyxz-SzS1OtdPBV4XsUxguJ5koA",
  //     appId: "1:760938335592:android:f7ac8acdea0d6214a81add", messagingSenderId: "760938335592", projectId: "karma-tracking"));
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  FirebaseMessaging.onBackgroundMessage(backgroundHandler);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    systemNavigationBarColor: Colors.transparent, // navigation bar color
    statusBarColor: Colors.transparent, // status bar color
  ));
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown
  ]);
  await GetStorage.init();

  InitialBindings().dependencies();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // This widget is the root of your application.
  @override
  void initState() {

    NotificationServices.init(context);
    NotificationServices.initialize();
    FirebaseMessaging.onMessage.listen((RemoteMessage event) {

      NotificationServices.showNotification(
        id: 1,
        title: event.notification!.title!,
        body: event.notification!.body!,

        payload: "",
      );
    });

   // NotificationServices.onNotifications.stream.listen(onClickNotification);
    FirebaseMessaging.instance
        .getInitialMessage()
        .then((RemoteMessage? message) {
      if (kDebugMode) {
        log("FirebaseMessaging.getInitialMessage ${message.toString()}");
      }
    });
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(create: (context)=> AppThemeController(),
    child: GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      getPages: AppRoutes.routes,

      initialBinding: InitialBindings(),
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        MonthYearPickerLocalizations.delegate,
      ],


    ),);
  }
}
